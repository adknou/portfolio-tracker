from __future__ import annotations

import os
import re
import sqlite3
from pathlib import Path
from typing import Any, Iterable

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
USE_POSTGRES = DATABASE_URL.startswith("postgres://") or DATABASE_URL.startswith("postgresql://")

try:
    if USE_POSTGRES:
        import psycopg
        from psycopg.rows import dict_row
        from psycopg.errors import UniqueViolation
    else:
        psycopg = None
        dict_row = None
        UniqueViolation = Exception
except Exception:  # imported lazily on local SQLite installs
    psycopg = None
    dict_row = None
    UniqueViolation = Exception

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "portfolio.db"


def backend_name() -> str:
    return "postgres" if USE_POSTGRES else "sqlite"


def _qmark_to_pg(sql: str) -> str:
    # Portfolio Tracker only uses ? as DB placeholders, not as SQL operators.
    return sql.replace("?", "%s")


def _named_to_pg(sql: str) -> str:
    return re.sub(r":([A-Za-z_][A-Za-z0-9_]*)", r"%(\1)s", sql)


class CompatCursor:
    def __init__(self, cursor: Any):
        self._cursor = cursor

    def fetchone(self):
        return self._cursor.fetchone()

    def fetchall(self):
        return self._cursor.fetchall()

    def __iter__(self):
        return iter(self._cursor)

    @property
    def rowcount(self):
        return getattr(self._cursor, "rowcount", -1)

    @property
    def lastrowid(self):
        return getattr(self._cursor, "lastrowid", None)


class CompatConnection:
    def __init__(self, conn: Any, postgres: bool):
        self._conn = conn
        self.postgres = postgres

    def execute(self, sql: str, params: Any = None) -> CompatCursor:
        if self.postgres:
            sql = _qmark_to_pg(sql)
            if isinstance(params, dict):
                sql = _named_to_pg(sql)
            cur = self._conn.execute(sql, params or ())
            return CompatCursor(cur)
        return CompatCursor(self._conn.execute(sql, params or ()))

    def executemany(self, sql: str, seq_params: Iterable[Any]) -> CompatCursor:
        if self.postgres:
            seq_params = list(seq_params)
            if seq_params and isinstance(seq_params[0], dict):
                sql = _named_to_pg(sql)
            else:
                sql = _qmark_to_pg(sql)
            cur = self._conn.cursor()
            cur.executemany(sql, seq_params)
            return CompatCursor(cur)
        return CompatCursor(self._conn.executemany(sql, seq_params))

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()


def connect() -> CompatConnection:
    if USE_POSTGRES:
        if psycopg is None:
            raise RuntimeError("psycopg n'est pas installé alors que DATABASE_URL pointe vers PostgreSQL")
        conn = psycopg.connect(DATABASE_URL, row_factory=dict_row)
        return CompatConnection(conn, True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return CompatConnection(conn, False)


def columns(conn: CompatConnection, table: str) -> set[str]:
    if conn.postgres:
        rows = conn.execute(
            "SELECT column_name AS name FROM information_schema.columns WHERE table_schema='public' AND table_name=?",
            (table,),
        ).fetchall()
        return {r["name"] for r in rows}
    return {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def add_column(conn: CompatConnection, table: str, definition: str) -> None:
    name = definition.split()[0]
    if name not in columns(conn, table):
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")


def is_integrity_error(exc: Exception) -> bool:
    if isinstance(exc, sqlite3.IntegrityError):
        return True
    if USE_POSTGRES and psycopg is not None:
        from psycopg import IntegrityError
        return isinstance(exc, IntegrityError)
    return False


def create_schema(conn: CompatConnection) -> None:
    if conn.postgres:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS positions (
                id BIGSERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                asset_type TEXT NOT NULL,
                account TEXT NOT NULL DEFAULT 'CTO',
                currency TEXT NOT NULL DEFAULT 'EUR',
                quantity DOUBLE PRECISION NOT NULL,
                last_price DOUBLE PRECISION NOT NULL DEFAULT 0,
                position_value DOUBLE PRECISION NOT NULL DEFAULT 0,
                performance_pct DOUBLE PRECISION NOT NULL DEFAULT 0,
                market_symbol TEXT NOT NULL DEFAULT '',
                target_pct DOUBLE PRECISION NOT NULL DEFAULT 0
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id BIGSERIAL PRIMARY KEY,
                position_id BIGINT NOT NULL,
                transaction_type TEXT NOT NULL,
                transaction_date TEXT NOT NULL,
                quantity DOUBLE PRECISION,
                unit_price_eur DOUBLE PRECISION,
                gross_amount_eur DOUBLE PRECISION NOT NULL DEFAULT 0,
                fees_eur DOUBLE PRECISION NOT NULL DEFAULT 0,
                realized_pnl_eur DOUBLE PRECISION,
                note TEXT NOT NULL DEFAULT '',
                created_at BIGINT NOT NULL DEFAULT (EXTRACT(EPOCH FROM NOW())::BIGINT)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS effort_monthly_confirmations (
                position_id BIGINT NOT NULL,
                month TEXT NOT NULL,
                amount_eur DOUBLE PRECISION NOT NULL,
                PRIMARY KEY (position_id, month)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_snapshots (
                id BIGSERIAL PRIMARY KEY,
                created_at BIGINT NOT NULL,
                total_value DOUBLE PRECISION NOT NULL,
                invested_estimate DOUBLE PRECISION NOT NULL DEFAULT 0,
                reason TEXT NOT NULL DEFAULT 'manual'
            )
            """
        )
    else:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS positions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                asset_type TEXT NOT NULL,
                account TEXT NOT NULL DEFAULT 'CTO',
                currency TEXT NOT NULL DEFAULT 'EUR',
                quantity REAL NOT NULL,
                last_price REAL NOT NULL DEFAULT 0,
                position_value REAL NOT NULL DEFAULT 0,
                performance_pct REAL NOT NULL DEFAULT 0,
                market_symbol TEXT NOT NULL DEFAULT '',
                target_pct REAL NOT NULL DEFAULT 0
            )
            """
        )
        conn.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                position_id INTEGER NOT NULL,
                transaction_type TEXT NOT NULL,
                transaction_date TEXT NOT NULL,
                quantity REAL,
                unit_price_eur REAL,
                gross_amount_eur REAL NOT NULL DEFAULT 0,
                fees_eur REAL NOT NULL DEFAULT 0,
                realized_pnl_eur REAL,
                note TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS effort_monthly_confirmations (
                position_id INTEGER NOT NULL,
                month TEXT NOT NULL,
                amount_eur REAL NOT NULL,
                PRIMARY KEY (position_id, month)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                total_value REAL NOT NULL,
                invested_estimate REAL NOT NULL DEFAULT 0,
                reason TEXT NOT NULL DEFAULT 'manual'
            )
            """
        )

    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_positions_name_account ON positions(name, account)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_position ON transactions(position_id, transaction_date, id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_snapshots_created ON portfolio_snapshots(created_at)")


def reset_postgres_sequences(conn: CompatConnection) -> None:
    if not conn.postgres:
        return
    for table in ("positions", "transactions", "portfolio_snapshots"):
        conn.execute(
            f"""
            SELECT setval(
                pg_get_serial_sequence('{table}','id'),
                GREATEST(COALESCE((SELECT MAX(id) FROM {table}), 1), 1),
                COALESCE((SELECT COUNT(*) FROM {table}), 0) > 0
            )
            """
        )
