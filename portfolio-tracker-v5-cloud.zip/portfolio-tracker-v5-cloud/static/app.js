let state=null, analyticsState=null, allocationChart=null, overviewPortfolioChart=null, effortChart=null, historyChart=null, positionHistoryCharts=new Map(), searchContext=null, selectedAddInstrument=null, transactionFilterPositionId=null;
let projectionCharts=[];
let activeTab="overview";
let tableSort={key:null,direction:'asc'};
let positionView='TOTAL';
let positionMetric=localStorage.getItem('portfolioPositionMetric')||'day_pct';
const expandedPositionIds=new Set();
const euro=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'});
const num=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:6});

async function api(url,options={}){
  const r=await fetch(url,{headers:{'Content-Type':'application/json','Cache-Control':'no-cache'},cache:'no-store',...options});
  const raw=await r.text(); let data={};
  try{data=raw?JSON.parse(raw):{}}catch{data={detail:raw||`Erreur HTTP ${r.status}`}}
  if(r.status===401){location.href='/login';throw new Error('Session expirée');}
  if(!r.ok) throw new Error(data.detail||`Erreur HTTP ${r.status}`);
  return data;
}
const perfClass=v=>v>0?'good':v<0?'bad':'';
function fmtPct(v){if(v===null||v===undefined||Number.isNaN(+v))return '—';const n=+v;return `${n>=0?'+':''}${n.toFixed(2)} %`}
function fmtNative(p){if(p.manual_active)return euro.format(p.manual_price||p.last_price_eur||0);const value=p.last_native_price??p.last_price_eur??0;try{return new Intl.NumberFormat('fr-FR',{style:'currency',currency:(p.currency||'EUR').toUpperCase(),maximumFractionDigits:4}).format(value)}catch{return `${num.format(value)} ${p.currency||''}`}}
function fmtCurrencyValue(v,c){try{return new Intl.NumberFormat('fr-FR',{style:'currency',currency:c||'EUR',maximumFractionDigits:4}).format(v)}catch{return `${num.format(v)} ${c||''}`}}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function marketLabel(p){if(p.manual_active)return `Manuel · ${euro.format(p.manual_price||p.last_price_eur||0)}${p.manual_price_note?` · ${p.manual_price_note}`:''}`;const bits=[p.provider,p.market_symbol,p.isin,p.exchange,p.currency,p.quote_quality].filter(Boolean);return bits.join(' · ')}
function fmtTarget(v){return `${(+v||0).toFixed(1)} %`}
function fmtGap(v){const n=+v||0;return `${n>=0?'+':''}${n.toFixed(2)} pt`}
function fmtTimestamp(epoch){if(!epoch)return '—';const d=new Date(Number(epoch)*1000);if(Number.isNaN(d.getTime()))return '—';return new Intl.DateTimeFormat('fr-FR',{dateStyle:'short',timeStyle:'short'}).format(d)}
function renderLastQuoteUpdate(){const el=document.querySelector('#lastQuoteUpdate');if(!el||!state)return;const checked=(state.positions||[]).map(p=>Number(p.quote_checked_at)||0).filter(Boolean);if(checked.length){el.textContent=`Dernière vérification des sources : ${fmtTimestamp(Math.max(...checked))} · la date du cours figure sur chaque ligne.`;return;}const times=(state.positions||[]).map(p=>Number(p.price_updated_at)||0).filter(Boolean);el.textContent=times.length?`Cours le plus récent en portefeuille : ${fmtTimestamp(Math.max(...times))} · vérifie la date propre à chaque titre.`:'Aucun cours encore actualisé';}

function renderQuoteFreshnessAlert(){
  const el=document.querySelector('#quoteFreshnessAlert');if(!el||!state)return;
  const rows=(state.positions||[]).filter(p=>p.quote_configured&&!p.manual_active);
  const stale=rows.filter(p=>p.quote_stale||p.quote_refresh_error);
  const unchecked=rows.filter(p=>!p.quote_checked_at);
  const now=new Date();const dailyCheckDue=now.getUTCDay()>=1&&now.getUTCDay()<=5&&now.getUTCHours()>=22;
  const notCheckedToday=dailyCheckDue?rows.filter(p=>!p.quote_checked_at||new Date(Number(p.quote_checked_at)*1000).toISOString().slice(0,10)!==now.toISOString().slice(0,10)):[];
  if(!rows.length){el.hidden=true;return;}
  el.hidden=false;
  if(stale.length){el.className='quoteFreshnessAlert warning';el.textContent=`⚠ ${stale.length} titre(s) avec cours ancien ou erreur de récupération. Actualise les cours pour vérifier les données.`;}
  else if(notCheckedToday.length){el.className='quoteFreshnessAlert warning';el.textContent=`⚠ ${notCheckedToday.length} titre(s) sans vérification enregistrée aujourd'hui. Actualise les cours.`;}
  else if(unchecked.length){el.className='quoteFreshnessAlert pending';el.textContent=`◷ ${unchecked.length} titre(s) sans vérification de cours enregistrée. Une actualisation est conseillée.`;}
  else{el.className='quoteFreshnessAlert fresh';el.textContent='✓ Aucun cours ancien signalé. Vérifie les dates des séances pour les marchés fermés.';}
}
function renderQuoteQualitySummary(){
  renderQuoteFreshnessAlert();
  const el=document.querySelector('#quoteQualitySummary');if(!el||!state)return;
  const rows=(state.positions||[]).filter(p=>p.quote_configured||p.manual_active||Number(p.last_price_eur)>0);
  const manual=rows.filter(p=>p.manual_active).length;
  const problem=rows.filter(p=>!p.manual_active&&(p.quote_stale||p.quote_refresh_error)).length;
  const fresh=Math.max(0,rows.length-manual-problem);
  const checked=rows.map(p=>Number(p.quote_checked_at)||Number(p.price_updated_at)||0).filter(Boolean);
  const last=checked.length?fmtTimestamp(Math.max(...checked)):'—';
  el.innerHTML=`<span class="qualityGood">${fresh} à jour</span> · ${manual} manuel${manual>1?'s':''} · <span class="${problem?'qualityBad':''}">${problem} ancien${problem>1?'s':''}/échec</span> · <span class="qualityTime">${escapeHtml(last)}</span>`;
}


async function load(){
  state=await api('/api/portfolio');
  analyticsState=await api('/api/analytics');
  document.querySelector('#totalValue').textContent=euro.format(state.total_value);
  document.querySelector('#invested').textContent=euro.format(state.invested_estimate);
  const pnl=document.querySelector('#pnl');pnl.textContent=euro.format(state.pnl_estimate);pnl.className=perfClass(state.pnl_estimate);
  const perf=document.querySelector('#perf');perf.textContent=fmtPct(state.performance_estimate_pct);perf.className=perfClass(state.performance_estimate_pct);
  document.querySelector('#mode').textContent=`${state.quote_mode} · v${state.app_version}`;
  document.querySelector('#planValue').textContent=euro.format(state.monthly_plan);
  document.querySelector('#planAsset').textContent=state.monthly_plan_asset;
  renderTable();renderPositionCards();renderLastQuoteUpdate();renderQuoteQualitySummary();renderAnalytics();renderActiveTab();
}


function sortValue(p,key){
  switch(key){
    case 'name': return String(p.name||'').toLocaleLowerCase('fr');
    case 'account': return String(p.account||'').toLocaleLowerCase('fr');
    case 'quantity': return Number(p.quantity)||0;
    case 'market_price': return Number(p.last_native_price??p.last_price_eur??0)||0;
    case 'position_value': return Number(p.position_value)||0;
    case 'weight_pct': return Number(p.weight_pct)||0;
    case 'target_pct': return Number(p.target_pct)||0;
    case 'performance_pct': return Number(p.performance_pct)||0;
    case 'day_change_pct': return Number(p.day_change_pct)||0;
    case 'source': return String([p.last_quote_provider||p.provider,p.market_symbol,p.isin,p.quote_quality].filter(Boolean).join(' ')).toLocaleLowerCase('fr');
    default: return 0;
  }
}
function positionRows(){
  const rows=[...(state?.positions||[])];
  if(positionView==='TOTAL')return rows;
  return rows.filter(p=>String(p.account||'').toUpperCase()===positionView);
}
function positionViewTotals(){
  const rows=positionRows();
  const value=rows.reduce((s,p)=>s+(Number(p.position_value)||0),0);
  const invested=rows.reduce((s,p)=>s+(Number(p.invested_estimate)||0),0);
  const pnl=invested?value-invested:0;
  const performance=invested?(value/invested-1)*100:0;
  const target=rows.reduce((s,p)=>s+(Number(p.target_pct)||0),0);
  return {rows,value,invested,pnl,performance,target};
}
function displayWeight(p){
  const total=positionViewTotals().value;
  return total?((Number(p.position_value)||0)/total*100):0;
}
function renderPositionViewSummary(){
  if(!state)return;
  const t=positionViewTotals();
  const label=positionView==='TOTAL'?'portefeuille global':positionView;
  document.querySelector('#positionViewValue').textContent=euro.format(t.value);
  document.querySelector('#positionViewInvested').textContent=euro.format(t.invested);
  const pnl=document.querySelector('#positionViewPnl');pnl.textContent=euro.format(t.pnl);pnl.className=perfClass(t.pnl);
  const perf=document.querySelector('#positionViewPerf');perf.textContent=fmtPct(t.performance);perf.className=perfClass(t.performance);
  const note=document.querySelector('#positionViewNote');if(note)note.textContent=`Vue ${label} · ${t.rows.length} ligne${t.rows.length>1?'s':''}. Le poids est recalculé dans cette vue.`;
  const ts=document.querySelector('#targetSummary');if(ts)ts.textContent=`Somme des poids cibles dans cette vue : ${t.target.toFixed(1)} %${positionView==='TOTAL'?(Math.abs(t.target-100)<0.05?' · allocation cible complète':' · à compléter'):''}`;
  document.querySelectorAll('[data-position-view]').forEach(btn=>btn.classList.toggle('active',btn.dataset.positionView===positionView));
}
function sortedPositions(){
  const rows=positionRows();
  if(!tableSort.key)return rows;
  const sign=tableSort.direction==='asc'?1:-1;
  return rows.sort((a,b)=>{
    const av=sortValue(a,tableSort.key),bv=sortValue(b,tableSort.key);
    if(typeof av==='string'||typeof bv==='string')return String(av).localeCompare(String(bv),'fr',{numeric:true,sensitivity:'base'})*sign;
    return (av-bv)*sign;
  });
}
function updateSortHeaders(){
  document.querySelectorAll('th[data-sort]').forEach(th=>{
    const active=th.dataset.sort===tableSort.key;
    th.setAttribute('aria-sort',active?(tableSort.direction==='asc'?'ascending':'descending'):'none');
    const icon=th.querySelector('.sortBtn span');
    if(icon)icon.textContent=active?(tableSort.direction==='asc'?'↑':'↓'):'↕';
  });
}
function initTableSorting(){
  document.querySelectorAll('th[data-sort] .sortBtn').forEach(btn=>{
    if(btn.dataset.bound==='1')return;
    btn.addEventListener('click',()=>{
      const key=btn.closest('th').dataset.sort;
      if(tableSort.key===key)tableSort.direction=tableSort.direction==='asc'?'desc':'asc';
      else tableSort={key,direction:'asc'};
      renderTable();
    });
    btn.dataset.bound='1';
  });
}
function renderTable(){
  const body=document.querySelector('#positionsBody');body.innerHTML='';
  for(const p of sortedPositions()){
    const tr=document.createElement('tr');tr.dataset.id=p.id;
    const isEod=String(p.quote_quality||'').toLowerCase().includes('clôture');
    const asof=p.price_updated_at?(isEod?`séance ${escapeHtml((p.quote_note||'').match(/\d{4}-\d{2}-\d{2}/)?.[0]||fmtTimestamp(p.price_updated_at))}`:`cours au ${escapeHtml(fmtTimestamp(p.price_updated_at))}`):'pas encore actualisé';
    const source=p.quote_configured
      ? `<button type="button" class="linkBtn" data-config-id="${p.id}">Configurer</button><br><span class="sourceTag">${escapeHtml(p.market_symbol)}</span><br><span class="muted">${escapeHtml([p.last_quote_provider||p.provider,p.exchange,p.quote_quality].filter(Boolean).join(' · '))}</span><br><span class="muted">${asof}</span>${p.quote_checked_at?`<br><span class="muted">Vérifié le ${escapeHtml(fmtTimestamp(p.quote_checked_at))}</span>`:''}${p.quote_stale?`<br><span class="quoteAgeWarning" title="${escapeHtml(p.quote_warning)}">Cours ancien · vérifier la source</span>`:''}`
      : `<button type="button" class="linkBtn" data-config-id="${p.id}">Configurer</button><br><span class="muted">Instrument non associé</span>`;
    tr.innerHTML=`<td><strong>${escapeHtml(p.name)}</strong><br><span class="muted">${escapeHtml(p.asset_type)}${p.transaction_count?` · ${p.transaction_count} op.`:''}</span><br><button type="button" class="miniTx" data-tx-id="${p.id}">+ transaction</button>${p.quote_configured?` <button type="button" class="miniTx quoteRefresh" data-refresh-id="${p.id}">Actualiser ce titre</button>`:''}</td>
      <td>${escapeHtml(p.account)}</td><td>${num.format(p.quantity)}</td>
      <td>${p.quote_configured?fmtNative(p):'<span class="muted">non connecté</span>'}</td>
      <td><strong>${euro.format(p.position_value)}</strong></td>
      <td><strong>${displayWeight(p).toFixed(2)} %</strong></td>
      <td>${fmtTarget(p.target_pct)}</td>
      <td class="${perfClass(p.performance_pct)}">${fmtPct(p.performance_pct)}</td>
      <td class="${perfClass(p.day_change_pct)}">${fmtPct(p.day_change_pct)}</td><td>${source}</td>`;
    tr.addEventListener('click',e=>{if(e.target.closest('.linkBtn,.miniTx,.quoteRefresh'))return;openEdit(p)});body.appendChild(tr);
  }
  body.querySelectorAll('[data-config-id]').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();const p=state.positions.find(x=>x.id===+btn.dataset.configId);openEdit(p)}));
  body.querySelectorAll('[data-tx-id]').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();openTransactions(+btn.dataset.txId)}));
  body.querySelectorAll('[data-refresh-id]').forEach(button=>button.addEventListener('click',event=>{event.stopPropagation();startQuoteRefresh({position_id:+button.dataset.refreshId});}));
  setQuoteBusy(quoteRefreshBusy);
  const totals=positionViewTotals();
  const weightTotal=totals.value>0?100:0;
  const targetTotal=totals.target;
  const weightEl=document.querySelector('#weightTotal'); if(weightEl) weightEl.innerHTML=`<strong>${weightTotal.toFixed(2)} %</strong>`;
  const targetEl=document.querySelector('#targetTotal'); if(targetEl) targetEl.innerHTML=`<strong>${targetTotal.toFixed(1)} %</strong>`;
  renderPositionViewSummary();
  updateSortHeaders();
  requestAnimationFrame(syncPositionScroll);
}


function positionLogoText(p){
  const n=String(p.name||'').toUpperCase();
  if(n.includes('S&P'))return 'S&P';
  if(n.includes('ROLLS'))return 'RR';
  if(n.includes('STOXX'))return 'STO';
  if(n.includes('XIAOMI'))return 'MI';
  if(n.includes('TOTALENERGIES'))return 'TE';
  if(n.includes('AIRLINES'))return 'H';
  if(n.includes('RUSSELL'))return 'R2K';
  if(n.includes('MSCI')||n.includes('GLOBAL'))return 'MSCI';
  return String(p.name||'PT').split(/\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase().slice(0,4);
}

function positionLocalLogo(p){
  const n=String(p.name||'').toUpperCase();
  if(n.includes('MSCI WORLD')&&!n.includes('ALL COUNTRY'))return '/static/logos/msci-world.png';
  if(n.includes('S&P 500'))return '/static/logos/sp500.png';
  if(n.includes('PEA GLOBAL'))return '/static/logos/pea-global.png';
  if(n.includes('MSCI ALL COUNTRY')||n.includes('ACWI'))return '/static/logos/acwi.png';
  if(n.includes('STOXX EUROPE 600 BANK'))return '/static/logos/stoxx-banks.png';
  if(n.includes('RUSSELL 2000'))return '/static/logos/russell2000.png';
  if(n.includes('AIRLINES')||n.includes('HOTELS')||n.includes('CRUISE'))return '/static/logos/travel.png';
  if(n.includes('PHYSICAL GOLD')||n.includes('ISHARES PHYSICAL GOLD'))return '/static/logos/gold.png';
  if(n.includes('ENHANCED COMMODITY')||n.includes('COMMODITY EX-AGRI'))return '/static/logos/commodities.png';
  return '';
}
function positionLogoDomain(p){
  const n=String(p.name||'').toUpperCase();
  if(n.includes('ROLLS'))return 'rolls-royce.com';
  if(n.includes('XIAOMI'))return 'mi.com';
  if(n.includes('TOTALENERGIES'))return 'totalenergies.com';
  return '';
}
function positionLogoMarkup(p){
  const fallback=escapeHtml(positionLogoText(p));
  const local=positionLocalLogo(p);
  const domain=positionLogoDomain(p);
  const src=local||(domain?`https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=256`:'');
  if(!src)return `<span class="logoFallback">${fallback}</span>`;
  return `<img src="${src}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><span class="logoFallback" style="display:none">${fallback}</span>`;
}
function dayValueChange(p){
  const current=Number(p.position_value)||0,pct=Number(p.day_change_pct);
  if(!Number.isFinite(pct)||Math.abs(100+pct)<1e-9)return null;
  const previous=current/(1+pct/100);
  return current-previous;
}
function positionMetricValue(p){
  if(positionMetric==='since_pct')return {value:Number(p.performance_pct),text:fmtPct(p.performance_pct)};
  if(positionMetric==='day_eur'){const v=dayValueChange(p);return {value:v,text:v==null?'—':`${v>=0?'+':''}${euro.format(v)}`};}
  if(positionMetric==='since_eur'){const v=(Number(p.position_value)||0)-(Number(p.invested_estimate)||0);return {value:v,text:`${v>=0?'+':''}${euro.format(v)}`};}
  return {value:Number(p.day_change_pct),text:fmtPct(p.day_change_pct)};
}
function positionSourceShort(p){
  if(p.manual_active)return `Manuel${p.manual_price_note?` · ${p.manual_price_note}`:''}`;
  return [p.last_quote_provider||p.provider,p.quote_quality].filter(Boolean).join(' · ')||'—';
}
function transactionTypeLabel(t){return ({buy:'Achat',sell:'Vente',dividend:'Dividende',fee:'Frais',deposit:'Versement',withdrawal:'Retrait',opening:'Solde initial'})[t]||t||'—';}
function transactionFrameworkLabel(t){return (t.investment_framework==='Autre'?(t.framework_label||'Autre'):(t.investment_framework||t.origin||''));}
function enableHistoryRowActions(container, selector){
  const rows=container.matches?.(selector)?[container]:Array.from(container.querySelectorAll(selector));
  for(const row of rows){
    const toggle=()=>{
      const next=!row.classList.contains('actionsVisible');
      const parent=row.parentElement;
      parent?.querySelectorAll('.expandableHistoryRow.actionsVisible').forEach(other=>{if(other!==row){other.classList.remove('actionsVisible');other.setAttribute('aria-expanded','false');}});
      row.classList.toggle('actionsVisible',next);
      row.setAttribute('aria-expanded',String(next));
    };
    row.addEventListener('click',event=>{if(event.target.closest('button,a,input,select,textarea'))return;toggle();});
    row.addEventListener('keydown',event=>{if(event.target!==row)return;if(event.key==='Enter'||event.key===' '){event.preventDefault();toggle();}});
  }
}
async function loadInlineHistory(positionId,box){
  if(!box||box.dataset.loaded==='1')return;
  box.innerHTML='<p class="muted">Chargement de l’historique…</p>';
  try{
    const r=await api(`/api/positions/${positionId}/ledger-history`);
    const tx=(r.transactions||[]).slice().sort((a,b)=>String(a.transaction_date||'').localeCompare(String(b.transaction_date||''))||(Number(a.id)||0)-(Number(b.id)||0));
    const rec=r.reconciliation||{};
    const rows=tx.length?tx.map(t=>{
      const type=t.transaction_type==='opening'?'Position initiale avant suivi':transactionTypeLabel(t.transaction_type), framework=transactionFrameworkLabel(t);
      let amount=Number(t.gross_amount_eur)||0;
      let detail='';
      if(t.transaction_type==='buy'||t.transaction_type==='sell'||t.transaction_type==='opening')detail=`${num.format(Math.abs(Number(t.quantity)||0))} × ${euro.format(Number(t.unit_price_eur)||0)}`;
      else detail=euro.format(amount);
      const openingAction=t.transaction_type==='opening'?`<button type="button" class="historyEditOpening" data-opening-id="${positionId}">Modifier / réconcilier</button>`:`<button type="button" class="historyEditTx" data-tx-id="${t.id}">Modifier</button> <button type="button" class="danger historyDeleteTx" data-tx-id="${t.id}">Supprimer</button>`;
      return `<div class="positionHistoryRow expandableHistoryRow ${t.transaction_type==='opening'?'openingRow':''}" tabindex="0" role="button" aria-expanded="false" aria-label="Afficher les actions de cette opération"><div><strong class="${t.transaction_type==='buy'?'good':t.transaction_type==='sell'?'bad':''}">${escapeHtml(type)}</strong><span>${escapeHtml(t.transaction_date==='1900-01-01'?'Avant suivi':t.transaction_date||'')}</span></div><div><b>${escapeHtml(framework||'Sans catégorie')}</b><span>${detail}</span>${openingAction}</div><div class="positionHistoryAmount">${euro.format(amount)}${Number(t.fees_eur)?`<small>frais ${euro.format(Number(t.fees_eur))}</small>`:''}</div></div>`;
    }).join(''):'<p class="muted">Aucun mouvement enregistré sur cette ligne.</p>';
    const chartId=`positionHistoryChart-${positionId}`;
    box.innerHTML=`<div class="positionHistoryChartBox"><div class="positionHistoryChartHead"><strong>Évolution de la position</strong><span>${escapeHtml(r.valuation_note||'')}</span></div><div class="chartWrap positionHistoryChart"><canvas id="${chartId}"></canvas></div></div><div class="positionHistoryList">${rows}</div><button type="button" class="danger historyDeletePosition">Supprimer ce titre et tout son historique</button>`;
    enableHistoryRowActions(box, '.expandableHistoryRow');
    box.querySelector('.historyEditOpening')?.addEventListener('click',()=>openOpeningDialog(positionId,r));
    box.querySelectorAll('.historyEditTx').forEach(b=>b.addEventListener('click',()=>{const t=tx.find(x=>x.id===Number(b.dataset.txId));if(t)editHistoryTransaction(t)}));
    box.querySelectorAll('.historyDeleteTx').forEach(b=>b.addEventListener('click',()=>{const t=tx.find(x=>x.id===Number(b.dataset.txId));if(t)deleteHistoryTransaction(t,positionId)}));
    box.querySelector('.historyDeletePosition')?.addEventListener('click',()=>deleteHistoryPosition(positionId));
    renderPositionLedgerChart(positionId,r.points||[],chartId);
    box.dataset.loaded='1';
  }catch(err){box.innerHTML=`<p class="status errorBox">${escapeHtml(err.message)}</p>`;}
}
function renderPositionLedgerChart(positionId,points,chartId){
  const canvas=document.getElementById(chartId);if(!canvas||typeof Chart==='undefined'||!points.length)return;
  const old=positionHistoryCharts.get(positionId);if(old)old.destroy();
  const labels=points.map(p=>p.type==='current'?'Aujourd’hui':(p.date==='1900-01-01'?'Initial':p.date));
  const chart=new Chart(canvas,{type:'line',data:{labels,datasets:[{label:'Valeur reconstituée',data:points.map(p=>p.position_value_after),borderColor:'#087cff',backgroundColor:'rgba(8,124,255,.08)',fill:true,tension:.18,pointRadius:3},{label:'Capital investi',data:points.map(p=>p.cost_basis_after),borderColor:'#00b956',borderDash:[5,4],tension:.18,pointRadius:2}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${euro.format(c.raw)}`}}},scales:{x:{ticks:{maxTicksLimit:7}},y:{ticks:{callback:v=>new Intl.NumberFormat('fr-FR',{notation:'compact'}).format(v)+' €'}}}}});
  positionHistoryCharts.set(positionId,chart);
}
let editingTransactionId=null;
async function deleteHistoryTransaction(t, positionId){
  if(!confirm('Supprimer définitivement cette opération ? La position sera recalculée.'))return;
  try{await api(`/api/transactions/${t.id}`,{method:'DELETE'});await load();renderPositionCards();}
  catch(err){alert(err.message)}
}
async function deleteHistoryPosition(positionId){
  const p=state.positions.find(x=>x.id===positionId);if(!p)return;
  if(!confirm(`Supprimer définitivement « ${p.name} » et TOUT son historique de transactions ?\n\nCette opération ne touche pas à Trade Republic.`))return;
  if(!confirm('Dernière confirmation : cette suppression est irréversible sans restauration de sauvegarde.'))return;
  try{await api(`/api/positions/${positionId}`,{method:'DELETE'});await load();renderPositionCards();}
  catch(err){alert(err.message)}
}
async function editHistoryTransaction(t){
  activateTab('transactions');
  transactionFilterPositionId=t.position_id;
  fillTxPositions(t.position_id);
  document.querySelector('#txPosition').value=String(t.position_id);
  document.querySelector('#txPosition').disabled=true;
  document.querySelector('#txType').value=t.transaction_type;
  document.querySelector('#txDate').value=t.transaction_date;
  document.querySelector('#txOrigin').value=t.investment_framework||'Investissement libre';
  document.querySelector('#txCustom').value=t.framework_label||'';
  document.querySelector('#txQty').value=t.quantity??'';
  document.querySelector('#txUnitPrice').value=t.unit_price_eur??'';
  document.querySelector('#txAmount').value=t.gross_amount_eur??'';
  document.querySelector('#txFees').value=t.fees_eur??0;
  document.querySelector('#txNote').value=t.note||'';
  editingTransactionId=t.id;
  document.querySelector('#saveTransactionBtn').textContent='Enregistrer les modifications';
  document.querySelector('#txStatus').textContent='Modification de l’opération sélectionnée';
  syncTxAccount();updateTxFields();await loadTransactions(t.position_id);
}
function resetTransactionEditing(){editingTransactionId=null;document.querySelector('#txPosition').disabled=false;document.querySelector('#saveTransactionBtn').textContent='Enregistrer la transaction'}
let openingContext=null;
function openingRecText(rec){
  if(!rec)return '';
  const gap=Number(rec.quantity_gap)||0;
  const err=(rec.history_only_errors||[])[0];
  if(err)return `<strong>Historique incomplet/incompatible.</strong><br>${escapeHtml(err)}`;
  if(Math.abs(gap)<1e-7)return `<strong class="good">Historique cohérent.</strong><br>Les mouvements antérieurs au début du suivi reconstituent exactement la position initiale (${num.format(rec.opening_quantity||0)} titre(s)). Elle peut être remplacée par l’historique.`;
  return `<strong>Écart restant : ${num.format(gap)} titre(s).</strong><br>Position initiale : ${num.format(rec.opening_quantity||0)} · historique antérieur au ${escapeHtml(rec.tracking_start_date||'début du suivi')} : ${num.format(rec.history_before_tracking_quantity||0)}. Continue à saisir les anciens mouvements ou réduis la position initiale.`;
}
function openOpeningDialog(positionId,ledgerData){
  const rec=ledgerData?.reconciliation||{};const op=rec.opening;if(!op)return;
  openingContext={positionId,ledgerData};
  document.querySelector('#openingPositionId').value=positionId;
  document.querySelector('#openingQty').value=Number(op.quantity)||0;
  document.querySelector('#openingPru').value=Number(op.unit_price_eur)||0;
  document.querySelector('#openingReconciliation').innerHTML=openingRecText(rec);
  document.querySelector('#openingStatus').textContent='';
  document.querySelector('#replaceOpeningBtn').disabled=!rec.can_replace_opening;
  document.querySelector('#openingDialog').showModal();
}
async function refreshOpeningContext(){
  if(!openingContext)return;
  const r=await api(`/api/positions/${openingContext.positionId}/ledger-history`);openingContext.ledgerData=r;
  document.querySelector('#openingReconciliation').innerHTML=openingRecText(r.reconciliation);
  document.querySelector('#replaceOpeningBtn').disabled=!r.reconciliation?.can_replace_opening;
}

const SECURITY_PERIODS=[['1J','1J'],['1S','1S'],['1M','1M'],['3M','3M'],['6M','6M'],['1A','1A'],['MAX','MAX'],['ACHAT','Depuis achat']];
const securitySelection=new Map();
async function loadSecurityHistory(id,card,period){
  const area=card.querySelector('[data-security-content]');if(!area)return;
  area.innerHTML='<p class="muted">Chargement des cours historiques…</p>';
  try{
    const data=await api(`/api/positions/${id}/security-history?period=${encodeURIComponent(period)}`);
    if(!card.isConnected)return;
    if(!data.points?.length||data.performance_pct===undefined){area.innerHTML=`<p class="muted">${escapeHtml(data.reason||'Données historiques insuffisantes')}</p>`;return;}
    const points=data.points,values=points.map(x=>x.price),min=Math.min(...values),max=Math.max(...values),range=max-min||1;
    const w=620,h=200,pad=15;
    const xy=points.map((x,i)=>[pad+i*(w-2*pad)/Math.max(1,points.length-1),h-pad-(x.price-min)/range*(h-2*pad)]);
    const line=xy.map(([x,y],i)=>`${i?'L':'M'}${x.toFixed(2)},${y.toFixed(2)}`).join(' ');
    const areaPath=`${line} L${xy[xy.length-1][0].toFixed(2)},${h-pad} L${pad},${h-pad} Z`;
    const color=data.performance_pct>=0?'#16a36b':'#dc4c5b';
    area.innerHTML=`<div class="securityChartTop"><div><span>Performance du titre</span><strong class="${perfClass(data.performance_pct)}">${fmtPct(data.performance_pct)}</strong></div><small>${escapeHtml(data.currency)} · ${escapeHtml(data.source)} · au ${escapeHtml(data.as_of)}</small></div><svg class="securityChart" viewBox="0 0 ${w} ${h}" role="img" aria-label="Évolution du cours du ${escapeHtml(points[0].date)} au ${escapeHtml(data.as_of)}"><defs><linearGradient id="securityFill${id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="${color}" stop-opacity=".18"/><stop offset="100%" stop-color="${color}" stop-opacity="0"/></linearGradient></defs><path d="${areaPath}" fill="url(#securityFill${id})"/><path d="${line}" stroke="${color}" stroke-width="2.8" stroke-linejoin="round" stroke-linecap="round" fill="none"/></svg><div class="securityChartAxis"><span>${escapeHtml(points[0].date)}</span><span>${escapeHtml(data.as_of)}</span></div><div class="securityChartValues"><span>${fmtCurrencyValue(points[0].price,data.currency)}</span><span>${fmtCurrencyValue(points[points.length-1].price,data.currency)}</span></div>${data.warning?`<p class="muted">Dernière récupération impossible : historique en cache affiché.</p>`:''}`;
  }catch(err){area.innerHTML=`<p class="muted">Historique indisponible : ${escapeHtml(err.message)}</p>`;}
}
function bindSecurityCard(id,card){
  card.querySelectorAll('[data-security-period]').forEach(btn=>btn.addEventListener('click',()=>{
    const period=btn.dataset.securityPeriod;securitySelection.set(id,period);
    card.querySelectorAll('[data-security-period]').forEach(b=>{b.classList.toggle('selected',b===btn);b.setAttribute('aria-pressed',String(b===btn));});
    loadSecurityHistory(id,card,period);
  }));
  loadSecurityHistory(id,card,securitySelection.get(id)||'1A');
}

function renderPositionCards(){
  const host=document.querySelector('#positionCards');if(!host||!state)return;
  const rows=positionRows();
  const selector=document.querySelector('#positionMetricSelect');if(selector&&selector.value!==positionMetric)selector.value=positionMetric;
  host.innerHTML='';
  if(!rows.length){host.innerHTML='<p class="muted">Aucune position dans cette vue.</p>';return;}
  for(const p of rows){
    const metric=positionMetricValue(p),isOpen=expandedPositionIds.has(+p.id);
    const card=document.createElement('article');card.className=`positionCard${isOpen?' open':''}`;card.dataset.positionCard=p.id;
    const latent=(Number(p.position_value)||0)-(Number(p.invested_estimate)||0);
    card.innerHTML=`
      <button type="button" class="positionCardSummary" aria-expanded="${isOpen?'true':'false'}">
        <span class="positionLogo">${positionLogoMarkup(p)}</span>
        <span class="positionIdentity"><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.asset_type||'')} · ${escapeHtml(p.account||'')}</small></span><span class="positionInlineScroll"><span class="positionInlineData"><span>${num.format(Number(p.last_price_eur)||0)} <i>|</i></span><span>${num.format(Number(p.quantity)||0)} <i>|</i></span><span>${euro.format(Number(p.position_value)||0)} <i>|</i></span></span></span>
        <span class="positionMetric ${perfClass(metric.value)}">${escapeHtml(metric.text)}</span>
      </button>
      <div class="positionCardDetail" ${isOpen?'':'hidden'}>
        <div class="positionDetailGrid">
          <div><span>Compte</span><strong>${escapeHtml(p.account||'—')}</strong></div>
          <div><span>PRU</span><strong>${p.avg_cost_eur==null?'—':euro.format(Number(p.avg_cost_eur))}</strong></div>
          <div><span>Performance</span><strong class="${perfClass(p.performance_pct)}">${fmtPct(p.performance_pct)}</strong></div>
          <div><span>+/- value</span><strong class="${perfClass(latent)}">${euro.format(latent)}</strong></div>
          <div><span>Poids cible</span><span class="positionTargetRow"><strong>${fmtTarget(p.target_pct)}</strong><button type="button" class="targetPencil" data-edit-target="${p.id}" aria-label="Modifier le poids cible de ${escapeHtml(p.name)}" title="Modifier le poids cible">✎</button></span><form class="positionTargetForm" data-target-form="${p.id}" hidden><input type="number" min="0" max="100" step="0.01" value="${Number(p.target_pct)||0}" aria-label="Nouveau poids cible en pourcentage" required><button type="submit">OK</button><button type="button" class="secondary" data-target-cancel="${p.id}" aria-label="Annuler">×</button><small class="targetFeedback" aria-live="polite"></small></form></div>
          <div><span>Poids actuel</span><strong>${displayWeight(p).toFixed(2)} %</strong></div>
          <div><span>Source</span><strong>${escapeHtml(positionSourceShort(p))}</strong></div>
          <div><span>Dernier cours</span><strong>${escapeHtml(fmtTimestamp(p.price_updated_at))}</strong></div>
          <div><span>Place</span><strong>${escapeHtml(p.exchange||'—')}</strong></div>
          <div><span>ISIN</span><strong>${escapeHtml(p.isin||'—')}</strong></div>
        </div>
        <section class="securityPerformance"><div class="securityPerformanceHeader"><h3>Performance du titre</h3><p>Évolution du cours, indépendamment de tes achats</p></div><div class="securityPeriodSelector" role="group" aria-label="Période du graphique">${SECURITY_PERIODS.map(([value,label])=>`<button type="button" data-security-period="${value}" aria-pressed="${(securitySelection.get(+p.id)||'1A')===value}" class="${(securitySelection.get(+p.id)||'1A')===value?'selected':''}">${label}</button>`).join('')}</div><div data-security-content aria-live="polite"></div></section>
        <div class="positionDetailActions"><button type="button" data-card-tx="${p.id}">+ Transaction</button><button type="button" class="secondary" data-card-edit="${p.id}">Modifier</button></div>
        <section class="positionHistory"><div class="positionHistoryHead"><h3>Historique des mouvements</h3><span class="muted">Achats, ventes et cadre d’investissement</span></div><div class="positionHistoryBody" data-history-for="${p.id}"></div></section>
      </div>`;
    host.appendChild(card);
    const summary=card.querySelector('.positionCardSummary');
    summary.addEventListener('click',()=>{
      const id=+p.id;
      const wasOpen=expandedPositionIds.has(id);
      expandedPositionIds.clear();
      if(!wasOpen)expandedPositionIds.add(id);
      renderPositionCards();
    });
    const targetForm=card.querySelector('[data-target-form]');
    card.querySelector('[data-edit-target]')?.addEventListener('click',()=>{targetForm.hidden=!targetForm.hidden;if(!targetForm.hidden)targetForm.querySelector('input').focus();});
    card.querySelector('[data-target-cancel]')?.addEventListener('click',()=>{targetForm.hidden=true;});
    targetForm?.addEventListener('submit',async ev=>{ev.preventDefault();const input=targetForm.querySelector('input');const value=Number(input.value);const feedback=targetForm.querySelector('.targetFeedback');if(!Number.isFinite(value)||value<0||value>100){feedback.textContent='Saisis une cible entre 0 et 100 %.';return;}try{await api(`/api/positions/${p.id}`,{method:'PATCH',body:JSON.stringify({target_pct:value})});await load();const sum=(state.positions||[]).reduce((total,x)=>total+(Number(x.target_pct)||0),0);if(Math.abs(sum-100)>0.01)alert(`Cible enregistrée. Total des cibles : ${sum.toFixed(2)} % (différent de 100 %).`);}catch(err){feedback.textContent=err.message;}});
    card.querySelector('[data-card-tx]')?.addEventListener('click',()=>openTransactions(p.id));
    card.querySelector('[data-card-refresh]')?.addEventListener('click',()=>startQuoteRefresh({position_id:+p.id}));
    card.querySelector('[data-card-edit]')?.addEventListener('click',()=>openEdit(p));
    if(isOpen){loadInlineHistory(p.id,card.querySelector(`[data-history-for="${p.id}"]`));bindSecurityCard(+p.id,card);}
  }
}
function initPositionCards(){
  const select=document.querySelector('#positionMetricSelect');if(!select||select.dataset.bound==='1')return;
  select.value=positionMetric;select.addEventListener('change',()=>{positionMetric=select.value;localStorage.setItem('portfolioPositionMetric',positionMetric);renderPositionCards();});select.dataset.bound='1';
}

function renderChart(){
  const canvas=document.querySelector('#allocationChart');if(typeof Chart==='undefined'||!canvas||!state)return;const data=state.positions.slice(0,16);if(allocationChart)allocationChart.destroy();
  allocationChart=new Chart(canvas,{type:'doughnut',data:{labels:data.map(x=>x.name),datasets:[{data:data.map(x=>x.position_value)}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{boxWidth:12,usePointStyle:true}},tooltip:{callbacks:{label:c=>`${c.label}: ${euro.format(c.raw)}`}}}}});
}

function renderOverviewVisuals(){
  if(!state||!analyticsState)return;
  const canvas=document.querySelector('#overviewPortfolioChart');
  const cats=Object.entries(analyticsState.risk?.categories||{}).filter(([,v])=>Number(v)>0);
  if(canvas&&typeof Chart!=='undefined'){
    if(overviewPortfolioChart)overviewPortfolioChart.destroy();
    overviewPortfolioChart=new Chart(canvas,{type:'doughnut',data:{labels:cats.map(x=>x[0]),datasets:[{data:cats.map(x=>x[1])}]},options:{responsive:true,maintainAspectRatio:false,cutout:'62%',plugins:{legend:{position:'bottom',labels:{boxWidth:10,usePointStyle:true}},tooltip:{callbacks:{label:c=>`${c.label}: ${Number(c.raw).toFixed(1)} %`}}}}});
  }
  const box=document.querySelector('#accountOverview');
  if(box){
    const total=Number(state.total_value)||0;
    const accounts=['PEA','CTO'].map(account=>{
      const rows=(state.positions||[]).filter(p=>String(p.account||'').toUpperCase()===account);
      const value=rows.reduce((s,p)=>s+(Number(p.position_value)||0),0);
      const pct=total?value/total*100:0;
      return {account,value,pct,count:rows.length};
    });
    box.innerHTML=accounts.map(a=>`<div class="accountCard"><div><span>${a.account}</span><strong>${euro.format(a.value)}</strong><small>${a.count} ligne${a.count>1?'s':''} · ${a.pct.toFixed(1)} %</small></div><div class="accountBar"><i style="width:${Math.max(0,Math.min(100,a.pct))}%"></i></div></div>`).join('');
  }
}


function projectionSettings(){
  const savedMonthly=Number(localStorage.getItem('portfolioProjectionMonthly'));
  const savedReturn=Number(localStorage.getItem('portfolioProjectionReturn'));
  return {
    monthly:Number.isFinite(savedMonthly)&&savedMonthly>=0?savedMonthly:Math.max(0,Number(state?.monthly_plan)||0),
    annualReturn:Number.isFinite(savedReturn)?savedReturn:6
  };
}
function projectionFutureValueMonths(current,monthly,annualRate,months){
  const monthlyRate=annualRate/100/12;
  if(Math.abs(monthlyRate)<1e-12)return current+monthly*months;
  const growth=Math.pow(1+monthlyRate,months);
  return current*growth+monthly*((growth-1)/monthlyRate);
}
function projectionFutureValue(current,monthly,annualRate,years){
  return projectionFutureValueMonths(current,monthly,annualRate,Math.round(years*12));
}
function projectionSeries(current,monthly,annualRate,years){
  const months=Math.round(years*12);
  const labels=[];const bare=[];const projected=[];
  for(let m=0;m<=months;m++){
    labels.push(m===0?'Départ':m%12===0?`${m/12} an${m>12?'s':''}`:`M${m}`);
    bare.push(current+monthly*m);
    projected.push(projectionFutureValueMonths(current,monthly,annualRate,m));
  }
  return {labels,bare,projected};
}
function destroyProjectionCharts(){
  for(const chart of projectionCharts){try{chart.destroy()}catch{}}
  projectionCharts=[];
}
function renderProjectionChart(canvas,current,monthly,annualReturn,years){
  if(typeof Chart==='undefined'||!canvas)return;
  const series=projectionSeries(current,monthly,annualReturn,years);
  const chart=new Chart(canvas,{
    type:'line',
    data:{labels:series.labels,datasets:[
      {label:'Capital sans rendement',data:series.bare,borderColor:'#737986',backgroundColor:'rgba(115,121,134,.10)',borderWidth:2,pointRadius:0,tension:.18},
      {label:'Valeur projetée',data:series.projected,borderColor:'#00b956',backgroundColor:'rgba(0,185,86,.10)',borderWidth:2,pointRadius:0,tension:.18}
    ]},
    options:{
      responsive:true,maintainAspectRatio:false,animation:false,interaction:{mode:'index',intersect:false},
      scales:{
        x:{grid:{display:false},ticks:{maxTicksLimit:4,font:{size:9},color:'#7a808c'}},
        y:{grid:{color:'rgba(0,0,0,.055)'},ticks:{maxTicksLimit:4,font:{size:9},color:'#7a808c',callback:v=>new Intl.NumberFormat('fr-FR',{notation:'compact',maximumFractionDigits:1}).format(v)+' €'}}
      },
      plugins:{
        legend:{display:true,position:'bottom',labels:{boxWidth:8,usePointStyle:true,font:{size:9}}},
        tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${euro.format(c.raw)}`}}
      }
    }
  });
  projectionCharts.push(chart);
}
function renderProjection(){
  const monthlyInput=document.querySelector('#projectionMonthly');
  const returnInput=document.querySelector('#projectionReturn');
  const cards=document.querySelector('#projectionCards');
  const summary=document.querySelector('#projectionSummary');
  if(!monthlyInput||!returnInput||!cards||!summary||!state)return;
  const defaults=projectionSettings();
  if(document.activeElement!==monthlyInput && monthlyInput.dataset.ready!=='1') monthlyInput.value=defaults.monthly;
  if(document.activeElement!==returnInput && returnInput.dataset.ready!=='1') returnInput.value=defaults.annualReturn;
  monthlyInput.dataset.ready='1';returnInput.dataset.ready='1';
  const monthly=Math.max(0,Number(monthlyInput.value)||0);
  const annualReturn=Math.max(-50,Math.min(50,Number(returnInput.value)||0));
  localStorage.setItem('portfolioProjectionMonthly',String(monthly));
  localStorage.setItem('portfolioProjectionReturn',String(annualReturn));
  const current=Math.max(0,Number(state.total_value)||0);
  const horizons=[1,2,5,10];
  destroyProjectionCharts();
  cards.innerHTML='';
  for(const years of horizons){
    const months=years*12;
    const contributions=monthly*months;
    const bareCapital=current+contributions;
    const projected=projectionFutureValue(current,monthly,annualReturn,years);
    const growth=projected-bareCapital;
    const card=document.createElement('article');
    card.className='projectionCard';
    const canvasId=`projectionChart${years}`;
    card.innerHTML=`<div class="projectionYears">Dans ${years} an${years>1?'s':''}</div>
      <strong>${euro.format(projected)}</strong>
      <div class="projectionBreakdown"><span>Capital sans rendement <b>${euro.format(bareCapital)}</b></span><span>Croissance estimée <b class="${perfClass(growth)}">${euro.format(growth)}</b></span></div>
      <div class="projectionMiniChart"><canvas id="${canvasId}" aria-label="Projection à ${years} an${years>1?'s':''}"></canvas></div>`;
    cards.appendChild(card);
    renderProjectionChart(card.querySelector('canvas'),current,monthly,annualReturn,years);
  }
  const ten=projectionFutureValue(current,monthly,annualReturn,10);
  const deposits=monthly*120;
  const growth=ten-current-deposits;
  summary.innerHTML=`Avec <strong>${euro.format(monthly)}/mois</strong> et une hypothèse de <strong>${annualReturn.toFixed(1)} %/an</strong>, ton portefeuille actuel de <strong>${euro.format(current)}</strong> atteindrait environ <strong>${euro.format(ten)}</strong> dans 10 ans, dont <strong>${euro.format(growth)}</strong> de croissance théorique au-delà de ton capital actuel et de tes nouveaux versements.`;
}
function initProjectionControls(){
  const monthly=document.querySelector('#projectionMonthly');
  const annual=document.querySelector('#projectionReturn');
  if(!monthly||!annual||monthly.dataset.bound==='1')return;
  const redraw=()=>renderProjection();
  monthly.addEventListener('input',redraw);annual.addEventListener('input',redraw);
  monthly.addEventListener('change',redraw);annual.addEventListener('change',redraw);
  monthly.dataset.bound='1';annual.dataset.bound='1';
}

function openEdit(p){
  document.querySelector('#editId').value=p.id;document.querySelector('#editAccount').value=p.account;document.querySelector('#editQty').value=p.quantity;
  document.querySelector('#editPru').value=p.avg_cost_eur??'';document.querySelector('#editTarget').value=p.target_pct||0;
  const qtyEl=document.querySelector('#editQty'),pruEl=document.querySelector('#editPru'),ledgerHint=document.querySelector('#editLedgerHint');
  qtyEl.disabled=!!p.has_transactions;pruEl.disabled=!!p.has_transactions;
  ledgerHint.textContent=p.has_transactions?'Quantité et PRU sont désormais calculés par le journal de transactions. Utilise « Ajouter une transaction » pour les faire évoluer.':'Quantité et PRU peuvent encore être corrigés manuellement avant la première transaction enregistrée.';
  document.querySelector('#editWeight').textContent=`Poids actuel : ${p.weight_pct.toFixed(2)} % · Cible : ${fmtTarget(p.target_pct)}${p.has_transactions?` · Réalisé : ${euro.format(p.realized_pnl_eur||0)} · Dividendes : ${euro.format(p.dividends_eur||0)}`:''}`;
  document.querySelector('#currentMarket').textContent=p.quote_configured?marketLabel(p):'Non associé';
  const status=document.querySelector('#tickerStatus');status.textContent=p.quote_note||'';status.className='status';
  document.querySelector('#manualPrice').value=p.manual_active?(p.manual_price??p.last_price_eur??''):'';
  document.querySelector('#manualPriceNote').value=p.manual_price_note||'';
  const manualStatus=document.querySelector('#manualPriceStatus');manualStatus.textContent=p.manual_active?`Cours manuel actif${p.manual_price_at?` depuis ${fmtTimestamp(p.manual_price_at)}`:''}. Cours automatique mémorisé : ${euro.format(p.auto_last_price_eur||0)}.`:'Mode automatique actif.';
  document.querySelector('#clearManualPriceBtn').disabled=!p.manual_active;
  document.querySelector('#editDialog').showModal();
}

document.querySelector('#editForm').addEventListener('submit',async e=>{
  e.preventDefault();const id=+document.querySelector('#editId').value;const p=state.positions.find(x=>x.id===id);const pru=document.querySelector('#editPru').value;
  const payload={account:document.querySelector('#editAccount').value,target_pct:+document.querySelector('#editTarget').value};
  if(!p?.has_transactions){payload.quantity=+document.querySelector('#editQty').value;payload.avg_cost_eur=pru===''?null:+pru}
  try{await api(`/api/positions/${id}`,{method:'PATCH',body:JSON.stringify(payload)});document.querySelector('#editDialog').close();await load()}catch(err){setTickerStatus(err.message,false)}
});
document.querySelector('#deletePositionBtn').addEventListener('click',async()=>{
  const id=+document.querySelector('#editId').value;const p=state.positions.find(x=>x.id===id);if(!p)return;
  if(!confirm(`Supprimer définitivement la ligne « ${p.name} » ?\n\nCette action supprime uniquement la ligne dans Portfolio Tracker. Elle ne touche évidemment pas à Trade Republic.`))return;
  try{await api(`/api/positions/${id}`,{method:'DELETE'});document.querySelector('#editDialog').close();await load()}catch(err){setTickerStatus(err.message,false)}
});
function setTickerStatus(msg,ok){const el=document.querySelector('#tickerStatus');el.textContent=msg;el.className=`status ${ok?'okBox':'errorBox'}`}

document.querySelector('#searchTickerBtn').addEventListener('click',()=>{const id=+document.querySelector('#editId').value;const p=state.positions.find(x=>x.id===id);openSearch({mode:'edit',positionId:id,query:p?.isin||p?.name||''})});
document.querySelector('#addTransactionFromPositionBtn').addEventListener('click',()=>{const id=+document.querySelector('#editId').value;document.querySelector('#editDialog').close();openTransactions(id)});
document.querySelector('#setManualPriceBtn').addEventListener('click',async()=>{const id=+document.querySelector('#editId').value;const price=Number(document.querySelector('#manualPrice').value);const note=document.querySelector('#manualPriceNote').value.trim();const st=document.querySelector('#manualPriceStatus');if(!price||price<=0){st.textContent='Renseigne un cours EUR positif.';return}try{await api(`/api/positions/${id}/manual-price`,{method:'POST',body:JSON.stringify({price_eur:price,note})});await load();const p=state.positions.find(x=>x.id===id);st.textContent=`Cours manuel actif : ${euro.format(p.last_price_eur)}.`;document.querySelector('#clearManualPriceBtn').disabled=false;document.querySelector('#currentMarket').textContent=marketLabel(p)}catch(err){st.textContent=err.message}});
document.querySelector('#clearManualPriceBtn').addEventListener('click',async()=>{const id=+document.querySelector('#editId').value;const st=document.querySelector('#manualPriceStatus');try{await api(`/api/positions/${id}/manual-price`,{method:'DELETE'});await load();const p=state.positions.find(x=>x.id===id);st.textContent='Cours automatique réactivé.';document.querySelector('#manualPrice').value='';document.querySelector('#manualPriceNote').value='';document.querySelector('#clearManualPriceBtn').disabled=true;document.querySelector('#currentMarket').textContent=p.quote_configured?marketLabel(p):'Non associé'}catch(err){st.textContent=err.message}});

function openSearch(ctx){searchContext=ctx;document.querySelector('#marketQuery').value=ctx.query||'';document.querySelector('#searchResults').innerHTML='';document.querySelector('#searchStatus').textContent='';document.querySelector('#searchDialog').showModal();if(ctx.query)searchMarket()}
document.querySelector('#marketSearchBtn').addEventListener('click',searchMarket);document.querySelector('#marketQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchMarket()}});
async function searchMarket(){
  const q=document.querySelector('#marketQuery').value.trim();if(!q)return;const status=document.querySelector('#searchStatus'),box=document.querySelector('#searchResults');status.textContent='Recherche EODHD…';box.innerHTML='';
  try{const r=await api(`/api/market/search?q=${encodeURIComponent(q)}`);status.textContent=r.results.length?`${r.results.length} résultat(s)`:'Aucun résultat';for(const item of r.results){const el=document.createElement('button');el.type='button';el.className='searchItem';const primary=item.is_primary?' · principal':'';el.innerHTML=`<span><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.symbol)} · ${escapeHtml(item.currency)} · ${escapeHtml(item.exchange)}${primary}<br>${escapeHtml(item.isin||'ISIN non fourni')}</small></span><span>Choisir</span>`;el.addEventListener('click',()=>selectSearchResult(item));box.appendChild(el)}}catch(err){status.textContent=err.message;status.className='status errorBox'}
}
async function selectSearchResult(item){
  if(searchContext?.mode==='edit'){
    const id=searchContext.positionId;document.querySelector('#searchStatus').textContent='Association…';
    try{const linked=await api(`/api/positions/${id}/market-link`,{method:'POST',body:JSON.stringify({market_symbol:item.symbol,provider:'eodhd',exchange:item.exchange||'',currency:item.currency||'EUR',isin:item.isin||''})});document.querySelector('#searchDialog').close();await load();const p=state.positions.find(x=>x.id===id);document.querySelector('#currentMarket').textContent=marketLabel(p);setTickerStatus('Instrument associé. Le cours sera récupéré lors de la prochaine actualisation manuelle.',true)}catch(err){document.querySelector('#searchStatus').textContent=err.message;document.querySelector('#searchStatus').className='status errorBox'}
  }else{
    selectedAddInstrument=item;document.querySelector('#addMarketSelection').textContent=`${item.name} · ${item.symbol} · ${item.currency} · ${item.isin||'sans ISIN'}`;document.querySelector('#addTickerStatus').textContent='Instrument sélectionné.';document.querySelector('#searchDialog').close();
  }
}

// Ajout
document.querySelector('#exportExcelBtn').addEventListener('click',()=>{window.location.href=`/api/export/positions.xlsx?t=${Date.now()}`});
document.querySelector('#exportHistoryExcelBtn')?.addEventListener('click',()=>{window.location.href=`/api/export/history.xlsx?t=${Date.now()}`});
document.querySelector('#addBtn').addEventListener('click',()=>{document.querySelector('#addForm').reset();document.querySelector('#addType').value='ETF';document.querySelector('#addTarget').value='0';selectedAddInstrument=null;document.querySelector('#addMarketSelection').textContent='Aucun instrument sélectionné';document.querySelector('#addTickerStatus').textContent='';document.querySelector('#addDialog').showModal()});
document.querySelector('#searchAddInstrumentBtn').addEventListener('click',()=>openSearch({mode:'add',query:document.querySelector('#addName').value.trim()}));
document.querySelector('#addForm').addEventListener('submit',async e=>{e.preventDefault();if(!selectedAddInstrument){const el=document.querySelector('#addTickerStatus');el.textContent='Sélectionne d’abord un instrument de marché.';el.className='status errorBox';return}const pru=document.querySelector('#addPru').value;try{await api('/api/positions',{method:'POST',body:JSON.stringify({name:document.querySelector('#addName').value.trim(),asset_type:document.querySelector('#addType').value.trim(),account:document.querySelector('#addAccount').value,quantity:+document.querySelector('#addQty').value,avg_cost_eur:pru===''?null:+pru,market_symbol:selectedAddInstrument.symbol,provider:'eodhd',exchange:selectedAddInstrument.exchange||'',currency:selectedAddInstrument.currency||'EUR',isin:selectedAddInstrument.isin||'',target_pct:+document.querySelector('#addTarget').value||0})});document.querySelector('#addDialog').close();await load()}catch(err){const el=document.querySelector('#addTickerStatus');el.textContent=err.message;el.className='status errorBox'}});

// Transactions
function localIsoDate(){const d=new Date();const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
const txLabels={opening:'Solde initial',buy:'Achat',sell:'Vente',dividend:'Dividende',fee:'Frais'};
function fillTxPositions(selectedId){const sel=document.querySelector('#txPosition');sel.innerHTML='';for(const p of state.positions){const o=document.createElement('option');o.value=p.id;o.textContent=`${p.name} · ${p.account}`;if(+p.id===+selectedId)o.selected=true;sel.appendChild(o)}}
function updateTxFields(){const typ=document.querySelector('#txType').value;const trade=typ==='buy'||typ==='sell';const originLabel=document.querySelector('#txOriginLabel');if(originLabel)originLabel.style.display='grid';updateFrameworkFields();document.querySelectorAll('.tradeField').forEach(el=>el.style.display=trade?'grid':'none');document.querySelector('#txFeesLabel').style.display=trade?'grid':'none';document.querySelector('#txTradeHint').textContent=trade?'Pour un achat ou une vente, renseigne au moins 2 valeurs parmi quantité, prix unitaire et montant. L’application calcule la troisième.':typ==='dividend'?'Saisis le montant net du dividende reçu en EUR.':'Saisis le montant du frais en EUR.'}
async function openTransactions(positionId=null){resetTransactionEditing();transactionFilterPositionId=positionId;fillTxPositions(positionId||state.positions[0]?.id);document.querySelector('#txType').value='buy';document.querySelector('#txDate').value=localIsoDate();document.querySelector('#txOrigin').value='';document.querySelector('#txCustom').value='';syncTxAccount();document.querySelector('#txQty').value='';document.querySelector('#txUnitPrice').value='';document.querySelector('#txAmount').value='';document.querySelector('#txFees').value='0';document.querySelector('#txNote').value='';document.querySelector('#txStatus').textContent='';updateTxFields();activateTab('transactions');await loadTransactions(positionId)}
async function loadTransactions(positionId=null){const url=positionId?`/api/transactions?position_id=${positionId}&limit=100`:'/api/transactions?limit=200';const r=await api(url);const box=document.querySelector('#txHistory');box.innerHTML='';const visible=r.transactions.filter(t=>{const q=(document.querySelector('#txSearch')?.value||'').toLowerCase();const type=document.querySelector('#txFilterType')?.value||'';const account=document.querySelector('#txFilterAccount')?.value||'';const from=document.querySelector('#txFilterFrom')?.value||'';const to=document.querySelector('#txFilterTo')?.value||'';const framework=document.querySelector('#txFilterFramework')?.value||'';const actualFramework=(t.investment_framework||t.origin||'').trim();return (!q||String(t.position_name||'').toLowerCase().includes(q))&&(!type||t.transaction_type===type)&&(!account||String(t.account||state.positions.find(p=>p.id===t.position_id)?.account||'')===account)&&(!from||t.transaction_date>=from)&&(!to||t.transaction_date<=to)&&(!framework||(framework==='Autre'?actualFramework==='Autre':actualFramework===framework))});const purchases=visible.filter(t=>t.transaction_type==='buy').reduce((n,t)=>n+(Number(t.gross_amount_eur)||0),0);const sales=visible.filter(t=>t.transaction_type==='sell').reduce((n,t)=>n+(Number(t.gross_amount_eur)||0),0);const selectedFramework=document.querySelector('#txFilterFramework')?.value||'';const filteredBuys=visible.filter(t=>t.transaction_type==='buy');document.querySelector('#txJournalTotals').textContent=selectedFramework?`${selectedFramework} · ${filteredBuys.length} achat(s) · Total investi : ${euro.format(purchases)}${sales?` · Ventes : ${euro.format(sales)}`:''}`:`Achats : ${euro.format(purchases)} · Ventes : ${euro.format(sales)}`;document.querySelector('#txHistorySummary').textContent=positionId?`${visible.filter(x=>x.transaction_type!=='opening').length} opération(s) sur cette ligne`:`${visible.filter(x=>x.transaction_type!=='opening').length} opération(s)`;if(!visible.length){box.innerHTML='<p class="muted">Aucune transaction enregistrée.</p>';return}for(const t of visible){const row=document.createElement('div');row.className=`txRow expandableHistoryRow ${t.transaction_type==='opening'?'txOpening':''}`;let detail='';if(t.transaction_type==='buy'||t.transaction_type==='sell')detail=`${num.format(t.quantity||0)} × ${euro.format(t.unit_price_eur||0)} = ${euro.format(t.gross_amount_eur||0)}${t.fees_eur?` · frais ${euro.format(t.fees_eur)}`:''}${t.realized_pnl_eur!=null?` · réalisé ${euro.format(t.realized_pnl_eur)}`:''}`;else detail=`${euro.format(t.gross_amount_eur||0)}`;const origin=t.transaction_type!=='opening'&&t.origin?` · ${escapeHtml((t.investment_framework==='Autre'?t.framework_label:t.investment_framework)||t.origin)}`:'';row.innerHTML=`<div><strong>${escapeHtml(txLabels[t.transaction_type]||t.transaction_type)}</strong> · ${escapeHtml(t.position_name)}<br><span class="muted">${escapeHtml(t.transaction_date)} · ${detail}${origin}${t.note?` · ${escapeHtml(t.note)}`:''}</span></div>${t.transaction_type==='opening'?'':'<div><button type="button" class="secondary txEdit">Modifier</button> <button type="button" class="danger txDelete">Supprimer</button></div>'}`;row.tabIndex=0;row.setAttribute('role','button');row.setAttribute('aria-expanded','false');row.setAttribute('aria-label','Afficher les actions de cette opération');enableHistoryRowActions(row, '.expandableHistoryRow');const edit=row.querySelector('.txEdit');if(edit)edit.addEventListener('click',()=>editHistoryTransaction(t));const del=row.querySelector('.txDelete');if(del)del.addEventListener('click',async()=>{if(!confirm('Supprimer cette transaction et recalculer la position ?'))return;try{await api(`/api/transactions/${t.id}`,{method:'DELETE'});await load();fillTxPositions(positionId||t.position_id);await loadTransactions(positionId)}catch(err){const st=document.querySelector('#txStatus');st.textContent=err.message;st.className='status errorBox'}});box.appendChild(row)}}
document.querySelector('#openingForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!openingContext)return;const st=document.querySelector('#openingStatus');st.textContent='Enregistrement…';try{await api(`/api/positions/${openingContext.positionId}/opening`,{method:'PATCH',body:JSON.stringify({quantity:+document.querySelector('#openingQty').value,avg_cost_eur:+document.querySelector('#openingPru').value})});st.textContent='Position initiale mise à jour.';st.className='status okBox';await load();await refreshOpeningContext();document.querySelector(`[data-history-for="${openingContext.positionId}"]`)?.removeAttribute('data-loaded');renderPositionCards();}catch(err){st.textContent=err.message;st.className='status errorBox';}});
document.querySelector('#replaceOpeningBtn')?.addEventListener('click',async()=>{if(!openingContext)return;if(!confirm('Remplacer définitivement la position initiale par l’historique réel saisi ?'))return;const st=document.querySelector('#openingStatus');try{await api(`/api/positions/${openingContext.positionId}/opening`,{method:'DELETE'});document.querySelector('#openingDialog').close();await load();renderPositionCards();}catch(err){st.textContent=err.message;st.className='status errorBox';}});
document.querySelector('#deleteOpeningBtn')?.addEventListener('click',async()=>{if(!openingContext)return;const rec=openingContext.ledgerData?.reconciliation||{};let msg=`Supprimer la position initiale ? La quantité sera recalculée uniquement depuis l’historique saisi.`;if(Math.abs(Number(rec.quantity_gap)||0)>1e-7)msg+=`\n\nAttention : il reste un écart de ${num.format(rec.quantity_gap)} titre(s).`;if(!confirm(msg))return;const st=document.querySelector('#openingStatus');try{await api(`/api/positions/${openingContext.positionId}/opening?force=true`,{method:'DELETE'});document.querySelector('#openingDialog').close();await load();renderPositionCards();}catch(err){st.textContent=err.message;st.className='status errorBox';}});
document.querySelector('#resetTxBtn')?.addEventListener('click',()=>openTransactions());
document.querySelector('#transactionsBtn').addEventListener('click',()=>openTransactions(null));
document.querySelector('#txType').addEventListener('change',updateTxFields);
document.querySelector('#txPosition').addEventListener('change',()=>{if(transactionFilterPositionId!==null){transactionFilterPositionId=+document.querySelector('#txPosition').value;loadTransactions(transactionFilterPositionId)}});
document.querySelector('#transactionForm').addEventListener('submit',async e=>{e.preventDefault();const typ=document.querySelector('#txType').value;const val=id=>{const x=document.querySelector(id).value;return x===''?null:+x};const payload={position_id:+document.querySelector('#txPosition').value,transaction_type:typ,transaction_date:document.querySelector('#txDate').value,quantity:val('#txQty'),unit_price_eur:val('#txUnitPrice'),amount_eur:val('#txAmount'),fees_eur:val('#txFees')||0,note:document.querySelector('#txNote').value.trim(),investment_framework:document.querySelector('#txOrigin').value,framework_label:document.querySelector('#txCustom').value.trim()};const st=document.querySelector('#txStatus');st.textContent='Enregistrement…';st.className='status';try{await api(editingTransactionId?`/api/transactions/${editingTransactionId}`:'/api/transactions',{method:editingTransactionId?'PATCH':'POST',body:JSON.stringify(payload)});st.textContent='Opération enregistrée. Quantité et PRU recalculés.';resetTransactionEditing();st.className='status okBox';await load();fillTxPositions(payload.position_id);document.querySelector('#txQty').value='';document.querySelector('#txUnitPrice').value='';document.querySelector('#txAmount').value='';document.querySelector('#txFees').value='0';document.querySelector('#txNote').value='';await loadTransactions(transactionFilterPositionId)}catch(err){st.textContent=err.message;st.className='status errorBox'}});

// Réglages
document.querySelector('#settingsBtn').addEventListener('click',async()=>{const s=await api('/api/settings/market');document.querySelector('#eodhdToken').value='';document.querySelector('#eodhdToken').disabled=!!s.token_managed_by_server;document.querySelector('#eodhdToken').placeholder=s.token_managed_by_server?'Clé gérée comme secret serveur':(s.token_configured?`Clé actuelle ${s.token_hint}`:'Colle ta clé EODHD');const secretInfo=document.querySelector('#marketSecretInfo');if(secretInfo)secretInfo.textContent=s.token_managed_by_server?'La clé EODHD est stockée comme secret chiffré chez l’hébergeur, pas dans PostgreSQL.':'La clé EODHD est gérée par ce serveur.';const cloudImport=document.querySelector('#cloudImportBox');if(cloudImport)cloudImport.hidden=!s.cloud_mode;document.querySelector('#yahooFallback').checked=s.yahoo_fallback;document.querySelector('#settingsStatus').textContent=s.token_configured?'Clé EODHD configurée. Les cours sont actualisés uniquement à la demande.':'Aucune clé EODHD configurée.';const usage=document.querySelector('#settingsApiUsage');if(usage)usage.textContent=`Appels EODHD aujourd’hui : ${s.calls_today||0}${s.daily_rate_limit?` / ${s.daily_rate_limit}`:''}`;document.querySelector('#settingsStatus').className='status';activateTab('settings')});
document.querySelector('#settingsForm').addEventListener('submit',async e=>{e.preventDefault();const token=document.querySelector('#eodhdToken').value.trim();const payload={yahoo_fallback:document.querySelector('#yahooFallback').checked};if(token)payload.eodhd_api_token=token;const status=document.querySelector('#settingsStatus');status.textContent='Vérification de la clé…';try{await api('/api/settings/market',{method:'POST',body:JSON.stringify(payload)});status.textContent='Réglages enregistrés. Les cours restent inchangés jusqu’à la prochaine actualisation manuelle.';status.className='status okBox';setTimeout(async()=>{await load()},500)}catch(err){status.textContent=err.message;status.className='status errorBox'}});

let quoteRefreshBusy=false,quotePolling=false,lastQuoteJob=null;
function setQuoteBusy(busy){quoteRefreshBusy=busy;document.querySelector('#refreshBtn').disabled=busy;document.querySelector('#refreshBtn').textContent=busy?'Actualisation en cours…':'Actualiser les cours';document.querySelector('#retryQuotesBtn').disabled=busy;document.querySelectorAll('[data-refresh-id]').forEach(button=>button.disabled=busy);}
function renderQuoteJob(job){
 if(!job?.id)return;lastQuoteJob=job;const running=job.status==='running';setQuoteBusy(running);
 const counts={recent:0,old:0,error:0,not_attempted:0,skipped:0,pending:0,running:0};for(const row of job.results||[])counts[row.status]=(counts[row.status]||0)+1;
 const progress=document.querySelector('#quoteRefreshProgress'),bar=document.querySelector('#quoteRefreshBar');bar.hidden=false;bar.max=Math.max(1,job.total);bar.value=job.processed+counts.skipped;
 const apiText=`${job.api_responses||0} réponse(s) API / ${job.api_requests||0} requête(s)${job.api_network_errors?` · ${job.api_network_errors} échec(s) réseau`:''}`;
 if(running){progress.textContent=`${job.processed}/${job.total} lignes traitées · ${apiText}${job.current_name?' · '+job.current_name:''}`;}
 else if(job.status==='interrupted'){progress.textContent=`Suivi interrompu : ${job.processed}/${job.total} lignes traitées · ${apiText}. Les lignes non abouties peuvent être reprises seules.`;}
 else if(counts.recent===job.total&&job.total>0){progress.textContent=`Terminé : tous les cours sélectionnés ont reçu une réponse récente (${counts.recent}/${job.total}) · ${apiText}.`;}
 else{progress.textContent=`Terminé : ${counts.recent} récent(s), ${counts.old} ancien(s), ${counts.error} échec(s), ${counts.not_attempted} non interrogé(s), ${counts.skipped} interrogation(s) récente(s) évitée(s) · ${apiText}.${job.quota_exhausted?' Quota atteint : les requêtes restantes n’ont pas été envoyées.':''}${counts.skipped?' Attends 60 secondes après la dernière tentative pour réinterroger ces titres.':''}`;}
 progress.className=counts.old||counts.error||counts.not_attempted||job.status==='interrupted'?'quoteJobWarning':'';
 const retry=document.querySelector('#retryQuotesBtn');retry.hidden=running||!(counts.old||counts.error||counts.not_attempted||job.status==='interrupted'||(counts.skipped&&(job.results||[]).some(r=>state?.positions.some(p=>p.id===r.id&&(p.quote_stale||p.quote_refresh_error)))));
 document.querySelector('#resumeQuotesBtn').hidden=true;
 document.querySelector('#quoteRefreshDetails').hidden=false;
 const labels={pending:'En attente',running:'Interrogation en cours',recent:'Réponse récente',old:'Réponse reçue, cours ancien',error:'Échec, cours conservé',not_attempted:'Non interrogé',skipped:'Nouvelle requête évitée (moins de 60 s)'};
 document.querySelector('#quoteRefreshResults').innerHTML=(job.results||[]).map(row=>`<div class="quoteJobRow"><strong>${escapeHtml(row.name)}</strong><span>${escapeHtml(labels[row.status]||row.status)}${row.timestamp?' · cours au '+escapeHtml(fmtTimestamp(row.timestamp)):''}${row.checked_at?' · reçu le '+escapeHtml(fmtTimestamp(row.checked_at)):''}${row.error?' · '+escapeHtml(row.error):''}</span></div>`).join('');
 const status=document.querySelector('#status');if(status){status.textContent=progress.textContent;status.className=progress.className?'status errorBox':'status';}
}
async function readQuoteJob(){const response=await fetchWithTimeout('/api/quotes/jobs/current',{},4000);const job=await response.json();if(!response.ok)throw new Error(job.detail||'Suivi indisponible');return job;}
async function pollQuoteJob(){
 if(quotePolling)return;quotePolling=true;let failures=0;
 try{while(true){try{const job=await readQuoteJob();failures=0;renderQuoteJob(job);if(job.status!=='running'){await load();renderQuoteJob(job);return;}}catch(error){failures++;if(failures>=3){document.querySelector('#quoteRefreshProgress').textContent='Suivi indisponible. L’opération peut continuer sur le serveur : reprends le suivi sans relancer les requêtes.';document.querySelector('#resumeQuotesBtn').hidden=false;return;}}await new Promise(resolve=>setTimeout(resolve,1000));}}finally{quotePolling=false;}
}
async function startQuoteRefresh(payload={}){
 if(quoteRefreshBusy)return;setQuoteBusy(true);document.querySelector('#quoteRefreshProgress').textContent='Préparation de l’actualisation…';
 try{const response=await fetchWithTimeout('/api/quotes/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)},10000);const job=await response.json();if(!response.ok)throw new Error(job.detail||'Actualisation impossible');renderQuoteJob(job);if(job.status==='running')await pollQuoteJob();else{await load();renderQuoteJob(job);}}
 catch(error){document.querySelector('#quoteRefreshProgress').textContent='Confirmation indisponible : reprends le suivi avant de lancer une nouvelle actualisation.';document.querySelector('#resumeQuotesBtn').hidden=false;}
}
async function resumeQuoteRefresh(){try{const job=await readQuoteJob();if(job.id){renderQuoteJob(job);if(job.status==='running')await pollQuoteJob();}else{setQuoteBusy(false);document.querySelector('#resumeQuotesBtn').hidden=true;document.querySelector('#quoteRefreshProgress').textContent='Aucune actualisation en cours.';}}catch(error){document.querySelector('#quoteRefreshProgress').textContent='Le serveur ne répond pas au suivi. Aucune nouvelle requête de cours n’a été lancée.';document.querySelector('#resumeQuotesBtn').hidden=false;}}
document.querySelector('#refreshBtn').addEventListener('click',()=>startQuoteRefresh());
document.querySelector('#retryQuotesBtn').addEventListener('click',()=>startQuoteRefresh({retry_only:true}));
document.querySelector('#resumeQuotesBtn').addEventListener('click',resumeQuoteRefresh);
async function boot(){initTabs();installNavigationFallback();initMobileNav();initProjectionControls();initTableSorting();initPositionCards();bindAnalyticsControls();await load();const s=document.querySelector('#status');if(!state.eodhd_configured){s.textContent='Commence par “Réglages marché” pour ajouter ta clé EODHD.';s.className='status'}else{s.textContent='Cours figés jusqu’à ta prochaine demande. Clique sur “Actualiser les cours” pour mettre à jour la valorisation.';s.className='status'}}


const tabMeta={radar:['Radar d’opportunités','Comparaison entre actifs d’une même catégorie et indication raisonnée.'],overview:['Synthèse','Vue visuelle de ton portefeuille et de son état.'],positions:['Positions','Lecture rapide des titres, performances et mouvements.'],table:['Export','Vue analytique complète, tri et export Excel.'],allocation:['Allocation','Cibles, concentration et rééquilibrage sans vente.'],effort:['Effort d’investissement','Mesure ce que tu investis réellement au-delà de ton plan.'],performance:['Performance','Historique, performance personnelle et rapprochement Trade Republic.'],transactions:['Transactions','Journal de tous les mouvements du portefeuille.'],goals:['Objectifs','Projection du capital, scénarios et prochains paliers.'],settings:['Réglages','Configuration du portefeuille et sauvegardes.']};
function initTabs(){
  document.querySelectorAll('.navTab[data-tab],.mobileBottomTab[data-tab],.mobileMoreSheet [data-tab]').forEach(btn=>btn.addEventListener('click',()=>{if(btn.dataset.tab==='transactions')openTransactions();else activateTab(btn.dataset.tab);closeMobileMore();}));
  document.querySelector('#navTransactionsBtn')?.addEventListener('click',()=>openTransactions());
  document.querySelector('#mobileTransactionsBtn')?.addEventListener('click',()=>openTransactions());


  document.querySelector('#mobileSettingsBtn')?.addEventListener('click',()=>document.querySelector('#settingsBtn')?.click());
  document.querySelector('#cancelSettingsBtn')?.addEventListener('click',()=>activateTab('positions'));
}

function installNavigationFallback(){
  document.addEventListener('click',event=>{
    const tab=event.target.closest('.mobileBottomTab[data-tab],.navTab[data-tab],.mobileMoreSheet [data-tab]');
    if(!tab)return;
    event.preventDefault();
    event.stopPropagation();
    if(tab.dataset.tab==='transactions')openTransactions();else activateTab(tab.dataset.tab);
    closeMobileMore();
  },true);
}
function initMobileNav(){
  let touchStart=null;
  document.addEventListener('touchstart',e=>{
    if(window.innerWidth>760||e.touches.length!==1){touchStart=null;return;}
    if(e.target.closest('#opportunityPanel,input,textarea,select,button,dialog,canvas,[contenteditable],.tableWrap,.positionInlineScroll,.mobileBottomNav,.txHistory')){touchStart=null;return;}
    touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY};
  },{passive:true});
  document.addEventListener('touchend',e=>{
    if(!touchStart||!e.changedTouches.length)return;
    const dx=e.changedTouches[0].clientX-touchStart.x,dy=e.changedTouches[0].clientY-touchStart.y;
    touchStart=null;
    if(Math.abs(dx)<75||Math.abs(dx)<Math.abs(dy)*1.5)return;
    const order=['overview','positions','transactions','allocation','effort','radar','performance','goals','table','settings'];
    const current=order.indexOf(activeTab),next=current+(dx<0?1:-1);
    if(next<0||next>=order.length)return;
    if(order[next]==='settings')document.querySelector('#settingsBtn')?.click();
    else if(order[next]==='transactions')openTransactions();else activateTab(order[next]);
  },{passive:true});
}

function openMobileNav(){}
function closeMobileNav(){}
function openMobileMore(){const sheet=document.querySelector('#mobileMoreSheet'),backdrop=document.querySelector('#mobileMoreBackdrop');if(!sheet||!backdrop)return;sheet.hidden=false;backdrop.hidden=false;requestAnimationFrame(()=>{sheet.classList.add('open');backdrop.classList.add('open');});}
function closeMobileMore(){const sheet=document.querySelector('#mobileMoreSheet'),backdrop=document.querySelector('#mobileMoreBackdrop');if(!sheet||!backdrop)return;sheet.classList.remove('open');backdrop.classList.remove('open');setTimeout(()=>{if(!sheet.classList.contains('open')){sheet.hidden=true;backdrop.hidden=true;}},180);}
function activateTab(tab){activeTab=tab;document.querySelectorAll('.navTab[data-tab],.mobileBottomTab[data-tab],#mobileSettingsBtn,#settingsBtn').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab||(tab==='settings'&&(b.id==='mobileSettingsBtn'||b.id==='settingsBtn'))));document.querySelector('.mobileBottomTab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});document.querySelectorAll('.tabView').forEach(v=>v.classList.toggle('active',v.dataset.view===tab));const meta=tabMeta[tab]||tabMeta.overview;document.querySelector('#tabTitle').textContent=meta[0];document.querySelector('#tabSubtitle').textContent=meta[1];document.body.classList.toggle('onPositions',tab==='positions');renderActiveTab();localStorage.setItem('portfolioActiveTab',tab);window.scrollTo({top:0,behavior:'smooth'});}
function renderActiveTab(){if(!state)return;if(activeTab==='overview')renderOverviewVisuals();if(activeTab==='allocation')renderChart();if(activeTab==='positions'){renderPositionViewSummary();renderPositionCards();}if(activeTab==='table'){requestAnimationFrame(syncPositionScroll);}if(activeTab==='effort')renderEffortChart();if(activeTab==='radar'){renderRadar();initializeOpportunity();}if(activeTab==='performance')renderHistoryChart();if(activeTab==='goals'){renderProjection();renderMilestones();renderScenario();}}

function renderAnalytics(){
  if(!analyticsState)return;const e=analyticsState.effort||{},p=analyticsState.performance||{},r=analyticsState.risk||{},rec=analyticsState.reconciliation||{},u=analyticsState.api_usage||{};
  document.querySelector('#effortActual').textContent=euro.format(e.actual||0);document.querySelector('#effortGoal').textContent=euro.format(e.annual_goal||0);
  const extra=document.querySelector('#effortExtra');extra.textContent=euro.format(e.extra_gross||0);extra.className=perfClass(e.extra_gross||0);
  const vp=document.querySelector('#effortVsPlan');vp.textContent=euro.format(e.net_vs_plan_ytd||0);vp.className=perfClass(e.net_vs_plan_ytd||0);
  document.querySelector('#effortMessage').textContent=e.encouragement||'';document.querySelector('#effortMonthlyTarget').value=e.monthly_target??state.monthly_plan;document.querySelector('#effortAnnualGoal').value=e.annual_goal??0;document.querySelector('#effortPeriod').textContent=`${e.labels[0]} – ${e.labels[11]}`;document.querySelector('#effortTotal').textContent=`Effort total de la période : ${euro.format(e.total_actual||0)}${e.other_extra?' · dont '+euro.format(e.other_extra)+' supplémentaires hors CTO':''}`;const coverage=document.querySelector('#effortCoverageNote');if(coverage)coverage.textContent=`Plan PEA : ${euro.format(e.journal_actual||0)} dans le journal + ${euro.format(e.confirmed_extra||0)} de complément confirmé. Comparaison jusqu’au mois en cours inclus. Les achats futurs ne sont pas comptés. ${e.legacy_catchup?'Ancien rattrapage conservé : '+euro.format(e.legacy_catchup)+' ; exclu du calcul car son compte et sa période ne sont pas établis. Enregistre les achats correspondants avec leurs dates et cadres pour les inclure.':''}`;
  renderOriginBreakdown(e.origins||{});
  window.ctoEffortOrigins={period:e.cto_origins||{},month:e.cto_origins_month||{},byMonth:e.cto_origins_by_month||{}};
  renderCtoComparison(e);
  renderEffortConfirmations(e);
  document.querySelector('#personalXirrValue').textContent=p.personal_xirr_pct==null?'—':fmtPct(p.personal_xirr_pct);document.querySelector('#personalXirrValue').className=perfClass(p.personal_xirr_pct||0);document.querySelector('#savebackTotalValue').textContent=euro.format(p.saveback_total||0);
  document.querySelector('#xirrValue').textContent=p.xirr_pct==null?'—':fmtPct(p.xirr_pct);document.querySelector('#xirrValue').className=perfClass(p.xirr_pct||0);
  document.querySelector('#dividendsValue').textContent=euro.format(p.dividends_year||0);document.querySelector('#realizedValue').textContent=euro.format(p.realized_year||0);document.querySelector('#xirrNote').textContent=p.xirr_note||'';
  document.querySelector('#trReferenceValue').value=rec.tr_reference_value||'';renderReconciliation(rec);
  renderRisk(r);renderAnomalies(r);
  const apiEl=document.querySelector('#apiUsage');if(apiEl)apiEl.textContent=`EODHD : ${u.calls_today||0}${u.daily_limit?` / ${u.daily_limit}`:''} appels aujourd’hui`;
  renderMilestones();renderScenario();
}
function renderAnomalies(r){const box=document.querySelector('#anomalyList');if(!box)return;const alerts=[...(r.alerts||[])];const stale=(state.positions||[]).filter(p=>p.price_updated_at&&Date.now()/1000-Number(p.price_updated_at)>3*86400);if(stale.length)alerts.push(`${stale.length} cours datent de plus de 3 jours.`);if(!alerts.length)alerts.push('Aucune anomalie importante détectée.');box.innerHTML=alerts.map((x,i)=>`<div class="insight ${i===0&&alerts.length===1?'okInsight':''}">${escapeHtml(x)}</div>`).join('');}
function renderOriginBreakdown(origins){const box=document.querySelector('#effortOrigin');if(!box)return;const entries=Object.entries(origins).sort((a,b)=>b[1]-a[1]);if(!entries.length){box.innerHTML='<p class="muted">Ajoute des achats dans le journal pour ventiler ton effort.</p>';return}const total=entries.reduce((s,x)=>s+Number(x[1]||0),0);box.innerHTML=entries.map(([k,v])=>`<div class="breakdownRow"><span>${escapeHtml(k)}</span><strong>${euro.format(v)}</strong><small>${total?((v/total)*100).toFixed(1):0} %</small></div>`).join('');}
function renderCtoComparison(e){
  const byMonth=window.ctoEffortOrigins?.byMonth||{};
  const now=new Date(),currentKey=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  const selectedKey=(window.ctoSelectedMonth && window.ctoSelectedMonth>=String(e.period_start||'').slice(0,7) && window.ctoSelectedMonth<=String(e.period_end||'').slice(0,7))?window.ctoSelectedMonth:currentKey;
  const past={};
  for(const [month,origins] of Object.entries(byMonth)){
    if(month>=currentKey)continue;
    for(const [name,value] of Object.entries(origins))past[name]=(past[name]||0)+Number(value||0);
  }
  const selected=byMonth[selectedKey]||{};
  const title=document.querySelector('#ctoSelectedTitle');
  if(title){const [y,m]=selectedKey.split('-').map(Number);title.textContent=new Date(y,m-1,1).toLocaleDateString('fr-FR',{month:'long',year:'numeric'}).replace(/^./,c=>c.toUpperCase());}
  renderCtoComparisonBars('ctoPastBars','ctoPastTotal',past,'past');
  renderCtoComparisonBars('ctoSelectedBars','ctoSelectedTotal',selected,'selected');
  const info=document.querySelector('#ctoBarInfo');if(info)info.hidden=true;
}
function renderCtoComparisonBars(hostId,totalId,origins,group){
  const host=document.getElementById(hostId),totalEl=document.getElementById(totalId);if(!host)return;
  const names=['Investissement libre','Round Up','Saveback'];
  const colors={'Investissement libre':'#1683f5','Round Up':'#eca53e','Saveback':'#2cb99b','Autre':'#8996ac'};
  const entries=names.map(name=>[name,Number(origins[name]||0)]);
  const other=Object.entries(origins).filter(([k])=>!names.includes(k)).reduce((n,[,v])=>n+Number(v||0),0);
  if(other>0)entries.push(['Autre',other]);
  const total=entries.reduce((n,[,v])=>n+v,0),max=Math.max(1,...entries.map(([,v])=>v));
  if(totalEl)totalEl.textContent=euro.format(total);
  host.innerHTML=entries.map(([name,value],i)=>`<button type="button" class="ctoCompareBar" data-index="${i}" style="--bar-color:${colors[name]};--bar-height:${value>0?Math.max(5,Math.round(value/max*100)):3}%" aria-label="${escapeHtml(name)} : ${euro.format(value)}" title="${escapeHtml(name)}"></button>`).join('');
  host.querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>{
    const [name,value]=entries[Number(button.dataset.index)];
    document.querySelectorAll('.ctoCompareBar').forEach(b=>b.classList.remove('selected'));
    button.classList.add('selected');
    const info=document.querySelector('#ctoBarInfo');if(info){info.textContent=`${name} — ${euro.format(value)}`;info.hidden=false;}
  }));
}

function allocationColor(delta){
  const t=Math.min(1,Math.abs(delta)/10);
  const stops=[[0,[32,165,104]],[.15,[130,201,79]],[.3,[244,200,75]],[.6,[230,90,69]],[1,[167,25,63]]];
  let i=0;while(i<stops.length-2&&t>stops[i+1][0])i++;
  const [a,ca]=stops[i],[b,cb]=stops[i+1],f=(t-a)/(b-a);
  return `rgb(${ca.map((v,k)=>Math.round(v+(cb[k]-v)*f)).join(',')})`;
}
function allocationGauge(weight,target){
  const gap=weight-target,position=Math.max(9,Math.min(91,50+5*gap));
  return `<div class="allocationGauge" role="img" aria-label="Poids actuel ${weight.toFixed(1)} %, cible ${target.toFixed(1)} %, écart ${gap.toFixed(1)} points"><span class="allocationGaugeBubble" style="left:${position}%;border-color:${allocationColor(gap)}">${weight.toFixed(1).replace('.',',')} %</span></div>`;
}
function renderRisk(r){
  const box=document.querySelector('#riskCategories');
  if(box){
    const entries=Object.entries(r.categories||{}).sort((a,b)=>b[1]-a[1]);
    box.innerHTML=entries.map(([name,value],i)=>{
      const current=Number(value)||0,target=Number(r.category_targets?.[name])||0;
      return `<button type="button" class="allocationGaugeRow" data-allocation-index="${i}" aria-label="${escapeHtml(name)} : montant à investir pour atteindre la cible"><span class="allocationGaugeName">${escapeHtml(name)}</span><span class="allocationGaugeTrack">${allocationGauge(current,target)}</span><span class="allocationGaugeTarget">Cible <b>${target.toFixed(1).replace('.',',')} %</b></span></button>`;
    }).join('')||'<p class="muted">Pas encore de données.</p>';
    box.querySelectorAll('[data-allocation-index]').forEach(btn=>btn.addEventListener('click',()=>{
      const [name,value]=entries[Number(btn.dataset.allocationIndex)],target=Number(r.category_targets?.[name])||0;
      const total=Number(state?.total_value)||0,actual=total*Number(value)/100,t=target/100;
      const detail=document.querySelector('#allocationInvestDetail');
      if(!detail)return;
      const required=t>0&&t<1?Math.max(0,(t*total-actual)/(1-t)):0;
      const note=target<=0?'Aucune cible positive définie.':target>=100?'Cible de 100 % : calcul par achat seul non applicable.':Number(value)>=target-0.0001?'Aucun achat nécessaire dans cette catégorie.':`Pour atteindre ${target.toFixed(1).replace('.',',')} %, investir environ <strong>${euro.format(required)}</strong> dans cette catégorie, sans vendre et à cours constants.`;
      detail.innerHTML=`<strong>${escapeHtml(name)}</strong><p>${note}</p><small>Simulation indicative, hors frais et variation des cours. Le total du portefeuille augmente avec le versement.</small>`;
      detail.hidden=false;
      box.querySelectorAll('.allocationGaugeRow').forEach(x=>x.classList.toggle('selected',x===btn));
    }));
  }
  const warn=document.querySelector('#overlapWarnings');if(warn){const items=[...(r.overlap||[]),...(r.alerts||[])];warn.innerHTML=(items.length?items:['Pas de signal particulier.']).map(x=>`<div class="insight">${escapeHtml(x)}</div>`).join('');}
}

function renderReconciliation(rec){const v=document.querySelector('#reconcileValue'),d=document.querySelector('#reconcileDetail');if(!v||!d)return;if(!rec.tr_reference_value){v.textContent='—';d.textContent='Ajoute une valeur Trade Republic pour mesurer l’écart.';return}v.textContent=euro.format(rec.gap||0);v.className=perfClass(-(rec.gap||0));d.textContent=`Trade Republic ${euro.format(rec.tr_reference_value)} · Tracker ${euro.format(rec.tracker_value)} · écart ${euro.format(rec.gap)} (${rec.gap_pct>=0?'+':''}${Number(rec.gap_pct||0).toFixed(2)} %)`;}
function renderEffortChart(){
  const canvas=document.querySelector('#effortChart');if(!canvas||typeof Chart==='undefined'||!analyticsState)return;
  if(effortChart)effortChart.destroy();
  const e=analyticsState.effort,labels=e.labels;
  const datasets=[
    {label:'Plan PEA réalisé',data:e.monthly,backgroundColor:'#087cff'},
    {label:'Plan PEA prévu',data:Array(12).fill(e.monthly_target),backgroundColor:'rgba(0,185,86,.20)'},
    {label:'Supplément CTO',data:e.extra_monthly,backgroundColor:'#72b0ff'},
    {label:'Supplément hors CTO',data:e.other_monthly,backgroundColor:'#dcaa55'}
  ];
  const legend=document.querySelector('#effortChartLegend');
  if(legend)legend.innerHTML=datasets.filter((d,i)=>i<3||d.data.some(v=>Number(v)>0)).map(d=>`<span class="effortLegendItem"><i style="background:${d.backgroundColor}"></i><span>${d.label}</span></span>`).join('');
  effortChart=new Chart(canvas,{type:'bar',data:{labels,datasets},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},onClick:(event,active,chart)=>{
    const hits=chart.getElementsAtEventForMode(event,'index',{intersect:false},false);
    if(!hits.length)return;
    const i=hits[0].index;
    const period=String(e.period_start||'');
    if(!period)return;
    const [year,month]=period.slice(0,7).split('-').map(Number);
    const date=new Date(year,month-1+i,1);
    window.ctoSelectedMonth=`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}`;
    renderCtoComparison(e);
  },scales:{y:{beginAtZero:true,ticks:{callback:v=>`${v} €`}}}}});
}

function renderHistoryChart(){const canvas=document.querySelector('#historyChart');if(!canvas||typeof Chart==='undefined'||!analyticsState)return;if(historyChart)historyChart.destroy();const h=analyticsState.performance.history||[];if(!h.length)return;historyChart=new Chart(canvas,{type:'line',data:{labels:h.map(x=>fmtTimestamp(x.created_at)),datasets:[{label:'Valeur du portefeuille',data:h.map(x=>x.total_value),borderColor:'#087cff',backgroundColor:'rgba(8,124,255,.08)',fill:true,tension:.15,pointRadius:h.length>60?0:2},{label:'Capital investi',data:h.map(x=>x.invested_estimate),borderColor:'#00b956',borderDash:[5,4],tension:.15,pointRadius:0}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${euro.format(c.raw)}`}}},scales:{x:{ticks:{maxTicksLimit:8}},y:{ticks:{callback:v=>new Intl.NumberFormat('fr-FR',{notation:'compact'}).format(v)+' €'}}}}});}
async function calculateRebalance(){const amount=Math.max(0,Number(document.querySelector('#rebalanceAmount').value)||0);const a=await api(`/api/analytics?rebalance_amount=${encodeURIComponent(amount)}`);analyticsState=a;const box=document.querySelector('#rebalanceResults');const list=a.rebalance?.suggestions||[];if(!list.length){box.innerHTML='<p class="muted">Aucune allocation proposée. Vérifie les cibles ou le montant.</p>';return}box.innerHTML=list.map(x=>`<div class="recommendation"><span><strong>${escapeHtml(x.name)}</strong><small>${Number(x.weight_pct).toFixed(1)} % actuel → cible ${Number(x.target_pct).toFixed(1)} %</small></span><strong>${euro.format(x.amount)}</strong></div>`).join('');}
async function saveGoals(){const monthly=Number(document.querySelector('#effortMonthlyTarget').value)||0,annual=Number(document.querySelector('#effortAnnualGoal').value)||0;const st=document.querySelector('#goalsStatus');try{await api('/api/settings/goals',{method:'POST',body:JSON.stringify({monthly_target:monthly,annual_goal:annual})});st.textContent='Objectifs enregistrés.';st.className='status okBox';await load()}catch(err){st.textContent=err.message;st.className='status errorBox'}}
async function saveTrRef(){const v=Number(document.querySelector('#trReferenceValue').value)||0;await api('/api/settings/goals',{method:'POST',body:JSON.stringify({tr_reference_value:v})});await load();}
function renderMilestones(){const box=document.querySelector('#milestoneGrid');if(!box||!state)return;const settings=projectionSettings();const monthly=Math.max(0,Number(document.querySelector('#projectionMonthly')?.value)||settings.monthly);const annual=Number(document.querySelector('#projectionReturn')?.value)||settings.annualReturn;const current=Number(state.total_value)||0;const targets=[10000,25000,50000,100000,250000];box.innerHTML=targets.map(target=>{if(current>=target)return `<div class="milestone reached"><span>${euro.format(target)}</span><strong>Atteint ✓</strong></div>`;let m=null;for(let i=1;i<=600;i++){if(projectionFutureValueMonths(current,monthly,annual,i)>=target){m=i;break}}const label=m?`${Math.floor(m/12)?Math.floor(m/12)+' an'+(Math.floor(m/12)>1?'s':'')+' ':''}${m%12?m%12+' mois':''}`:'> 50 ans';return `<div class="milestone"><span>${euro.format(target)}</span><strong>${label.trim()}</strong></div>`}).join('');}
function renderScenario(){const out=document.querySelector('#scenarioResult');if(!out||!state)return;const one=Math.max(0,Number(document.querySelector('#scenarioOneOff')?.value)||0),monthly=Math.max(0,Number(document.querySelector('#scenarioMonthly')?.value)||projectionSettings().monthly),years=Number(document.querySelector('#scenarioYears')?.value)||5,annual=Number(document.querySelector('#scenarioReturn')?.value)||6;const val=projectionFutureValue(Number(state.total_value||0)+one,monthly,annual,years);out.innerHTML=`Avec <strong>${euro.format(one)}</strong> de versement ponctuel puis <strong>${euro.format(monthly)}/mois</strong>, la valeur projetée à ${years} an${years>1?'s':''} serait d’environ <strong>${euro.format(val)}</strong> avec ${annual.toFixed(1)} %/an.`;}
function bindAnalyticsControls(){document.querySelectorAll('[data-position-view]').forEach(btn=>btn.addEventListener('click',()=>{positionView=btn.dataset.positionView||'TOTAL';renderTable();renderPositionCards();}));document.querySelector('#saveGoalsBtn')?.addEventListener('click',saveGoals);document.querySelector('#editAnnualGoalBtn')?.addEventListener('click',()=>{const field=document.querySelector('#effortAnnualGoal');if(!field)return;field.scrollIntoView({behavior:'smooth',block:'center'});field.focus({preventScroll:true});field.select();});document.querySelector('#rebalanceBtn')?.addEventListener('click',calculateRebalance);document.querySelector('#saveTrRefBtn')?.addEventListener('click',saveTrRef);['#scenarioOneOff','#scenarioMonthly','#scenarioYears','#scenarioReturn'].forEach(sel=>document.querySelector(sel)?.addEventListener('input',renderScenario));['#projectionMonthly','#projectionReturn'].forEach(sel=>document.querySelector(sel)?.addEventListener('input',()=>{renderMilestones();renderScenario()}));const saved=localStorage.getItem('portfolioActiveTab');if(saved&&tabMeta[saved]){if(saved==='transactions')openTransactions();else if(saved==='settings')document.querySelector('#settingsBtn')?.click();else activateTab(saved);}}

// PWA installable (Android / desktop)
document.querySelector('#cloudDbImportBtn')?.addEventListener('click',async()=>{const file=document.querySelector('#cloudDbFile').files?.[0];const status=document.querySelector('#cloudDbImportStatus');if(!file){status.textContent='Choisis une copie de portfolio.db.';status.className='status errorBox';return}const replace=document.querySelector('#cloudDbReplace').checked;if(replace&&!confirm('Remplacer toutes les données actuellement présentes dans le cloud ?'))return;status.textContent='Import en cours…';status.className='status';try{const r=await fetch(`/api/admin/import-sqlite?replace=${replace?'true':'false'}`,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:file,cache:'no-store'});const data=await r.json();if(r.status===401){location.href='/login';return}if(!r.ok)throw new Error(data.detail||'Import impossible');status.textContent=`Import terminé : ${data.counts?.positions||0} positions et ${data.counts?.transactions||0} transactions.`;status.className='status okBox';await load()}catch(err){status.textContent=err.message;status.className='status errorBox'}});

let deferredInstallPrompt=null;
const installBtn=document.querySelector('#installPwaBtn');
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferredInstallPrompt=event;if(installBtn)installBtn.hidden=false});
if(installBtn)installBtn.addEventListener('click',async()=>{if(!deferredInstallPrompt)return;deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;installBtn.hidden=true});
window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;if(installBtn)installBtn.hidden=true});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>{}));}

boot().then(resumeQuoteRefresh).catch(err=>{const s=document.querySelector('#status');s.textContent=err.message;s.className='status errorBox'});

// Mise à jour de l'application (v2.5+)
async function loadUpdateStatus(){
  const box=document.querySelector('#updateStatus');
  try{
    const u=await api('/api/update/status');
    document.querySelector('#updateVersion').textContent=`Version actuelle : v${u.current_version}`;
    if(u.cloud_mode){
      const updateBox=document.querySelector('#updateBox');
      if(updateBox) updateBox.innerHTML=`<div><strong>Mises à jour cloud</strong><p class="muted">${escapeHtml(u.message||'Les mises à jour sont déployées côté serveur.')}</p></div><p class="positionMeta">Version actuelle : v${escapeHtml(u.current_version)}</p>`;
      return;
    }
    const restore=document.querySelector('#restoreUpdateBtn');
    restore.disabled=!u.can_restore;
    restore.title=u.can_restore?'Restaurer la dernière version sauvegardée':'Aucune version précédente disponible';
    if(box && !box.textContent) box.textContent=u.can_restore?`Une sauvegarde de version est disponible.`:'Aucune sauvegarde de version pour le moment.';
  }catch(err){if(box){box.textContent=err.message;box.className='status errorBox'}}
}

async function fetchWithTimeout(url,options={},timeout=4000){
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeout);
  try{const response=await fetch(url,{...options,signal:controller.signal,cache:'no-store'});const body=await response.text();return {ok:response.ok,status:response.status,text:async()=>body,json:async()=>JSON.parse(body)};}finally{clearTimeout(timer);}
}
let updateBusy=false;
function setUpdateBusy(busy){updateBusy=busy;document.querySelector('#installUpdateBtn').disabled=busy;document.querySelector('#restoreUpdateBtn').disabled=busy;document.querySelector('#updateFile').disabled=busy;}
async function waitForVersion(expected){
  const status=document.querySelector('#updateStatus');const deadline=Date.now()+90000;
  while(Date.now()<deadline){
    try{
      const r=await fetchWithTimeout(`/api/health?t=${Date.now()}`,{},3000);
      if(r.ok){const h=await r.json();if(h.ok&&h.version===expected){
        status.textContent=`Version ${h.version} démarrée. Rechargement…`;status.className='status okBox';
        const dialog=document.querySelector('#settingsDialog');if(dialog?.open&&typeof dialog.close==='function')dialog.close();
        location.replace(`/?v=${encodeURIComponent(h.version)}&t=${Date.now()}`);return true;
      }}
    }catch{}
    status.textContent=`Mise à jour installée. Redémarrage en cours… ${Math.max(0,Math.ceil((deadline-Date.now())/1000))} s maximum.`;
    await new Promise(r=>setTimeout(r,1000));
  }
  status.textContent='Les fichiers sont installés, mais le redémarrage n’a pas été confirmé. Relance “Mon Portefeuille” ou start-portfolio.bat, puis recharge cette page. En cas de nouvel échec, consulte .updates/restart.log.';
  status.className='status errorBox';return false;
}

document.querySelector('#installUpdateBtn').addEventListener('click',async()=>{
  if(updateBusy)return;
  const input=document.querySelector('#updateFile');
  const status=document.querySelector('#updateStatus');
  const file=input.files?.[0];
  if(!file){status.textContent='Choisis d’abord un fichier .ptupdate ou .zip.';status.className='status errorBox';return}
  if(!confirm(`Installer ${file.name} ? Une sauvegarde de l’application et de la base sera créée automatiquement.`)) return;
  setUpdateBusy(true);
  status.textContent='Vérification et installation… ne ferme pas cette page.';status.className='status';
  try{
    const r=await fetchWithTimeout('/api/update/install',{method:'POST',headers:{'Content-Type':'application/zip','X-Update-Filename':file.name},body:file,cache:'no-store'},300000);
    const raw=await r.text();let data={};try{data=raw?JSON.parse(raw):{}}catch{data={detail:raw}}
    if(!r.ok) throw new Error(data.detail||`Erreur HTTP ${r.status}`);
    status.textContent=`Mise à jour ${data.to_version} installée. Redémarrage…`;
    status.className='status okBox';
    await waitForVersion(data.to_version);
  }catch(err){status.textContent=err.name==='AbortError'?'Le serveur ne répond plus. Relance Mon Portefeuille et vérifie la version avant de réessayer.':err.message;status.className='status errorBox'}finally{setUpdateBusy(false);}
});

document.querySelector('#restoreUpdateBtn').addEventListener('click',async()=>{
  if(updateBusy)return;
  const status=document.querySelector('#updateStatus');
  if(!confirm('Restaurer la dernière version de l’application ? Les données du portefeuille ne seront pas remplacées.')) return;
  setUpdateBusy(true);
  status.textContent='Restauration de la version précédente…';status.className='status';
  try{
    const response=await fetchWithTimeout('/api/update/restore-latest',{method:'POST'},300000);const r=await response.json();if(!response.ok)throw new Error(r.detail||'Restauration impossible');
    status.textContent=`Version précédente restaurée. Redémarrage…`;
    status.className='status okBox';
    await waitForVersion(r.restored.version);
  }catch(err){status.textContent=err.message;status.className='status errorBox'}finally{setUpdateBusy(false);}
});

// Charger l'état du système de mise à jour à l'ouverture des réglages.
const originalSettingsHandler=document.querySelector('#settingsBtn');
originalSettingsHandler.addEventListener('click',()=>setTimeout(loadUpdateStatus,0));

function syncTxAccount(){const p=state?.positions.find(p=>+p.id===+document.querySelector('#txPosition').value);document.querySelector('#txAccount').value=p?.account||'';}
function updateFrameworkFields(){const other=document.querySelector('#txOrigin').value==='Autre';document.querySelector('#txCustomLabel').hidden=!other;document.querySelector('#txCustomLabel').style.display=other?'grid':'none';document.querySelector('#txCustom').required=other;syncTxAccount();}
document.querySelector('#txOrigin').addEventListener('change',updateFrameworkFields);
document.querySelector('#txPosition').addEventListener('change',syncTxAccount);
// Refresh the active period after returning to the app, including October rollover.
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&state)load();});

setInterval(()=>{if(!analyticsState||document.hidden)return;const now=new Date();const startYear=now.getMonth()>=9?now.getFullYear():now.getFullYear()-1;if(analyticsState.effort.period_start!==`${startYear}-10-01`)load();},60000);

function renderEffortConfirmations(e){
  const select=document.querySelector('#effortConfirmPosition');const previous=select.value;
  select.innerHTML=state.positions.filter(p=>p.account==='PEA').map(p=>`<option value="${p.id}">${escapeHtml(p.name)} · PEA</option>`).join('');
  if([...select.options].some(o=>o.value===previous))select.value=previous;
  const month=document.querySelector('#effortConfirmMonth');if(!month.value)month.value=localIsoDate().slice(0,7);month.max=localIsoDate().slice(0,7);
  const entries=e.confirmations||[];
  document.querySelector('#effortConfirmList').innerHTML=entries.map(c=>`<div class="breakdownRow"><span>${escapeHtml(c.position_name)} · ${escapeHtml(c.month)}${c.account!=='PEA'?' · hors PEA, exclu':''}</span><strong>${euro.format(c.amount_eur)}</strong><small>Complément ${euro.format(c.added_to_effort)}</small><button type="button" class="secondary" data-confirm-position="${c.position_id}" data-confirm-month="${escapeHtml(c.month)}">Modifier</button></div>`).join('');
  document.querySelectorAll('[data-confirm-position]').forEach(button=>button.addEventListener('click',()=>{select.value=button.dataset.confirmPosition;month.value=button.dataset.confirmMonth;syncEffortConfirmation();}));
}
function syncEffortConfirmation(){const entry=analyticsState?.effort?.confirmations?.find(c=>+c.position_id===+document.querySelector('#effortConfirmPosition').value&&c.month===document.querySelector('#effortConfirmMonth').value);document.querySelector('#effortConfirmAmount').value=entry?.amount_eur??'';}
document.querySelector('#effortConfirmPosition').addEventListener('change',syncEffortConfirmation);
document.querySelector('#effortConfirmMonth').addEventListener('change',syncEffortConfirmation);
document.querySelector('#effortConfirmForm').addEventListener('submit',async event=>{
 event.preventDefault();const status=document.querySelector('#effortConfirmStatus');const button=document.querySelector('#effortConfirmSave');button.disabled=true;
 try{await api('/api/effort/monthly-confirmations',{method:'POST',body:JSON.stringify({position_id:+document.querySelector('#effortConfirmPosition').value,month:document.querySelector('#effortConfirmMonth').value,amount_eur:+document.querySelector('#effortConfirmAmount').value})});await load();status.textContent='Effort enregistré. Quantité, PRU et valeur de la position inchangés.';status.className='status okBox';}catch(error){status.textContent=error.message;status.className='status errorBox';}finally{button.disabled=false;}
});

function syncPositionScroll(){const wrap=document.querySelector('#positionsTableWrap'),range=document.querySelector('#positionsScrollRange');if(!wrap||!range)return;const max=Math.max(0,wrap.scrollWidth-wrap.clientWidth);range.max=String(max);range.value=String(wrap.scrollLeft);range.disabled=max===0;document.querySelector('#positionsScrollLeft').disabled=wrap.scrollLeft<=0;document.querySelector('#positionsScrollRight').disabled=wrap.scrollLeft>=max-1;}
const positionScrollWrap=document.querySelector('#positionsTableWrap');
positionScrollWrap.addEventListener('scroll',syncPositionScroll,{passive:true});
document.querySelector('#positionsScrollRange').addEventListener('input',event=>{positionScrollWrap.scrollLeft=+event.target.value;syncPositionScroll();});
document.querySelector('#positionsScrollLeft').addEventListener('click',()=>{positionScrollWrap.scrollLeft-=Math.max(200,positionScrollWrap.clientWidth*.65);syncPositionScroll();});
document.querySelector('#positionsScrollRight').addEventListener('click',()=>{positionScrollWrap.scrollLeft+=Math.max(200,positionScrollWrap.clientWidth*.65);syncPositionScroll();});
new ResizeObserver(syncPositionScroll).observe(positionScrollWrap);

['txSearch','txFilterType','txFilterAccount','txFilterFrom','txFilterTo','txFilterFramework'].forEach(id=>document.getElementById(id)?.addEventListener('input',()=>loadTransactions(transactionFilterPositionId)));

// Diagnostic facultatif, lecture seule, sans modification de Neon.
document.querySelector('#checkDataHealthBtn')?.addEventListener('click',async()=>{
  const out=document.querySelector('#dataHealthResults');out.textContent='Vérification en cours…';
  try{const data=await api('/api/data-health');
    out.innerHTML=`<strong>${data.warnings.length?data.warnings.length+' point(s) à examiner':'Aucune anomalie détectée par ces contrôles'}</strong><p>${data.checked} vérifications exécutées</p>`+data.warnings.map(w=>`<p class="dataHealthWarning">⚠ ${escapeHtml(w)}</p>`).join('')+'<small>Contrôle indicatif : aucune donnée modifiée.</small>';
  }catch(e){out.textContent='Impossible de terminer le contrôle : '+e.message;}
});


// Radar : pas de conseil automatique ni de comparaison entre devises différentes.
let opportunityChartInstance=null, opportunityInitialized=false, opportunityRequest=0;
function initializeOpportunity(){
  const select=document.getElementById('opportunityTitle');if(!select||!state)return;
  const old=select.value;
  const positions=state.positions||[];
  select.innerHTML=positions.map(p=>`<option value="${Number(p.id)}">${escapeHtml(p.name)}</option>`).join('');
  if(positions.some(p=>String(p.id)===old))select.value=old;
  if(opportunityInitialized)return;
  opportunityInitialized=true;
  const today=new Date();const end=new Date(today);end.setDate(end.getDate()-1);
  const start=new Date(end);start.setMonth(start.getMonth()-1);
  const localDate=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  document.getElementById('opportunityStart').value=localDate(start);
  document.getElementById('opportunityEnd').value=localDate(end);
  document.getElementById('opportunityRun').addEventListener('click',runOpportunity);
  for(const id of ['opportunityTitle','opportunityStart','opportunityEnd','opportunityQuantity']){
    document.getElementById(id).addEventListener('change',()=>{
      ++opportunityRequest;
      document.getElementById('opportunityResults').hidden=true;
      document.getElementById('opportunityStatus').textContent='Paramètres modifiés : lance la simulation pour actualiser les résultats.';
    });
  }
}
async function runOpportunity(){
  const get=id=>document.getElementById(id).value;
  const start=get('opportunityStart'),end=get('opportunityEnd'),quantity=Number(get('opportunityQuantity'));
  const status=document.getElementById('opportunityStatus'),results=document.getElementById('opportunityResults');
  const button=document.getElementById('opportunityRun');
  results.hidden=true;
  if(!start||!end||start>=end||!(quantity>0)||!Number.isFinite(quantity)){
    status.textContent='Renseigne une période croissante et une quantité strictement positive.';return;
  }
  const token=++opportunityRequest;button.disabled=true;status.textContent='Calcul des deux scénarios…';
  try{
    const params=new URLSearchParams({position_id:get('opportunityTitle'),start,end,quantity:String(quantity)});
    const data=await api('/api/opportunities/simulate?'+params.toString());
    if(token!==opportunityRequest)return;
    const f=data.final;
    for(const [id,value,percent] of [['opportunityRealGain',f.real_gain_eur,false],['opportunitySimGain',f.simulation_gain_eur,false],['opportunityRealPct',f.real_pct,true],['opportunitySimPct',f.simulation_pct,true],['opportunityImpactGain',data.impact_eur,false],['opportunityImpactPct',data.impact_pct,true]]){
      const el=document.getElementById(id);el.textContent=percent?fmtPct(value):euro.format(value);el.className=perfClass(Number(value));
    }
    document.getElementById('opportunityMethod').textContent=`${data.method} Achat fictif : ${euro.format(data.fictitious_cost_eur)}. Dernier cours : ${data.last_quote_date}.`;
    const warning=document.getElementById('opportunityWarnings');warning.hidden=!data.warnings?.length;
    document.getElementById('opportunityWarningText').textContent=(data.warnings||[]).join(' · ');
    results.hidden=false;
    if(opportunityChartInstance)opportunityChartInstance.destroy();
    opportunityChartInstance=new Chart(document.getElementById('opportunityChart'),{
      type:'line',data:{labels:data.points.map(p=>p.date),datasets:[
        {label:'Réel',data:data.points.map(p=>p.real_value_eur),borderColor:'#087cff',backgroundColor:'rgba(8,124,255,.08)',pointRadius:0,pointHoverRadius:4,borderWidth:2.5,tension:0.15,fill:false},
        {label:'Simulation',data:data.points.map(p=>p.simulation_value_eur),borderColor:'#b7791f',backgroundColor:'rgba(183,121,31,.08)',pointRadius:0,pointHoverRadius:4,borderWidth:2.5,tension:0.15,fill:false}
      ]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},
        plugins:{legend:{display:true,position:'bottom',labels:{usePointStyle:true,boxWidth:9}},tooltip:{callbacks:{label:c=>`${c.dataset.label} : ${euro.format(c.parsed.y)}`}}},
        scales:{x:{ticks:{autoSkip:true,maxTicksLimit:7,maxRotation:0}},y:{title:{display:true,text:'Valeur de la position (€)'},ticks:{callback:v=>euro.format(v)}}}}
    });
    status.textContent=`Simulation calculée pour ${data.position_name} du ${start} au ${end}.`;
  }catch(err){if(token===opportunityRequest)status.textContent=`Simulation impossible : ${err.message}`;}
  finally{if(token===opportunityRequest)button.disabled=false;}
}

let radarResults=[],radarBusy=false,radarSelected=null;
const radarNames={large:'ETF larges',theme:'ETF thématiques',stock:'Titres individuels',commodity:'Matières premières',unknown:'Non classés'};
function radarCategory(p){
 const n=String(p.name||'').toLowerCase(),t=String(p.asset_type||'').toLowerCase();
 if(/or physique|\bgold\b|silver|argent physique|commodit|matière première|\bpetrol/.test(n+' '+t))return 'commodity';
 if(/action|stock|equity individuelle/.test(t))return 'stock';
 if(/thémat|themat|sector|sectoriel|sectorial|nasdaq|technology|techno|cyber|semiconductor|healthcare|robot|clean energy|banks|banques/.test(n+' '+t))return 'theme';
 if(/world|s&p 500|stoxx 600|all.country|acwi|msci europe|global|europe 600|ftse 100|russell 2000|small cap/.test(n+' '+t))return 'large';
 return 'unknown';
}
function radarPercent(x){return x==null||!Number.isFinite(Number(x))?'—':fmtPct(Number(x))}
function radarValid(r){return Number.isFinite(r.day)&&Number.isFinite(r.week)&&!r.reason}
function radarMedian(vals){const a=vals.filter(Number.isFinite).sort((x,y)=>x-y);return a.length?(a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2):null}
function radarDecision(r,all){
 if(!radarValid(r))return {kind:'wait',label:'Attendre',why:r.reason||'Cours historiques insuffisants.'};
 if(r.category==='unknown')return {kind:'wait',label:'Attendre',why:'Catégorie non identifiée.'};
 const peers=all.filter(x=>x.key!==r.key&&radarValid(x));
 const group=peers.filter(x=>x.category===r.category);
 if(peers.length<2||group.length<1)return {kind:'wait',label:'Attendre',why:'Pas assez de titres comparables pour distinguer une baisse générale.'};
 const medianDay=radarMedian(peers.map(x=>x.day)),medianWeek=radarMedian(peers.map(x=>x.week));
 const decliningDay=peers.filter(x=>x.day<0).length/peers.length,decliningWeek=peers.filter(x=>x.week<0).length/peers.length;
 const groupDay=radarMedian(group.map(x=>x.day)),groupWeek=radarMedian(group.map(x=>x.week));
 const common=decliningDay>=0.6&&decliningWeek>=0.6&&medianDay<0&&medianWeek<0&&groupDay<0&&groupWeek<0;
 if(!(Number(r.position.avg_cost_eur)>0)||!Number.isFinite(Number(r.position.performance_pct)))return {kind:'wait',label:'Attendre',why:'PRU non exploitable.'};
 if(Number(r.position.performance_pct)>=0)return {kind:'wait',label:'Attendre',why:'Le dernier cours n’est pas inférieur au PRU.'};
 const weight=Number(r.position.weight_pct)||0,target=Number(r.position.target_pct)||0;
 if(target<=0||weight>=target)return {kind:'caution',label:'Prudence',why:'Poids cible atteint ou cible non définie : renforcer augmenterait la concentration.'};
 if(r.day<groupDay-2||r.week<groupWeek-3)return {kind:'caution',label:'Prudence',why:'Baisse sensiblement plus marquée que les autres actifs de la catégorie (1J ou 7J).'};
 if(!common)return {kind:'wait',label:'Attendre',why:'La baisse n’est pas suffisamment partagée sur 1J et 7J par le portefeuille et la catégorie.'};
 return {kind:'possible',label:'Achat à étudier',why:'Cours inférieur au PRU, baisse partagée sur 1J et 7J et poids sous sa cible. Vérifier budget et risques avant de renforcer.'};
}
function renderRadar(){
 const box=document.querySelector('#radarRows'),summary=document.querySelector('#radarSummary');if(!box||!state)return;
 const cat=document.querySelector('#radarCategory').value;
 const positions=(state.positions||[]).filter(p=>cat==='all'||radarCategory(p)===cat);
 if(!radarResults.length){box.innerHTML=`<p class="muted">${positions.length} position(s) dans la sélection. Lance l’analyse pour comparer les variations 1J et 7J.</p>`;summary.hidden=true;return;}
 const priority={possible:0,caution:1,wait:2};
 const rows=radarResults.filter(r=>cat==='all'||r.category===cat).sort((a,b)=>{
  const rank=(priority[a.decision.kind]??3)-(priority[b.decision.kind]??3);
  if(rank)return rank;
  // Au sein d'un statut, le plus fort rabais au PRU est prioritaire.
  const gap=r=>{const n=Number(r.position.performance_pct);return Number.isFinite(n)?n:Infinity;};
  const difference=gap(a)-gap(b);
  if(difference)return difference;
  return String(a.position.name||'').localeCompare(String(b.position.name||''),'fr')||String(a.position.id).localeCompare(String(b.position.id));
 });
 const counts={possible:0,caution:0,wait:0};rows.forEach(r=>counts[r.decision.kind]++);
 summary.hidden=false;summary.innerHTML=`<span class="radarPossible">${counts.possible} achat(s) à étudier</span><span class="radarCaution">${counts.caution} prudence</span><span>${counts.wait} attendre</span>`;
 box.innerHTML=rows.length?rows.map(r=>{
  const opened=radarSelected===r.position.id;
  return `<div class="radarItem"><button type="button" class="radarRow ${opened?'selected':''}" data-radar-id="${r.position.id}" aria-expanded="${opened}" aria-controls="radarDetail-${r.position.id}"><span class="radarRowName"><strong>${escapeHtml(r.position.name)}</strong><small>${escapeHtml(radarNames[r.category])}</small></span><span>PRU <b class="${perfClass(Number(r.position.performance_pct))}">${radarPercent(r.position.performance_pct)}</b></span><span>1J <b class="${perfClass(r.day)}">${radarPercent(r.day)}</b><br>7J <b class="${perfClass(r.week)}">${radarPercent(r.week)}</b></span><span class="radarTag ${r.decision.kind}">${escapeHtml(r.decision.label)} <span aria-hidden="true">${opened?'▴':'▾'}</span></span></button>${opened?`<div class="radarDetail radarDetailInline" id="radarDetail-${r.position.id}">${radarDetailHtml(r)}</div>`:''}</div>`;
 }).join(''):'<p class="muted">Aucun actif dans cette catégorie.</p>';
 box.querySelectorAll('[data-radar-id]').forEach(el=>el.addEventListener('click',()=>{
  const id=Number(el.dataset.radarId);
  radarSelected=radarSelected===id?null:id;
  renderRadar();
 }));
 // L'ancien panneau situé après la liste n'est plus utilisé.
 const oldDetail=document.querySelector('#radarDetail');if(oldDetail){oldDetail.hidden=true;oldDetail.innerHTML='';}

}
function radarDetailHtml(r){
 const peers=radarResults.filter(x=>x.key!==r.key&&radarValid(x));
 const group=peers.filter(x=>x.category===r.category);
 const medDay=radarMedian(peers.map(x=>x.day)),medWeek=radarMedian(peers.map(x=>x.week));
 const groupDay=radarMedian(group.map(x=>x.day)),groupWeek=radarMedian(group.map(x=>x.week));
 const declines=peers.length?`${peers.filter(x=>x.day<0).length}/${peers.length} sur 1J et ${peers.filter(x=>x.week<0).length}/${peers.length} sur 7J`:'Comparaison indisponible';
 const bars=[r,...group].map(x=>`<div class="radarBarRow"><span>${escapeHtml(x.position.name)}</span><div class="radarBarTrack"><i style="width:${Math.min(100,Math.abs(x.week||0)*5)}%" class="${x.week<0?'negative':'positive'}"></i></div><b>${radarPercent(x.week)}</b></div>`).join('');
 return `<h3>${escapeHtml(r.position.name)} · ${escapeHtml(radarNames[r.category])}</h3><div class="radarMetrics"><span>Écart au PRU <strong class="${perfClass(Number(r.position.performance_pct))}">${radarPercent(r.position.performance_pct)}</strong></span><span>Variation 1J <strong class="${perfClass(r.day)}">${radarPercent(r.day)}</strong></span><span>Variation 7J <strong class="${perfClass(r.week)}">${radarPercent(r.week)}</strong></span><span>Poids / cible <strong>${fmtTarget(r.position.weight_pct)} / ${fmtTarget(r.position.target_pct)}</strong></span><span>Médiane portefeuille 1J / 7J <strong>${radarPercent(medDay)} / ${radarPercent(medWeek)}</strong></span><span>Médiane catégorie 1J / 7J <strong>${radarPercent(groupDay)} / ${radarPercent(groupWeek)}</strong></span></div><p class="muted">Autres actifs en baisse : ${declines}. Les titres détenus plusieurs fois sont comptés une seule fois dans la comparaison.</p><h4>Autres actifs de la catégorie · 7 jours</h4>${bars||'<p>Pas de comparaison disponible.</p>'}<div class="radarConclusion ${r.decision.kind}"><strong>${escapeHtml(r.decision.label)}</strong><p>${escapeHtml(r.decision.why)}</p></div><p class="muted">${escapeHtml(r.reason||'')} Dernières clôtures : ${escapeHtml(r.asOf||'indisponibles')}. Une baisse commune du portefeuille ne prouve pas une baisse de l’ensemble du marché. Indication informative, non prédictive.</p>`;
}
async function analyzeRadar(){
 if(radarBusy||!state)return;radarBusy=true;radarResults=[];radarSelected=null;
 const button=document.querySelector('#radarAnalyzeBtn'),status=document.querySelector('#radarStatus');button.disabled=true;
 const positions=state.positions||[],cache=new Map();
 try{
  for(let i=0;i<positions.length;i++){
   const p=positions[i],category=radarCategory(p);status.textContent=`Analyse 1J / 7J : ${i+1} / ${positions.length} · ${p.name}`;
   const key=String(p.isin||p.market_symbol||p.id).toUpperCase();
   let record=cache.get(key);
   if(!record){
    record={day:null,week:null,reason:null,asOf:null};
    if(category==='unknown')record.reason='Catégorie non identifiée';
    else if(String(p.currency||'EUR').toUpperCase()!=='EUR')record.reason='Historique EUR indisponible : conversion historique requise';
    else{
     try{
      const [one,seven]=await Promise.all([api(`/api/positions/${encodeURIComponent(p.id)}/security-history?period=1J`),api(`/api/positions/${encodeURIComponent(p.id)}/security-history?period=1S`)]);
      if(one.reason||seven.reason)record.reason=`1J : ${one.reason||'OK'} ; 7J : ${seven.reason||'OK'}`;
      else if(!Number.isFinite(Number(one.performance_pct))||!Number.isFinite(Number(seven.performance_pct)))record.reason='Variations historiques indisponibles';
      else if(!one.as_of||!seven.as_of||one.as_of!==seven.as_of||(Date.now()-new Date(one.as_of+'T12:00:00Z').getTime())>5*86400000)record.reason='Clôtures incohérentes ou trop anciennes';
      else {record.day=Number(one.performance_pct);record.week=Number(seven.performance_pct);record.asOf=one.as_of;}
     }catch(e){record.reason=e.message||'Historique indisponible';}
    }
    cache.set(key,record);
   }
   radarResults.push({position:p,category,key,...record});
  }
  const distinct=[...new Map(radarResults.map(r=>[r.key,r])).values()];
  radarResults.forEach(r=>{r.decision=radarDecision(r,distinct);});
  status.textContent=`Analyse terminée · ${distinct.filter(radarValid).length}/${distinct.length} titres distincts avec historiques 1J et 7J exploitables.`;
  radarSelected=null;renderRadar();
 }finally{radarBusy=false;button.disabled=false;}
}
document.querySelector('#radarCategory')?.addEventListener('change',renderRadar);
document.querySelector('#radarAnalyzeBtn')?.addEventListener('click',()=>analyzeRadar().catch(e=>{document.querySelector('#radarStatus').textContent=`Analyse interrompue : ${e.message}`;radarBusy=false;document.querySelector('#radarAnalyzeBtn').disabled=false;}));
