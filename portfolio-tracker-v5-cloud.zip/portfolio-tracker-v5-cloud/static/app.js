let state=null, analyticsState=null, allocationChart=null, overviewPortfolioChart=null, effortChart=null, historyChart=null, positionHistoryCharts=new Map(), searchContext=null, selectedAddInstrument=null, transactionFilterPositionId=null;
let projectionCharts=[];
let activeTab="overview";
let tableSort={key:null,direction:'asc'};
let positionView='TOTAL';
let positionMetric=localStorage.getItem('portfolioPositionMetric')||'day_pct';
const expandedPositionIds=new Set();
const euro=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'});
const num=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:6});

async function api(url,options={}){
  const r=await fetch(url,{headers:{'Content-Type':'application/json','Cache-Control':'no-cache'},cache:'no-store',...options});
  const raw=await r.text(); let data={};
  try{data=raw?JSON.parse(raw):{}}catch{data={detail:raw||`Erreur HTTP ${r.status}`}}
  if(r.status===401){location.href='/login';throw new Error('Session expirée');}
  if(!r.ok) throw new Error(data.detail||`Erreur HTTP ${r.status}`);
  return data;
}
const perfClass=v=>v>0?'good':v<0?'bad':'';
function fmtPct(v){if(v===null||v===undefined||Number.isNaN(+v))return '—';const n=+v;return `${n>=0?'+':''}${n.toFixed(2)} %`}
function fmtNative(p){if(p.manual_active)return euro.format(p.manual_price||p.last_price_eur||0);const value=p.last_native_price??p.last_price_eur??0;try{return new Intl.NumberFormat('fr-FR',{style:'currency',currency:(p.currency||'EUR').toUpperCase(),maximumFractionDigits:4}).format(value)}catch{return `${num.format(value)} ${p.currency||''}`}}
function fmtCurrencyValue(v,c){try{return new Intl.NumberFormat('fr-FR',{style:'currency',currency:c||'EUR',maximumFractionDigits:4}).format(v)}catch{return `${num.format(v)} ${c||''}`}}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function marketLabel(p){if(p.manual_active)return `Manuel · ${euro.format(p.manual_price||p.last_price_eur||0)}${p.manual_price_note?` · ${p.manual_price_note}`:''}`;const bits=[p.provider,p.market_symbol,p.isin,p.exchange,p.currency,p.quote_quality].filter(Boolean);return bits.join(' · ')}
function fmtTarget(v){return `${(+v||0).toFixed(1)} %`}
function fmtGap(v){const n=+v||0;return `${n>=0?'+':''}${n.toFixed(2)} pt`}
function fmtTimestamp(epoch){if(!epoch)return '—';const d=new Date(Number(epoch)*1000);if(Number.isNaN(d.getTime()))return '—';return new Intl.DateTimeFormat('fr-FR',{dateStyle:'short',timeStyle:'short'}).format(d)}
function renderLastQuoteUpdate(){const el=document.querySelector('#lastQuoteUpdate');if(!el||!state)return;const checked=(state.positions||[]).map(p=>Number(p.quote_checked_at)||0).filter(Boolean);if(checked.length){el.textContent=`Dernière vérification des sources : ${fmtTimestamp(Math.max(...checked))} · la date du cours figure sur chaque ligne.`;return;}const times=(state.positions||[]).map(p=>Number(p.price_updated_at)||0).filter(Boolean);el.textContent=times.length?`Cours le plus récent en portefeuille : ${fmtTimestamp(Math.max(...times))} · vérifie la date propre à chaque titre.`:'Aucun cours encore actualisé';}

function renderQuoteQualitySummary(){
  const el=document.querySelector('#quoteQualitySummary');if(!el||!state)return;
  const rows=(state.positions||[]).filter(p=>p.quote_configured||p.manual_active||Number(p.last_price_eur)>0);
  const manual=rows.filter(p=>p.manual_active).length;
  const problem=rows.filter(p=>!p.manual_active&&(p.quote_stale||p.quote_refresh_error)).length;
  const fresh=Math.max(0,rows.length-manual-problem);
  const checked=rows.map(p=>Number(p.quote_checked_at)||Number(p.price_updated_at)||0).filter(Boolean);
  const last=checked.length?fmtTimestamp(Math.max(...checked)):'—';
  el.innerHTML=`<span class="qualityGood">${fresh} à jour</span> · ${manual} manuel${manual>1?'s':''} · <span class="${problem?'qualityBad':''}">${problem} ancien${problem>1?'s':''}/échec</span> · <span class="qualityTime">${escapeHtml(last)}</span>`;
}


async function load(){
  state=await api('/api/portfolio');
  analyticsState=await api('/api/analytics');
  document.querySelector('#totalValue').textContent=euro.format(state.total_value);
  document.querySelector('#invested').textContent=euro.format(state.invested_estimate);
  const pnl=document.querySelector('#pnl');pnl.textContent=euro.format(state.pnl_estimate);pnl.className=perfClass(state.pnl_estimate);
  const perf=document.querySelector('#perf');perf.textContent=fmtPct(state.performance_estimate_pct);perf.className=perfClass(state.performance_estimate_pct);
  document.querySelector('#mode').textContent=`${state.quote_mode} · v${state.app_version}`;
  document.querySelector('#planValue').textContent=euro.format(state.monthly_plan);
  document.querySelector('#planAsset').textContent=state.monthly_plan_asset;
  renderTable();renderPositionCards();renderLastQuoteUpdate();renderQuoteQualitySummary();renderAnalytics();renderActiveTab();
}


function sortValue(p,key){
  switch(key){
    case 'name': return String(p.name||'').toLocaleLowerCase('fr');
    case 'account': return String(p.account||'').toLocaleLowerCase('fr');
    case 'quantity': return Number(p.quantity)||0;
    case 'market_price': return Number(p.last_native_price??p.last_price_eur??0)||0;
    case 'position_value': return Number(p.position_value)||0;
    case 'weight_pct': return Number(p.weight_pct)||0;
    case 'target_pct': return Number(p.target_pct)||0;
    case 'performance_pct': return Number(p.performance_pct)||0;
    case 'day_change_pct': return Number(p.day_change_pct)||0;
    case 'source': return String([p.last_quote_provider||p.provider,p.market_symbol,p.isin,p.quote_quality].filter(Boolean).join(' ')).toLocaleLowerCase('fr');
    default: return 0;
  }
}
function positionRows(){
  const rows=[...(state?.positions||[])];
  if(positionView==='TOTAL')return rows;
  return rows.filter(p=>String(p.account||'').toUpperCase()===positionView);
}
function positionViewTotals(){
  const rows=positionRows();
  const value=rows.reduce((s,p)=>s+(Number(p.position_value)||0),0);
  const invested=rows.reduce((s,p)=>s+(Number(p.invested_estimate)||0),0);
  const pnl=invested?value-invested:0;
  const performance=invested?(value/invested-1)*100:0;
  const target=rows.reduce((s,p)=>s+(Number(p.target_pct)||0),0);
  return {rows,value,invested,pnl,performance,target};
}
function displayWeight(p){
  const total=positionViewTotals().value;
  return total?((Number(p.position_value)||0)/total*100):0;
}
function renderPositionViewSummary(){
  if(!state)return;
  const t=positionViewTotals();
  const label=positionView==='TOTAL'?'portefeuille global':positionView;
  document.querySelector('#positionViewValue').textContent=euro.format(t.value);
  document.querySelector('#positionViewInvested').textContent=euro.format(t.invested);
  const pnl=document.querySelector('#positionViewPnl');pnl.textContent=euro.format(t.pnl);pnl.className=perfClass(t.pnl);
  const perf=document.querySelector('#positionViewPerf');perf.textContent=fmtPct(t.performance);perf.className=perfClass(t.performance);
  const note=document.querySelector('#positionViewNote');if(note)note.textContent=`Vue ${label} · ${t.rows.length} ligne${t.rows.length>1?'s':''}. Le poids est recalculé dans cette vue.`;
  const ts=document.querySelector('#targetSummary');if(ts)ts.textContent=`Somme des poids cibles dans cette vue : ${t.target.toFixed(1)} %${positionView==='TOTAL'?(Math.abs(t.target-100)<0.05?' · allocation cible complète':' · à compléter'):''}`;
  document.querySelectorAll('[data-position-view]').forEach(btn=>btn.classList.toggle('active',btn.dataset.positionView===positionView));
}
function sortedPositions(){
  const rows=positionRows();
  if(!tableSort.key)return rows;
  const sign=tableSort.direction==='asc'?1:-1;
  return rows.sort((a,b)=>{
    const av=sortValue(a,tableSort.key),bv=sortValue(b,tableSort.key);
    if(typeof av==='string'||typeof bv==='string')return String(av).localeCompare(String(bv),'fr',{numeric:true,sensitivity:'base'})*sign;
    return (av-bv)*sign;
  });
}
function updateSortHeaders(){
  document.querySelectorAll('th[data-sort]').forEach(th=>{
    const active=th.dataset.sort===tableSort.key;
    th.setAttribute('aria-sort',active?(tableSort.direction==='asc'?'ascending':'descending'):'none');
    const icon=th.querySelector('.sortBtn span');
    if(icon)icon.textContent=active?(tableSort.direction==='asc'?'↑':'↓'):'↕';
  });
}
function initTableSorting(){
  document.querySelectorAll('th[data-sort] .sortBtn').forEach(btn=>{
    if(btn.dataset.bound==='1')return;
    btn.addEventListener('click',()=>{
      const key=btn.closest('th').dataset.sort;
      if(tableSort.key===key)tableSort.direction=tableSort.direction==='asc'?'desc':'asc';
      else tableSort={key,direction:'asc'};
      renderTable();
    });
    btn.dataset.bound='1';
  });
}
function renderTable(){
  const body=document.querySelector('#positionsBody');body.innerHTML='';
  for(const p of sortedPositions()){
    const tr=document.createElement('tr');tr.dataset.id=p.id;
    const isEod=String(p.quote_quality||'').toLowerCase().includes('clôture');
    const asof=p.price_updated_at?(isEod?`séance ${escapeHtml((p.quote_note||'').match(/\d{4}-\d{2}-\d{2}/)?.[0]||fmtTimestamp(p.price_updated_at))}`:`cours au ${escapeHtml(fmtTimestamp(p.price_updated_at))}`):'pas encore actualisé';
    const source=p.quote_configured
      ? `<button type="button" class="linkBtn" data-config-id="${p.id}">Configurer</button><br><span class="sourceTag">${escapeHtml(p.market_symbol)}</span><br><span class="muted">${escapeHtml([p.last_quote_provider||p.provider,p.exchange,p.quote_quality].filter(Boolean).join(' · '))}</span><br><span class="muted">${asof}</span>${p.quote_checked_at?`<br><span class="muted">Vérifié le ${escapeHtml(fmtTimestamp(p.quote_checked_at))}</span>`:''}${p.quote_stale?`<br><span class="quoteAgeWarning" title="${escapeHtml(p.quote_warning)}">Cours ancien · vérifier la source</span>`:''}`
      : `<button type="button" class="linkBtn" data-config-id="${p.id}">Configurer</button><br><span class="muted">Instrument non associé</span>`;
    tr.innerHTML=`<td><strong>${escapeHtml(p.name)}</strong><br><span class="muted">${escapeHtml(p.asset_type)}${p.transaction_count?` · ${p.transaction_count} op.`:''}</span><br><button type="button" class="miniTx" data-tx-id="${p.id}">+ transaction</button>${p.quote_configured?` <button type="button" class="miniTx quoteRefresh" data-refresh-id="${p.id}">Actualiser ce titre</button>`:''}</td>
      <td>${escapeHtml(p.account)}</td><td>${num.format(p.quantity)}</td>
      <td>${p.quote_configured?fmtNative(p):'<span class="muted">non connecté</span>'}</td>
      <td><strong>${euro.format(p.position_value)}</strong></td>
      <td><strong>${displayWeight(p).toFixed(2)} %</strong></td>
      <td>${fmtTarget(p.target_pct)}</td>
      <td class="${perfClass(p.performance_pct)}">${fmtPct(p.performance_pct)}</td>
      <td class="${perfClass(p.day_change_pct)}">${fmtPct(p.day_change_pct)}</td><td>${source}</td>`;
    tr.addEventListener('click',e=>{if(e.target.closest('.linkBtn,.miniTx,.quoteRefresh'))return;openEdit(p)});body.appendChild(tr);
  }
  body.querySelectorAll('[data-config-id]').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();const p=state.positions.find(x=>x.id===+btn.dataset.configId);openEdit(p)}));
  body.querySelectorAll('[data-tx-id]').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();openTransactions(+btn.dataset.txId)}));
  body.querySelectorAll('[data-refresh-id]').forEach(button=>button.addEventListener('click',event=>{event.stopPropagation();startQuoteRefresh({position_id:+button.dataset.refreshId});}));
  setQuoteBusy(quoteRefreshBusy);
  const totals=positionViewTotals();
  const weightTotal=totals.value>0?100:0;
  const targetTotal=totals.target;
  const weightEl=document.querySelector('#weightTotal'); if(weightEl) weightEl.innerHTML=`<strong>${weightTotal.toFixed(2)} %</strong>`;
  const targetEl=document.querySelector('#targetTotal'); if(targetEl) targetEl.innerHTML=`<strong>${targetTotal.toFixed(1)} %</strong>`;
  renderPositionViewSummary();
  updateSortHeaders();
  requestAnimationFrame(syncPositionScroll);
}


function positionLogoText(p){
  const n=String(p.name||'').toUpperCase();
  if(n.includes('S&P'))return 'S&P';
  if(n.includes('ROLLS'))return 'RR';
  if(n.includes('STOXX'))return 'STO';
  if(n.includes('XIAOMI'))return 'MI';
  if(n.includes('TOTALENERGIES'))return 'TE';
  if(n.includes('AIRLINES'))return 'H';
  if(n.includes('RUSSELL'))return 'R2K';
  if(n.includes('MSCI')||n.includes('GLOBAL'))return 'MSCI';
  return String(p.name||'PT').split(/\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase().slice(0,4);
}

function positionLocalLogo(p){
  const n=String(p.name||'').toUpperCase();
  if(n.includes('MSCI WORLD')&&!n.includes('ALL COUNTRY'))return '/static/logos/msci-world.png';
  if(n.includes('S&P 500'))return '/static/logos/sp500.png';
  if(n.includes('PEA GLOBAL'))return '/static/logos/pea-global.png';
  if(n.includes('MSCI ALL COUNTRY')||n.includes('ACWI'))return '/static/logos/acwi.png';
  if(n.includes('STOXX EUROPE 600 BANK'))return '/static/logos/stoxx-banks.png';
  if(n.includes('RUSSELL 2000'))return '/static/logos/russell2000.png';
  if(n.includes('AIRLINES')||n.includes('HOTELS')||n.includes('CRUISE'))return '/static/logos/travel.png';
  if(n.includes('PHYSICAL GOLD')||n.includes('ISHARES PHYSICAL GOLD'))return '/static/logos/gold.png';
  if(n.includes('ENHANCED COMMODITY')||n.includes('COMMODITY EX-AGRI'))return '/static/logos/commodities.png';
  return '';
}
function positionLogoDomain(p){
  const n=String(p.name||'').toUpperCase();
  if(n.includes('ROLLS'))return 'rolls-royce.com';
  if(n.includes('XIAOMI'))return 'mi.com';
  if(n.includes('TOTALENERGIES'))return 'totalenergies.com';
  return '';
}
function positionLogoMarkup(p){
  const fallback=escapeHtml(positionLogoText(p));
  const local=positionLocalLogo(p);
  const domain=positionLogoDomain(p);
  const src=local||(domain?`https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=256`:'');
  if(!src)return `<span class="logoFallback">${fallback}</span>`;
  return `<img src="${src}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><span class="logoFallback" style="display:none">${fallback}</span>`;
}
function dayValueChange(p){
  const current=Number(p.position_value)||0,pct=Number(p.day_change_pct);
  if(!Number.isFinite(pct)||Math.abs(100+pct)<1e-9)return null;
  const previous=current/(1+pct/100);
  return current-previous;
}
function positionMetricValue(p){
  if(positionMetric==='since_pct')return {value:Number(p.performance_pct),text:fmtPct(p.performance_pct)};
  if(positionMetric==='day_eur'){const v=dayValueChange(p);return {value:v,text:v==null?'—':`${v>=0?'+':''}${euro.format(v)}`};}
  if(positionMetric==='since_eur'){const v=(Number(p.position_value)||0)-(Number(p.invested_estimate)||0);return {value:v,text:`${v>=0?'+':''}${euro.format(v)}`};}
  return {value:Number(p.day_change_pct),text:fmtPct(p.day_change_pct)};
}
function positionSourceShort(p){
  if(p.manual_active)return `Manuel${p.manual_price_note?` · ${p.manual_price_note}`:''}`;
  return [p.last_quote_provider||p.provider,p.quote_quality].filter(Boolean).join(' · ')||'—';
}
function transactionTypeLabel(t){return ({buy:'Achat',sell:'Vente',dividend:'Dividende',fee:'Frais',deposit:'Versement',withdrawal:'Retrait',opening:'Solde initial'})[t]||t||'—';}
function transactionFrameworkLabel(t){return (t.investment_framework==='Autre'?(t.framework_label||'Autre'):(t.investment_framework||t.origin||''));}
function enableHistoryRowActions(container, selector){
  const rows=container.matches?.(selector)?[container]:Array.from(container.querySelectorAll(selector));
  for(const row of rows){
    const toggle=()=>{
      const next=!row.classList.contains('actionsVisible');
      const parent=row.parentElement;
      parent?.querySelectorAll('.expandableHistoryRow.actionsVisible').forEach(other=>{if(other!==row){other.classList.remove('actionsVisible');other.setAttribute('aria-expanded','false');}});
      row.classList.toggle('actionsVisible',next);
      row.setAttribute('aria-expanded',String(next));
    };
    row.addEventListener('click',event=>{if(event.target.closest('button,a,input,select,textarea'))return;toggle();});
    row.addEventListener('keydown',event=>{if(event.target!==row)return;if(event.key==='Enter'||event.key===' '){event.preventDefault();toggle();}});
  }
}
async function loadInlineHistory(positionId,box){
  if(!box||box.dataset.loaded==='1')return;
  box.innerHTML='<p class="muted">Chargement de l’historique…</p>';
  try{
    const r=await api(`/api/positions/${positionId}/ledger-history`);
    const tx=(r.transactions||[]).slice().sort((a,b)=>String(a.transaction_date||'').localeCompare(String(b.transaction_date||''))||(Number(a.id)||0)-(Number(b.id)||0));
    const rec=r.reconciliation||{};
    const rows=tx.length?tx.map(t=>{
      const type=t.transaction_type==='opening'?'Position initiale avant suivi':transactionTypeLabel(t.transaction_type), framework=transactionFrameworkLabel(t);
      let amount=Number(t.gross_amount_eur)||0;
      let detail='';
      if(t.transaction_type==='buy'||t.transaction_type==='sell'||t.transaction_type==='opening')detail=`${num.format(Math.abs(Number(t.quantity)||0))} × ${euro.format(Number(t.unit_price_eur)||0)}`;
      else detail=euro.format(amount);
      const openingAction=t.transaction_type==='opening'?`<button type="button" class="historyEditOpening" data-opening-id="${positionId}">Modifier / réconcilier</button>`:`<button type="button" class="historyEditTx" data-tx-id="${t.id}">Modifier</button> <button type="button" class="danger historyDeleteTx" data-tx-id="${t.id}">Supprimer</button>`;
      return `<div class="positionHistoryRow expandableHistoryRow ${t.transaction_type==='opening'?'openingRow':''}" tabindex="0" role="button" aria-expanded="false" aria-label="Afficher les actions de cette opération"><div><strong class="${t.transaction_type==='buy'?'good':t.transaction_type==='sell'?'bad':''}">${escapeHtml(type)}</strong><span>${escapeHtml(t.transaction_date==='1900-01-01'?'Avant suivi':t.transaction_date||'')}</span></div><div><b>${escapeHtml(framework||'Sans catégorie')}</b><span>${detail}</span>${openingAction}</div><div class="positionHistoryAmount">${euro.format(amount)}${Number(t.fees_eur)?`<small>frais ${euro.format(Number(t.fees_eur))}</small>`:''}</div></div>`;
    }).join(''):'<p class="muted">Aucun mouvement enregistré sur cette ligne.</p>';
    const chartId=`positionHistoryChart-${positionId}`;
    box.innerHTML=`<div class="positionHistoryChartBox"><div class="positionHistoryChartHead"><strong>Évolution de la position</strong><span>${escapeHtml(r.valuation_note||'')}</span></div><div class="chartWrap positionHistoryChart"><canvas id="${chartId}"></canvas></div></div><div class="positionHistoryList">${rows}</div><button type="button" class="danger historyDeletePosition">Supprimer ce titre et tout son historique</button>`;
    enableHistoryRowActions(box, '.expandableHistoryRow');
    box.querySelector('.historyEditOpening')?.addEventListener('click',()=>openOpeningDialog(positionId,r));
    box.querySelectorAll('.historyEditTx').forEach(b=>b.addEventListener('click',()=>{const t=tx.find(x=>x.id===Number(b.dataset.txId));if(t)editHistoryTransaction(t)}));
    box.querySelectorAll('.historyDeleteTx').forEach(b=>b.addEventListener('click',()=>{const t=tx.find(x=>x.id===Number(b.dataset.txId));if(t)deleteHistoryTransaction(t,positionId)}));
    box.querySelector('.historyDeletePosition')?.addEventListener('click',()=>deleteHistoryPosition(positionId));
    renderPositionLedgerChart(positionId,r.points||[],chartId);
    box.dataset.loaded='1';
  }catch(err){box.innerHTML=`<p class="status errorBox">${escapeHtml(err.message)}</p>`;}
}
function renderPositionLedgerChart(positionId,points,chartId){
  const canvas=document.getElementById(chartId);if(!canvas||typeof Chart==='undefined'||!points.length)return;
  const old=positionHistoryCharts.get(positionId);if(old)old.destroy();
  const labels=points.map(p=>p.type==='current'?'Aujourd’hui':(p.date==='1900-01-01'?'Initial':p.date));
  const chart=new Chart(canvas,{type:'line',data:{labels,datasets:[{label:'Valeur reconstituée',data:points.map(p=>p.position_value_after),borderColor:'#087cff',backgroundColor:'rgba(8,124,255,.08)',fill:true,tension:.18,pointRadius:3},{label:'Capital investi',data:points.map(p=>p.cost_basis_after),borderColor:'#00b956',borderDash:[5,4],tension:.18,pointRadius:2}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${euro.format(c.raw)}`}}},scales:{x:{ticks:{maxTicksLimit:7}},y:{ticks:{callback:v=>new Intl.NumberFormat('fr-FR',{notation:'compact'}).format(v)+' €'}}}}});
  positionHistoryCharts.set(positionId,chart);
}
let editingTransactionId=null;
async function deleteHistoryTransaction(t, positionId){
  if(!confirm('Supprimer définitivement cette opération ? La position sera recalculée.'))return;
  try{await api(`/api/transactions/${t.id}`,{method:'DELETE'});await load();renderPositionCards();}
  catch(err){alert(err.message)}
}
async function deleteHistoryPosition(positionId){
  const p=state.positions.find(x=>x.id===positionId);if(!p)return;
  if(!confirm(`Supprimer définitivement « ${p.name} » et TOUT son historique de transactions ?\n\nCette opération ne touche pas à Trade Republic.`))return;
  if(!confirm('Dernière confirmation : cette suppression est irréversible sans restauration de sauvegarde.'))return;
  try{await api(`/api/positions/${positionId}`,{method:'DELETE'});await load();renderPositionCards();}
  catch(err){alert(err.message)}
}
async function editHistoryTransaction(t){
  activateTab('transactions');
  transactionFilterPositionId=t.position_id;
  fillTxPositions(t.position_id);
  document.querySelector('#txPosition').value=String(t.position_id);
  document.querySelector('#txPosition').disabled=true;
  document.querySelector('#txType').value=t.transaction_type;
  document.querySelector('#txDate').value=t.transaction_date;
  document.querySelector('#txOrigin').value=t.investment_framework||'Investissement libre';
  document.querySelector('#txCustom').value=t.framework_label||'';
  document.querySelector('#txQty').value=t.quantity??'';
  document.querySelector('#txUnitPrice').value=t.unit_price_eur??'';
  document.querySelector('#txAmount').value=t.gross_amount_eur??'';
  document.querySelector('#txFees').value=t.fees_eur??0;
  document.querySelector('#txNote').value=t.note||'';
  editingTransactionId=t.id;
  document.querySelector('#saveTransactionBtn').textContent='Enregistrer les modifications';
  document.querySelector('#txStatus').textContent='Modification de l’opération sélectionnée';
  syncTxAccount();updateTxFields();await loadTransactions(t.position_id);
}
function resetTransactionEditing(){editingTransactionId=null;document.querySelector('#txPosition').disabled=false;document.querySelector('#saveTransactionBtn').textContent='Enregistrer la transaction'}
let openingContext=null;
function openingRecText(rec){
  if(!rec)return '';
  const gap=Number(rec.quantity_gap)||0;
  const err=(rec.history_only_errors||[])[0];
  if(err)return `<strong>Historique incomplet/incompatible.</strong><br>${escapeHtml(err)}`;
  if(Math.abs(gap)<1e-7)return `<strong class="good">Historique cohérent.</strong><br>Les mouvements antérieurs au début du suivi reconstituent exactement la position initiale (${num.format(rec.opening_quantity||0)} titre(s)). Elle peut être remplacée par l’historique.`;
  return `<strong>Écart restant : ${num.format(gap)} titre(s).</strong><br>Position initiale : ${num.format(rec.opening_quantity||0)} · historique antérieur au ${escapeHtml(rec.tracking_start_date||'début du suivi')} : ${num.format(rec.history_before_tracking_quantity||0)}. Continue à saisir les anciens mouvements ou réduis la position initiale.`;
}
function openOpeningDialog(positionId,ledgerData){
  const rec=ledgerData?.reconciliation||{};const op=rec.opening;if(!op)return;
  openingContext={positionId,ledgerData};
  document.querySelector('#openingPositionId').value=positionId;
  document.querySelector('#openingQty').value=Number(op.quantity)||0;
  document.querySelector('#openingPru').value=Number(op.unit_price_eur)||0;
  document.querySelector('#openingReconciliation').innerHTML=openingRecText(rec);
  document.querySelector('#openingStatus').textContent='';
  document.querySelector('#replaceOpeningBtn').disabled=!rec.can_replace_opening;
  document.querySelector('#openingDialog').showModal();
}
async function refreshOpeningContext(){
  if(!openingContext)return;
  const r=await api(`/api/positions/${openingContext.positionId}/ledger-history`);openingContext.ledgerData=r;
  document.querySelector('#openingReconciliation').innerHTML=openingRecText(r.reconciliation);
  document.querySelector('#replaceOpeningBtn').disabled=!r.reconciliation?.can_replace_opening;
}

function renderPositionCards(){
  const host=document.querySelector('#positionCards');if(!host||!state)return;
  const rows=positionRows();
  const selector=document.querySelector('#positionMetricSelect');if(selector&&selector.value!==positionMetric)selector.value=positionMetric;
  host.innerHTML='';
  if(!rows.length){host.innerHTML='<p class="muted">Aucune position dans cette vue.</p>';return;}
  for(const p of rows){
    const metric=positionMetricValue(p),isOpen=expandedPositionIds.has(+p.id);
    const card=document.createElement('article');card.className=`positionCard${isOpen?' open':''}`;card.dataset.positionCard=p.id;
    const latent=(Number(p.position_value)||0)-(Number(p.invested_estimate)||0);
    card.innerHTML=`
      <button type="button" class="positionCardSummary" aria-expanded="${isOpen?'true':'false'}">
        <span class="positionLogo">${positionLogoMarkup(p)}</span>
        <span class="positionIdentity"><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.asset_type||'')} · ${escapeHtml(p.account||'')}</small><span class="positionInlineData"><span class="positionNumCol">${new Intl.NumberFormat("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(p.last_price_eur)||0)} <i>|</i></span><span class="positionNumCol">${new Intl.NumberFormat("fr-FR",{minimumFractionDigits:4,maximumFractionDigits:4}).format(Number(p.quantity)||0)} <i>|</i></span><span class="positionNumCol">${new Intl.NumberFormat("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(p.position_value)||0)} <i>|</i></span></span></span>
        <span class="positionMetric ${perfClass(metric.value)}">${escapeHtml(metric.text)}</span>
      </button>
      <div class="positionCardDetail" ${isOpen?'':'hidden'}>
        <div class="positionDetailGrid">
          <div><span>PRU</span><strong>${p.avg_cost_eur==null?'—':euro.format(Number(p.avg_cost_eur))}</strong></div>
          <div><span>+/- value</span><strong class="${perfClass(latent)}">${euro.format(latent)}</strong></div>
          <div><span>Performance</span><strong class="${perfClass(p.performance_pct)}">${fmtPct(p.performance_pct)}</strong></div>
          <div><span>Poids actuel</span><strong>${displayWeight(p).toFixed(2)} %</strong></div>
          <div><span>Poids cible</span><strong>${fmtTarget(p.target_pct)}</strong></div>
          <div><span>Compte</span><strong>${escapeHtml(p.account||'—')}</strong></div>
          <div><span>Source</span><strong>${escapeHtml(positionSourceShort(p))}</strong></div>
          <div><span>Dernier cours</span><strong>${escapeHtml(fmtTimestamp(p.price_updated_at))}</strong></div>
          <div><span>Place</span><strong>${escapeHtml(p.exchange||'—')}</strong></div>
          <div><span>ISIN</span><strong>${escapeHtml(p.isin||'—')}</strong></div>
        </div>
        <div class="positionDetailActions"><button type="button" data-card-tx="${p.id}">+ Transaction</button><button type="button" class="secondary" data-card-refresh="${p.id}" ${p.quote_configured?'':'disabled'}>↻ Actualiser</button><button type="button" class="secondary" data-card-edit="${p.id}">Modifier</button></div>
        <section class="positionHistory"><div class="positionHistoryHead"><h3>Historique des mouvements</h3><span class="muted">Achats, ventes et cadre d’investissement</span></div><div class="positionHistoryBody" data-history-for="${p.id}"></div></section>
      </div>`;
    host.appendChild(card);
    const summary=card.querySelector('.positionCardSummary');
    summary.addEventListener('click',()=>{
      const id=+p.id;
      const wasOpen=expandedPositionIds.has(id);
      expandedPositionIds.clear();
      if(!wasOpen)expandedPositionIds.add(id);
      renderPositionCards();
    });
    card.querySelector('[data-card-tx]')?.addEventListener('click',()=>openTransactions(p.id));
    card.querySelector('[data-card-refresh]')?.addEventListener('click',()=>startQuoteRefresh({position_id:+p.id}));
    card.querySelector('[data-card-edit]')?.addEventListener('click',()=>openEdit(p));
    if(isOpen)loadInlineHistory(p.id,card.querySelector(`[data-history-for="${p.id}"]`));
  }
}
function initPositionCards(){
  const select=document.querySelector('#positionMetricSelect');if(!select||select.dataset.bound==='1')return;
  select.value=positionMetric;select.addEventListener('change',()=>{positionMetric=select.value;localStorage.setItem('portfolioPositionMetric',positionMetric);renderPositionCards();});select.dataset.bound='1';
}

function renderChart(){
  const canvas=document.querySelector('#allocationChart');if(typeof Chart==='undefined'||!canvas||!state)return;const data=state.positions.slice(0,16);if(allocationChart)allocationChart.destroy();
  allocationChart=new Chart(canvas,{type:'doughnut',data:{labels:data.map(x=>x.name),datasets:[{data:data.map(x=>x.position_value)}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'right',labels:{boxWidth:12,usePointStyle:true}},tooltip:{callbacks:{label:c=>`${c.label}: ${euro.format(c.raw)}`}}}}});
}

function renderOverviewVisuals(){
  if(!state||!analyticsState)return;
  const canvas=document.querySelector('#overviewPortfolioChart');
  const cats=Object.entries(analyticsState.risk?.categories||{}).filter(([,v])=>Number(v)>0);
  if(canvas&&typeof Chart!=='undefined'){
    if(overviewPortfolioChart)overviewPortfolioChart.destroy();
    overviewPortfolioChart=new Chart(canvas,{type:'doughnut',data:{labels:cats.map(x=>x[0]),datasets:[{data:cats.map(x=>x[1])}]},options:{responsive:true,maintainAspectRatio:false,cutout:'62%',plugins:{legend:{position:'bottom',labels:{boxWidth:10,usePointStyle:true}},tooltip:{callbacks:{label:c=>`${c.label}: ${Number(c.raw).toFixed(1)} %`}}}}});
  }
  const box=document.querySelector('#accountOverview');
  if(box){
    const total=Number(state.total_value)||0;
    const accounts=['PEA','CTO'].map(account=>{
      const rows=(state.positions||[]).filter(p=>String(p.account||'').toUpperCase()===account);
      const value=rows.reduce((s,p)=>s+(Number(p.position_value)||0),0);
      const pct=total?value/total*100:0;
      return {account,value,pct,count:rows.length};
    });
    box.innerHTML=accounts.map(a=>`<div class="accountCard"><div><span>${a.account}</span><strong>${euro.format(a.value)}</strong><small>${a.count} ligne${a.count>1?'s':''} · ${a.pct.toFixed(1)} %</small></div><div class="accountBar"><i style="width:${Math.max(0,Math.min(100,a.pct))}%"></i></div></div>`).join('');
  }
}


function projectionSettings(){
  const savedMonthly=Number(localStorage.getItem('portfolioProjectionMonthly'));
  const savedReturn=Number(localStorage.getItem('portfolioProjectionReturn'));
  return {
    monthly:Number.isFinite(savedMonthly)&&savedMonthly>=0?savedMonthly:Math.max(0,Number(state?.monthly_plan)||0),
    annualReturn:Number.isFinite(savedReturn)?savedReturn:6
  };
}
function projectionFutureValueMonths(current,monthly,annualRate,months){
  const monthlyRate=annualRate/100/12;
  if(Math.abs(monthlyRate)<1e-12)return current+monthly*months;
  const growth=Math.pow(1+monthlyRate,months);
  return current*growth+monthly*((growth-1)/monthlyRate);
}
function projectionFutureValue(current,monthly,annualRate,years){
  return projectionFutureValueMonths(current,monthly,annualRate,Math.round(years*12));
}
function projectionSeries(current,monthly,annualRate,years){
  const months=Math.round(years*12);
  const labels=[];const bare=[];const projected=[];
  for(let m=0;m<=months;m++){
    labels.push(m===0?'Départ':m%12===0?`${m/12} an${m>12?'s':''}`:`M${m}`);
    bare.push(current+monthly*m);
    projected.push(projectionFutureValueMonths(current,monthly,annualRate,m));
  }
  return {labels,bare,projected};
}
function destroyProjectionCharts(){
  for(const chart of projectionCharts){try{chart.destroy()}catch{}}
  projectionCharts=[];
}
function renderProjectionChart(canvas,current,monthly,annualReturn,years){
  if(typeof Chart==='undefined'||!canvas)return;
  const series=projectionSeries(current,monthly,annualReturn,years);
  const chart=new Chart(canvas,{
    type:'line',
    data:{labels:series.labels,datasets:[
      {label:'Capital sans rendement',data:series.bare,borderColor:'#737986',backgroundColor:'rgba(115,121,134,.10)',borderWidth:2,pointRadius:0,tension:.18},
      {label:'Valeur projetée',data:series.projected,borderColor:'#00b956',backgroundColor:'rgba(0,185,86,.10)',borderWidth:2,pointRadius:0,tension:.18}
    ]},
    options:{
      responsive:true,maintainAspectRatio:false,animation:false,interaction:{mode:'index',intersect:false},
      scales:{
        x:{grid:{display:false},ticks:{maxTicksLimit:4,font:{size:9},color:'#7a808c'}},
        y:{grid:{color:'rgba(0,0,0,.055)'},ticks:{maxTicksLimit:4,font:{size:9},color:'#7a808c',callback:v=>new Intl.NumberFormat('fr-FR',{notation:'compact',maximumFractionDigits:1}).format(v)+' €'}}
      },
      plugins:{
        legend:{display:true,position:'bottom',labels:{boxWidth:8,usePointStyle:true,font:{size:9}}},
        tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${euro.format(c.raw)}`}}
      }
    }
  });
  projectionCharts.push(chart);
}
function renderProjection(){
  const monthlyInput=document.querySelector('#projectionMonthly');
  const returnInput=document.querySelector('#projectionReturn');
  const cards=document.querySelector('#projectionCards');
  const summary=document.querySelector('#projectionSummary');
  if(!monthlyInput||!returnInput||!cards||!summary||!state)return;
  const defaults=projectionSettings();
  if(document.activeElement!==monthlyInput && monthlyInput.dataset.ready!=='1') monthlyInput.value=defaults.monthly;
  if(document.activeElement!==returnInput && returnInput.dataset.ready!=='1') returnInput.value=defaults.annualReturn;
  monthlyInput.dataset.ready='1';returnInput.dataset.ready='1';
  const monthly=Math.max(0,Number(monthlyInput.value)||0);
  const annualReturn=Math.max(-50,Math.min(50,Number(returnInput.value)||0));
  localStorage.setItem('portfolioProjectionMonthly',String(monthly));
  localStorage.setItem('portfolioProjectionReturn',String(annualReturn));
  const current=Math.max(0,Number(state.total_value)||0);
  const horizons=[1,2,5,10];
  destroyProjectionCharts();
  cards.innerHTML='';
  for(const years of horizons){
    const months=years*12;
    const contributions=monthly*months;
    const bareCapital=current+contributions;
    const projected=projectionFutureValue(current,monthly,annualReturn,years);
    const growth=projected-bareCapital;
    const card=document.createElement('article');
    card.className='projectionCard';
    const canvasId=`projectionChart${years}`;
    card.innerHTML=`<div class="projectionYears">Dans ${years} an${years>1?'s':''}</div>
      <strong>${euro.format(projected)}</strong>
      <div class="projectionBreakdown"><span>Capital sans rendement <b>${euro.format(bareCapital)}</b></span><span>Croissance estimée <b class="${perfClass(growth)}">${euro.format(growth)}</b></span></div>
      <div class="projectionMiniChart"><canvas id="${canvasId}" aria-label="Projection à ${years} an${years>1?'s':''}"></canvas></div>`;
    cards.appendChild(card);
    renderProjectionChart(card.querySelector('canvas'),current,monthly,annualReturn,years);
  }
  const ten=projectionFutureValue(current,monthly,annualReturn,10);
  const deposits=monthly*120;
  const growth=ten-current-deposits;
  summary.innerHTML=`Avec <strong>${euro.format(monthly)}/mois</strong> et une hypothèse de <strong>${annualReturn.toFixed(1)} %/an</strong>, ton portefeuille actuel de <strong>${euro.format(current)}</strong> atteindrait environ <strong>${euro.format(ten)}</strong> dans 10 ans, dont <strong>${euro.format(growth)}</strong> de croissance théorique au-delà de ton capital actuel et de tes nouveaux versements.`;
}
function initProjectionControls(){
  const monthly=document.querySelector('#projectionMonthly');
  const annual=document.querySelector('#projectionReturn');
  if(!monthly||!annual||monthly.dataset.bound==='1')return;
  const redraw=()=>renderProjection();
  monthly.addEventListener('input',redraw);annual.addEventListener('input',redraw);
  monthly.addEventListener('change',redraw);annual.addEventListener('change',redraw);
  monthly.dataset.bound='1';annual.dataset.bound='1';
}

function openEdit(p){
  document.querySelector('#editId').value=p.id;document.querySelector('#editAccount').value=p.account;document.querySelector('#editQty').value=p.quantity;
  document.querySelector('#editPru').value=p.avg_cost_eur??'';document.querySelector('#editTarget').value=p.target_pct||0;
  const qtyEl=document.querySelector('#editQty'),pruEl=document.querySelector('#editPru'),ledgerHint=document.querySelector('#editLedgerHint');
  qtyEl.disabled=!!p.has_transactions;pruEl.disabled=!!p.has_transactions;
  ledgerHint.textContent=p.has_transactions?'Quantité et PRU sont désormais calculés par le journal de transactions. Utilise « Ajouter une transaction » pour les faire évoluer.':'Quantité et PRU peuvent encore être corrigés manuellement avant la première transaction enregistrée.';
  document.querySelector('#editWeight').textContent=`Poids actuel : ${p.weight_pct.toFixed(2)} % · Cible : ${fmtTarget(p.target_pct)}${p.has_transactions?` · Réalisé : ${euro.format(p.realized_pnl_eur||0)} · Dividendes : ${euro.format(p.dividends_eur||0)}`:''}`;
  document.querySelector('#currentMarket').textContent=p.quote_configured?marketLabel(p):'Non associé';
  const status=document.querySelector('#tickerStatus');status.textContent=p.quote_note||'';status.className='status';
  document.querySelector('#manualPrice').value=p.manual_active?(p.manual_price??p.last_price_eur??''):'';
  document.querySelector('#manualPriceNote').value=p.manual_price_note||'';
  const manualStatus=document.querySelector('#manualPriceStatus');manualStatus.textContent=p.manual_active?`Cours manuel actif${p.manual_price_at?` depuis ${fmtTimestamp(p.manual_price_at)}`:''}. Cours automatique mémorisé : ${euro.format(p.auto_last_price_eur||0)}.`:'Mode automatique actif.';
  document.querySelector('#clearManualPriceBtn').disabled=!p.manual_active;
  document.querySelector('#editDialog').showModal();
}

document.querySelector('#editForm').addEventListener('submit',async e=>{
  if(e.submitter?.value==='cancel')return;e.preventDefault();const id=+document.querySelector('#editId').value;const p=state.positions.find(x=>x.id===id);const pru=document.querySelector('#editPru').value;
  const payload={account:document.querySelector('#editAccount').value,target_pct:+document.querySelector('#editTarget').value};
  if(!p?.has_transactions){payload.quantity=+document.querySelector('#editQty').value;payload.avg_cost_eur=pru===''?null:+pru}
  try{await api(`/api/positions/${id}`,{method:'PATCH',body:JSON.stringify(payload)});document.querySelector('#editDialog').close();await load()}catch(err){setTickerStatus(err.message,false)}
});
document.querySelector('#deletePositionBtn').addEventListener('click',async()=>{
  const id=+document.querySelector('#editId').value;const p=state.positions.find(x=>x.id===id);if(!p)return;
  if(!confirm(`Supprimer définitivement la ligne « ${p.name} » ?\n\nCette action supprime uniquement la ligne dans Portfolio Tracker. Elle ne touche évidemment pas à Trade Republic.`))return;
  try{await api(`/api/positions/${id}`,{method:'DELETE'});document.querySelector('#editDialog').close();await load()}catch(err){setTickerStatus(err.message,false)}
});
function setTickerStatus(msg,ok){const el=document.querySelector('#tickerStatus');el.textContent=msg;el.className=`status ${ok?'okBox':'errorBox'}`}

document.querySelector('#searchTickerBtn').addEventListener('click',()=>{const id=+document.querySelector('#editId').value;const p=state.positions.find(x=>x.id===id);openSearch({mode:'edit',positionId:id,query:p?.isin||p?.name||''})});
document.querySelector('#addTransactionFromPositionBtn').addEventListener('click',()=>{const id=+document.querySelector('#editId').value;document.querySelector('#editDialog').close();openTransactions(id)});
document.querySelector('#setManualPriceBtn').addEventListener('click',async()=>{const id=+document.querySelector('#editId').value;const price=Number(document.querySelector('#manualPrice').value);const note=document.querySelector('#manualPriceNote').value.trim();const st=document.querySelector('#manualPriceStatus');if(!price||price<=0){st.textContent='Renseigne un cours EUR positif.';return}try{await api(`/api/positions/${id}/manual-price`,{method:'POST',body:JSON.stringify({price_eur:price,note})});await load();const p=state.positions.find(x=>x.id===id);st.textContent=`Cours manuel actif : ${euro.format(p.last_price_eur)}.`;document.querySelector('#clearManualPriceBtn').disabled=false;document.querySelector('#currentMarket').textContent=marketLabel(p)}catch(err){st.textContent=err.message}});
document.querySelector('#clearManualPriceBtn').addEventListener('click',async()=>{const id=+document.querySelector('#editId').value;const st=document.querySelector('#manualPriceStatus');try{await api(`/api/positions/${id}/manual-price`,{method:'DELETE'});await load();const p=state.positions.find(x=>x.id===id);st.textContent='Cours automatique réactivé.';document.querySelector('#manualPrice').value='';document.querySelector('#manualPriceNote').value='';document.querySelector('#clearManualPriceBtn').disabled=true;document.querySelector('#currentMarket').textContent=p.quote_configured?marketLabel(p):'Non associé'}catch(err){st.textContent=err.message}});

function openSearch(ctx){searchContext=ctx;document.querySelector('#marketQuery').value=ctx.query||'';document.querySelector('#searchResults').innerHTML='';document.querySelector('#searchStatus').textContent='';document.querySelector('#searchDialog').showModal();if(ctx.query)searchMarket()}
document.querySelector('#marketSearchBtn').addEventListener('click',searchMarket);document.querySelector('#marketQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchMarket()}});
async function searchMarket(){
  const q=document.querySelector('#marketQuery').value.trim();if(!q)return;const status=document.querySelector('#searchStatus'),box=document.querySelector('#searchResults');status.textContent='Recherche EODHD…';box.innerHTML='';
  try{const r=await api(`/api/market/search?q=${encodeURIComponent(q)}`);status.textContent=r.results.length?`${r.results.length} résultat(s)`:'Aucun résultat';for(const item of r.results){const el=document.createElement('button');el.type='button';el.className='searchItem';const primary=item.is_primary?' · principal':'';el.innerHTML=`<span><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.symbol)} · ${escapeHtml(item.currency)} · ${escapeHtml(item.exchange)}${primary}<br>${escapeHtml(item.isin||'ISIN non fourni')}</small></span><span>Choisir</span>`;el.addEventListener('click',()=>selectSearchResult(item));box.appendChild(el)}}catch(err){status.textContent=err.message;status.className='status errorBox'}
}
async function selectSearchResult(item){
  if(searchContext?.mode==='edit'){
    const id=searchContext.positionId;document.querySelector('#searchStatus').textContent='Association…';
    try{const linked=await api(`/api/positions/${id}/market-link`,{method:'POST',body:JSON.stringify({market_symbol:item.symbol,provider:'eodhd',exchange:item.exchange||'',currency:item.currency||'EUR',isin:item.isin||''})});document.querySelector('#searchDialog').close();await load();const p=state.positions.find(x=>x.id===id);document.querySelector('#currentMarket').textContent=marketLabel(p);setTickerStatus('Instrument associé. Le cours sera récupéré lors de la prochaine actualisation manuelle.',true)}catch(err){document.querySelector('#searchStatus').textContent=err.message;document.querySelector('#searchStatus').className='status errorBox'}
  }else{
    selectedAddInstrument=item;document.querySelector('#addMarketSelection').textContent=`${item.name} · ${item.symbol} · ${item.currency} · ${item.isin||'sans ISIN'}`;document.querySelector('#addTickerStatus').textContent='Instrument sélectionné.';document.querySelector('#searchDialog').close();
  }
}

// Ajout
document.querySelector('#exportExcelBtn').addEventListener('click',()=>{window.location.href=`/api/export/positions.xlsx?t=${Date.now()}`});
document.querySelector('#exportHistoryExcelBtn')?.addEventListener('click',()=>{window.location.href=`/api/export/history.xlsx?t=${Date.now()}`});
document.querySelector('#addBtn').addEventListener('click',()=>{document.querySelector('#addForm').reset();document.querySelector('#addType').value='ETF';document.querySelector('#addTarget').value='0';selectedAddInstrument=null;document.querySelector('#addMarketSelection').textContent='Aucun instrument sélectionné';document.querySelector('#addTickerStatus').textContent='';document.querySelector('#addDialog').showModal()});
document.querySelector('#searchAddInstrumentBtn').addEventListener('click',()=>openSearch({mode:'add',query:document.querySelector('#addName').value.trim()}));
document.querySelector('#addForm').addEventListener('submit',async e=>{if(e.submitter?.value==='cancel')return;e.preventDefault();if(!selectedAddInstrument){const el=document.querySelector('#addTickerStatus');el.textContent='Sélectionne d’abord un instrument de marché.';el.className='status errorBox';return}const pru=document.querySelector('#addPru').value;try{await api('/api/positions',{method:'POST',body:JSON.stringify({name:document.querySelector('#addName').value.trim(),asset_type:document.querySelector('#addType').value.trim(),account:document.querySelector('#addAccount').value,quantity:+document.querySelector('#addQty').value,avg_cost_eur:pru===''?null:+pru,market_symbol:selectedAddInstrument.symbol,provider:'eodhd',exchange:selectedAddInstrument.exchange||'',currency:selectedAddInstrument.currency||'EUR',isin:selectedAddInstrument.isin||'',target_pct:+document.querySelector('#addTarget').value||0})});document.querySelector('#addDialog').close();await load()}catch(err){const el=document.querySelector('#addTickerStatus');el.textContent=err.message;el.className='status errorBox'}});

// Transactions
function localIsoDate(){const d=new Date();const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
const txLabels={opening:'Solde initial',buy:'Achat',sell:'Vente',dividend:'Dividende',fee:'Frais'};
function fillTxPositions(selectedId){const sel=document.querySelector('#txPosition');sel.innerHTML='';for(const p of state.positions){const o=document.createElement('option');o.value=p.id;o.textContent=`${p.name} · ${p.account}`;if(+p.id===+selectedId)o.selected=true;sel.appendChild(o)}}
function updateTxFields(){const typ=document.querySelector('#txType').value;const trade=typ==='buy'||typ==='sell';const originLabel=document.querySelector('#txOriginLabel');if(originLabel)originLabel.style.display='grid';updateFrameworkFields();document.querySelectorAll('.tradeField').forEach(el=>el.style.display=trade?'grid':'none');document.querySelector('#txFeesLabel').style.display=trade?'grid':'none';document.querySelector('#txTradeHint').textContent=trade?'Pour un achat ou une vente, renseigne au moins 2 valeurs parmi quantité, prix unitaire et montant. L’application calcule la troisième.':typ==='dividend'?'Saisis le montant net du dividende reçu en EUR.':'Saisis le montant du frais en EUR.'}
async function openTransactions(positionId=null){resetTransactionEditing();transactionFilterPositionId=positionId;fillTxPositions(positionId||state.positions[0]?.id);document.querySelector('#txType').value='buy';document.querySelector('#txDate').value=localIsoDate();document.querySelector('#txOrigin').value='';document.querySelector('#txCustom').value='';syncTxAccount();document.querySelector('#txQty').value='';document.querySelector('#txUnitPrice').value='';document.querySelector('#txAmount').value='';document.querySelector('#txFees').value='0';document.querySelector('#txNote').value='';document.querySelector('#txStatus').textContent='';updateTxFields();activateTab('transactions');await loadTransactions(positionId)}
async function loadTransactions(positionId=null){const url=positionId?`/api/transactions?position_id=${positionId}&limit=100`:'/api/transactions?limit=200';const r=await api(url);const box=document.querySelector('#txHistory');box.innerHTML='';const all=r.transactions;const search=(document.querySelector("#txSearch")?.value||"").toLocaleLowerCase("fr").trim(),type=document.querySelector("#txFilterType")?.value||"",account=document.querySelector("#txFilterAccount")?.value||"",from=document.querySelector("#txFilterFrom")?.value||"",to=document.querySelector("#txFilterTo")?.value||"";const visible=all.filter(t=>(!search||(t.position_name||"").toLocaleLowerCase("fr").includes(search))&&(!type||t.transaction_type===type)&&(!account||t.account===account||state.positions.some(p=>+p.id===+t.position_id&&p.account===account))&&(!from||t.transaction_date>=from)&&(!to||t.transaction_date<=to));const buys=visible.filter(t=>t.transaction_type==="buy").reduce((a,t)=>a+Number(t.gross_amount_eur||0),0),sells=visible.filter(t=>t.transaction_type==="sell").reduce((a,t)=>a+Number(t.gross_amount_eur||0),0);document.querySelector("#txTotals").textContent=`Achats : ${euro.format(buys)} · Ventes : ${euro.format(sells)}`;document.querySelector('#txHistorySummary').textContent=positionId?`${visible.filter(x=>x.transaction_type!=='opening').length} opération(s) sur cette ligne`:`${visible.filter(x=>x.transaction_type!=='opening').length} opération(s)`;if(!visible.length){box.innerHTML='<p class="muted">Aucune transaction enregistrée.</p>';return}for(const t of visible){const row=document.createElement('div');row.className=`txRow expandableHistoryRow ${t.transaction_type==='opening'?'txOpening':''}`;let detail='';if(t.transaction_type==='buy'||t.transaction_type==='sell')detail=`${num.format(t.quantity||0)} × ${euro.format(t.unit_price_eur||0)} = ${euro.format(t.gross_amount_eur||0)}${t.fees_eur?` · frais ${euro.format(t.fees_eur)}`:''}${t.realized_pnl_eur!=null?` · réalisé ${euro.format(t.realized_pnl_eur)}`:''}`;else detail=`${euro.format(t.gross_amount_eur||0)}`;const origin=t.transaction_type!=='opening'&&t.origin?` · ${escapeHtml((t.investment_framework==='Autre'?t.framework_label:t.investment_framework)||t.origin)}`:'';row.innerHTML=`<div><strong>${escapeHtml(txLabels[t.transaction_type]||t.transaction_type)}</strong> · ${escapeHtml(t.position_name)}<br><span class="muted">${escapeHtml(t.transaction_date)} · ${detail}${origin}${t.note?` · ${escapeHtml(t.note)}`:''}</span></div>${t.transaction_type==='opening'?'':'<div><button type="button" class="secondary txEdit">Modifier</button> <button type="button" class="danger txDelete">Supprimer</button></div>'}`;row.tabIndex=0;row.setAttribute('role','button');row.setAttribute('aria-expanded','false');row.setAttribute('aria-label','Afficher les actions de cette opération');enableHistoryRowActions(row, '.expandableHistoryRow');const edit=row.querySelector('.txEdit');if(edit)edit.addEventListener('click',()=>editHistoryTransaction(t));const del=row.querySelector('.txDelete');if(del)del.addEventListener('click',async()=>{if(!confirm('Supprimer cette transaction et recalculer la position ?'))return;try{await api(`/api/transactions/${t.id}`,{method:'DELETE'});await load();fillTxPositions(positionId||t.position_id);await loadTransactions(positionId)}catch(err){const st=document.querySelector('#txStatus');st.textContent=err.message;st.className='status errorBox'}});box.appendChild(row)}}
document.querySelector('#openingForm')?.addEventListener('submit',async e=>{if(e.submitter?.value==='cancel')return;e.preventDefault();if(!openingContext)return;const st=document.querySelector('#openingStatus');st.textContent='Enregistrement…';try{await api(`/api/positions/${openingContext.positionId}/opening`,{method:'PATCH',body:JSON.stringify({quantity:+document.querySelector('#openingQty').value,avg_cost_eur:+document.querySelector('#openingPru').value})});st.textContent='Position initiale mise à jour.';st.className='status okBox';await load();await refreshOpeningContext();document.querySelector(`[data-history-for="${openingContext.positionId}"]`)?.removeAttribute('data-loaded');renderPositionCards();}catch(err){st.textContent=err.message;st.className='status errorBox';}});
document.querySelector('#replaceOpeningBtn')?.addEventListener('click',async()=>{if(!openingContext)return;if(!confirm('Remplacer définitivement la position initiale par l’historique réel saisi ?'))return;const st=document.querySelector('#openingStatus');try{await api(`/api/positions/${openingContext.positionId}/opening`,{method:'DELETE'});document.querySelector('#openingDialog').close();await load();renderPositionCards();}catch(err){st.textContent=err.message;st.className='status errorBox';}});
document.querySelector('#deleteOpeningBtn')?.addEventListener('click',async()=>{if(!openingContext)return;const rec=openingContext.ledgerData?.reconciliation||{};let msg=`Supprimer la position initiale ? La quantité sera recalculée uniquement depuis l’historique saisi.`;if(Math.abs(Number(rec.quantity_gap)||0)>1e-7)msg+=`\n\nAttention : il reste un écart de ${num.format(rec.quantity_gap)} titre(s).`;if(!confirm(msg))return;const st=document.querySelector('#openingStatus');try{await api(`/api/positions/${openingContext.positionId}/opening?force=true`,{method:'DELETE'});document.querySelector('#openingDialog').close();await load();renderPositionCards();}catch(err){st.textContent=err.message;st.className='status errorBox';}});
// Transactions is now an inline tab; editing state resets on demand.
document.querySelector('#transactionsBtn').addEventListener('click',()=>openTransactions(null));
document.querySelector('#txType').addEventListener('change',updateTxFields);
document.querySelector('#txPosition').addEventListener('change',()=>{if(transactionFilterPositionId!==null){transactionFilterPositionId=+document.querySelector('#txPosition').value;loadTransactions(transactionFilterPositionId)}});
document.querySelector('#transactionForm').addEventListener('submit',async e=>{if(e.submitter?.value==='cancel'){e.preventDefault();openTransactions();return;}e.preventDefault();const typ=document.querySelector('#txType').value;const val=id=>{const x=document.querySelector(id).value;return x===''?null:+x};const payload={position_id:+document.querySelector('#txPosition').value,transaction_type:typ,transaction_date:document.querySelector('#txDate').value,quantity:val('#txQty'),unit_price_eur:val('#txUnitPrice'),amount_eur:val('#txAmount'),fees_eur:val('#txFees')||0,note:document.querySelector('#txNote').value.trim(),investment_framework:document.querySelector('#txOrigin').value,framework_label:document.querySelector('#txCustom').value.trim()};const st=document.querySelector('#txStatus');st.textContent='Enregistrement…';st.className='status';try{await api(editingTransactionId?`/api/transactions/${editingTransactionId}`:'/api/transactions',{method:editingTransactionId?'PATCH':'POST',body:JSON.stringify(payload)});st.textContent='Opération enregistrée. Quantité et PRU recalculés.';resetTransactionEditing();st.className='status okBox';await load();fillTxPositions(payload.position_id);document.querySelector('#txQty').value='';document.querySelector('#txUnitPrice').value='';document.querySelector('#txAmount').value='';document.querySelector('#txFees').value='0';document.querySelector('#txNote').value='';await loadTransactions(transactionFilterPositionId)}catch(err){st.textContent=err.message;st.className='status errorBox'}});

// Réglages
document.querySelector('#settingsBtn').addEventListener('click',async()=>{const s=await api('/api/settings/market');document.querySelector('#eodhdToken').value='';document.querySelector('#eodhdToken').disabled=!!s.token_managed_by_server;document.querySelector('#eodhdToken').placeholder=s.token_managed_by_server?'Clé gérée comme secret serveur':(s.token_configured?`Clé actuelle ${s.token_hint}`:'Colle ta clé EODHD');const secretInfo=document.querySelector('#marketSecretInfo');if(secretInfo)secretInfo.textContent=s.token_managed_by_server?'La clé EODHD est stockée comme secret chiffré chez l’hébergeur, pas dans PostgreSQL.':'La clé EODHD est gérée par ce serveur.';const cloudImport=document.querySelector('#cloudImportBox');if(cloudImport)cloudImport.hidden=!s.cloud_mode;document.querySelector('#yahooFallback').checked=s.yahoo_fallback;document.querySelector('#settingsStatus').textContent=s.token_configured?'Clé EODHD configurée. Les cours sont actualisés uniquement à la demande.':'Aucune clé EODHD configurée.';const usage=document.querySelector('#settingsApiUsage');if(usage)usage.textContent=`Appels EODHD aujourd’hui : ${s.calls_today||0}${s.daily_rate_limit?` / ${s.daily_rate_limit}`:''}`;document.querySelector('#settingsStatus').className='status';document.querySelector('#settingsDialog').showModal()});
document.querySelector('#settingsForm').addEventListener('submit',async e=>{if(e.submitter?.value==='cancel')return;e.preventDefault();const token=document.querySelector('#eodhdToken').value.trim();const payload={yahoo_fallback:document.querySelector('#yahooFallback').checked};if(token)payload.eodhd_api_token=token;const status=document.querySelector('#settingsStatus');status.textContent='Vérification de la clé…';try{await api('/api/settings/market',{method:'POST',body:JSON.stringify(payload)});status.textContent='Réglages enregistrés. Les cours restent inchangés jusqu’à la prochaine actualisation manuelle.';status.className='status okBox';setTimeout(async()=>{document.querySelector('#settingsDialog').close();await load()},500)}catch(err){status.textContent=err.message;status.className='status errorBox'}});

let quoteRefreshBusy=false,quotePolling=false,lastQuoteJob=null;
function setQuoteBusy(busy){quoteRefreshBusy=busy;document.querySelector('#refreshBtn').disabled=busy;document.querySelector('#refreshBtn').textContent=busy?'Actualisation en cours…':'Actualiser les cours';document.querySelector('#retryQuotesBtn').disabled=busy;document.querySelectorAll('[data-refresh-id]').forEach(button=>button.disabled=busy);}
function renderQuoteJob(job){
 if(!job?.id)return;lastQuoteJob=job;const running=job.status==='running';setQuoteBusy(running);
 const counts={recent:0,old:0,error:0,not_attempted:0,skipped:0,pending:0,running:0};for(const row of job.results||[])counts[row.status]=(counts[row.status]||0)+1;
 const progress=document.querySelector('#quoteRefreshProgress'),bar=document.querySelector('#quoteRefreshBar');bar.hidden=false;bar.max=Math.max(1,job.total);bar.value=job.processed+counts.skipped;
 const apiText=`${job.api_responses||0} réponse(s) API / ${job.api_requests||0} requête(s)${job.api_network_errors?` · ${job.api_network_errors} échec(s) réseau`:''}`;
 if(running){progress.textContent=`${job.processed}/${job.total} lignes traitées · ${apiText}${job.current_name?' · '+job.current_name:''}`;}
 else if(job.status==='interrupted'){progress.textContent=`Suivi interrompu : ${job.processed}/${job.total} lignes traitées · ${apiText}. Les lignes non abouties peuvent être reprises seules.`;}
 else if(counts.recent===job.total&&job.total>0){progress.textContent=`Terminé : tous les cours sélectionnés ont reçu une réponse récente (${counts.recent}/${job.total}) · ${apiText}.`;}
 else{progress.textContent=`Terminé : ${counts.recent} récent(s), ${counts.old} ancien(s), ${counts.error} échec(s), ${counts.not_attempted} non interrogé(s), ${counts.skipped} interrogation(s) récente(s) évitée(s) · ${apiText}.${job.quota_exhausted?' Quota atteint : les requêtes restantes n’ont pas été envoyées.':''}${counts.skipped?' Attends 60 secondes après la dernière tentative pour réinterroger ces titres.':''}`;}
 progress.className=counts.old||counts.error||counts.not_attempted||job.status==='interrupted'?'quoteJobWarning':'';
 const retry=document.querySelector('#retryQuotesBtn');retry.hidden=running||!(counts.old||counts.error||counts.not_attempted||job.status==='interrupted'||(counts.skipped&&(job.results||[]).some(r=>state?.positions.some(p=>p.id===r.id&&(p.quote_stale||p.quote_refresh_error)))));
 document.querySelector('#resumeQuotesBtn').hidden=true;
 document.querySelector('#quoteRefreshDetails').hidden=false;
 const labels={pending:'En attente',running:'Interrogation en cours',recent:'Réponse récente',old:'Réponse reçue, cours ancien',error:'Échec, cours conservé',not_attempted:'Non interrogé',skipped:'Nouvelle requête évitée (moins de 60 s)'};
 document.querySelector('#quoteRefreshResults').innerHTML=(job.results||[]).map(row=>`<div class="quoteJobRow"><strong>${escapeHtml(row.name)}</strong><span>${escapeHtml(labels[row.status]||row.status)}${row.timestamp?' · cours au '+escapeHtml(fmtTimestamp(row.timestamp)):''}${row.checked_at?' · reçu le '+escapeHtml(fmtTimestamp(row.checked_at)):''}${row.error?' · '+escapeHtml(row.error):''}</span></div>`).join('');
 const status=document.querySelector('#status');if(status){status.textContent=progress.textContent;status.className=progress.className?'status errorBox':'status';}
}
async function readQuoteJob(){const response=await fetchWithTimeout('/api/quotes/jobs/current',{},4000);const job=await response.json();if(!response.ok)throw new Error(job.detail||'Suivi indisponible');return job;}
async function pollQuoteJob(){
 if(quotePolling)return;quotePolling=true;let failures=0;
 try{while(true){try{const job=await readQuoteJob();failures=0;renderQuoteJob(job);if(job.status!=='running'){await load();renderQuoteJob(job);return;}}catch(error){failures++;if(failures>=3){document.querySelector('#quoteRefreshProgress').textContent='Suivi indisponible. L’opération peut continuer sur le serveur : reprends le suivi sans relancer les requêtes.';document.querySelector('#resumeQuotesBtn').hidden=false;return;}}await new Promise(resolve=>setTimeout(resolve,1000));}}finally{quotePolling=false;}
}
async function startQuoteRefresh(payload={}){
 if(quoteRefreshBusy)return;setQuoteBusy(true);document.querySelector('#quoteRefreshProgress').textContent='Préparation de l’actualisation…';
 try{const response=await fetchWithTimeout('/api/quotes/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)},10000);const job=await response.json();if(!response.ok)throw new Error(job.detail||'Actualisation impossible');renderQuoteJob(job);if(job.status==='running')await pollQuoteJob();else{await load();renderQuoteJob(job);}}
 catch(error){document.querySelector('#quoteRefreshProgress').textContent='Confirmation indisponible : reprends le suivi avant de lancer une nouvelle actualisation.';document.querySelector('#resumeQuotesBtn').hidden=false;}
}
async function resumeQuoteRefresh(){try{const job=await readQuoteJob();if(job.id){renderQuoteJob(job);if(job.status==='running')await pollQuoteJob();}else{setQuoteBusy(false);document.querySelector('#resumeQuotesBtn').hidden=true;document.querySelector('#quoteRefreshProgress').textContent='Aucune actualisation en cours.';}}catch(error){document.querySelector('#quoteRefreshProgress').textContent='Le serveur ne répond pas au suivi. Aucune nouvelle requête de cours n’a été lancée.';document.querySelector('#resumeQuotesBtn').hidden=false;}}
document.querySelector('#refreshBtn').addEventListener('click',()=>startQuoteRefresh());
document.querySelector('#retryQuotesBtn').addEventListener('click',()=>startQuoteRefresh({retry_only:true}));
document.querySelector('#resumeQuotesBtn').addEventListener('click',resumeQuoteRefresh);
async function boot(){initTabs();installNavigationFallback();initMobileNav();initProjectionControls();initTableSorting();initPositionCards();bindAnalyticsControls();await load();const s=document.querySelector('#status');if(!state.eodhd_configured){s.textContent='Commence par “Réglages marché” pour ajouter ta clé EODHD.';s.className='status'}else{s.textContent='Cours figés jusqu’à ta prochaine demande. Clique sur “Actualiser les cours” pour mettre à jour la valorisation.';s.className='status'}}


const tabMeta={overview:['Synthèse','Vue visuelle de ton portefeuille et de son état.'],positions:['Positions','Lecture rapide des titres, performances et mouvements.'],table:['Export','Vue analytique complète, tri et export Excel.'],transactions:['Transactions','Journal des achats, ventes, dividendes et frais.'],allocation:['Allocation','Cibles, concentration et rééquilibrage sans vente.'],effort:['Effort d’investissement','Mesure ce que tu investis réellement au-delà de ton plan.'],performance:['Performance','Historique, performance personnelle et rapprochement Trade Republic.'],goals:['Objectifs','Projection du capital, scénarios et prochains paliers.']};

// Swipe between sections without stealing gestures from charts, sliders, tables or controls.
function installTabSwipe(){
 const order=['overview','positions','transactions','allocation','effort','performance','goals','table','settings'];
 let start=null;const main=document.querySelector('main.wrap');
 main.addEventListener('touchstart',e=>{if(innerWidth>760||e.touches.length!==1||e.target.closest('input,select,textarea,button,canvas,.tableWrap,.positionInlineData,.txHistory,[data-no-swipe],dialog')){start=null;return;}const t=e.touches[0];start={x:t.clientX,y:t.clientY};},{passive:true});
 main.addEventListener('touchend',e=>{if(!start||innerWidth>760)return;const t=e.changedTouches[0],dx=t.clientX-start.x,dy=t.clientY-start.y;start=null;if(Math.abs(dx)<75||Math.abs(dx)<Math.abs(dy)*1.6)return;const index=order.indexOf(activeTab),next=order[index+(dx<0?1:-1)];if(next==='settings'){document.querySelector('#settingsBtn')?.click();return;}if(next)activateTab(next);},{passive:true});
 main.addEventListener('touchcancel',()=>start=null,{passive:true});
}
function initTabs(){
  document.querySelectorAll('.navTab[data-tab],.mobileBottomTab[data-tab]').forEach(btn=>btn.addEventListener('click',()=>{if(btn.dataset.tab==='transactions')transactionFilterPositionId=null;activateTab(btn.dataset.tab);}));
  document.querySelector('#mobileSettingsBtn')?.addEventListener('click',()=>document.querySelector('#settingsBtn')?.click());
  for(const id of ['txSearch','txFilterType','txFilterAccount','txFilterFrom','txFilterTo'])document.getElementById(id)?.addEventListener('input',()=>loadTransactions(transactionFilterPositionId));
  installTabSwipe();
}

function installNavigationFallback(){
  document.addEventListener('click',event=>{
    const tab=event.target.closest('.mobileBottomTab[data-tab],.navTab[data-tab],.mobileMoreSheet [data-tab]');
    if(!tab)return;
    event.preventDefault();
    event.stopPropagation();
    if(tab.dataset.tab==='transactions')transactionFilterPositionId=null;activateTab(tab.dataset.tab);
  },true);
}
function initMobileNav(){const nav=document.querySelector('.mobileBottomNav');if(nav)nav.dataset.bound='1';}

function openMobileNav(){}
function closeMobileNav(){}
function openMobileMore(){const sheet=document.querySelector('#mobileMoreSheet'),backdrop=document.querySelector('#mobileMoreBackdrop');if(!sheet||!backdrop)return;sheet.hidden=false;backdrop.hidden=false;requestAnimationFrame(()=>{sheet.classList.add('open');backdrop.classList.add('open');});}
function closeMobileMore(){const sheet=document.querySelector('#mobileMoreSheet'),backdrop=document.querySelector('#mobileMoreBackdrop');if(!sheet||!backdrop)return;sheet.classList.remove('open');backdrop.classList.remove('open');setTimeout(()=>{if(!sheet.classList.contains('open')){sheet.hidden=true;backdrop.hidden=true;}},180);}
function activateTab(tab){activeTab=tab;document.querySelectorAll('.navTab[data-tab],.mobileBottomTab[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.tabView').forEach(v=>v.classList.toggle('active',v.dataset.view===tab));const meta=tabMeta[tab]||tabMeta.overview;document.querySelector('#tabTitle').textContent=meta[0];document.querySelector('#tabSubtitle').textContent=meta[1];renderActiveTab();localStorage.setItem('portfolioActiveTab',tab);window.scrollTo({top:0,behavior:'smooth'});}
function renderActiveTab(){if(!state)return;if(activeTab==='overview')renderOverviewVisuals();if(activeTab==='allocation')renderChart();if(activeTab==='positions'){renderPositionViewSummary();renderPositionCards();}if(activeTab==='table'){requestAnimationFrame(syncPositionScroll);}if(activeTab==='transactions'){loadTransactions(transactionFilterPositionId).catch(console.error);}if(activeTab==='effort')renderEffortChart();if(activeTab==='performance')renderHistoryChart();if(activeTab==='goals'){renderProjection();renderMilestones();renderScenario();}}

function renderAnalytics(){
  if(!analyticsState)return;const e=analyticsState.effort||{},p=analyticsState.performance||{},r=analyticsState.risk||{},rec=analyticsState.reconciliation||{},u=analyticsState.api_usage||{};
  document.querySelector('#effortActual').textContent=euro.format(e.actual||0);document.querySelector('#effortGoal').textContent=euro.format(e.annual_goal||0);
  const extra=document.querySelector('#effortExtra');extra.textContent=euro.format(e.extra_gross||0);extra.className=perfClass(e.extra_gross||0);
  const vp=document.querySelector('#effortVsPlan');vp.textContent=euro.format(e.net_vs_plan_ytd||0);vp.className=perfClass(e.net_vs_plan_ytd||0);
  document.querySelector('#effortMessage').textContent=e.encouragement||'';document.querySelector('#effortMonthlyTarget').value=e.monthly_target??state.monthly_plan;document.querySelector('#effortAnnualGoal').value=e.annual_goal??0;document.querySelector('#effortPeriod').textContent=`${e.labels[0]} – ${e.labels[11]}`;document.querySelector('#effortTotal').textContent=`Effort total de la période : ${euro.format(e.total_actual||0)}${e.other_extra?' · dont '+euro.format(e.other_extra)+' supplémentaires hors CTO':''}`;const coverage=document.querySelector('#effortCoverageNote');if(coverage)coverage.textContent=`Plan PEA : ${euro.format(e.journal_actual||0)} dans le journal + ${euro.format(e.confirmed_extra||0)} de complément confirmé. Comparaison jusqu’au mois en cours inclus. Les achats futurs ne sont pas comptés. ${e.legacy_catchup?'Ancien rattrapage conservé : '+euro.format(e.legacy_catchup)+' ; exclu du calcul car son compte et sa période ne sont pas établis. Enregistre les achats correspondants avec leurs dates et cadres pour les inclure.':''}`;
  renderOriginBreakdown(e.origins||{});
  renderEffortConfirmations(e);
  document.querySelector('#xirrValue').textContent=p.xirr_pct==null?'—':fmtPct(p.xirr_pct);document.querySelector('#xirrValue').className=perfClass(p.xirr_pct||0);
  document.querySelector('#dividendsValue').textContent=euro.format(p.dividends_year||0);document.querySelector('#realizedValue').textContent=euro.format(p.realized_year||0);document.querySelector('#xirrNote').textContent=p.xirr_note||'';
  document.querySelector('#trReferenceValue').value=rec.tr_reference_value||'';renderReconciliation(rec);
  renderRisk(r);renderAnomalies(r);
  const apiEl=document.querySelector('#apiUsage');if(apiEl)apiEl.textContent=`EODHD : ${u.calls_today||0}${u.daily_limit?` / ${u.daily_limit}`:''} appels aujourd’hui`;
  renderMilestones();renderScenario();
}
function renderAnomalies(r){const box=document.querySelector('#anomalyList');if(!box)return;const alerts=[...(r.alerts||[])];const stale=(state.positions||[]).filter(p=>p.price_updated_at&&Date.now()/1000-Number(p.price_updated_at)>3*86400);if(stale.length)alerts.push(`${stale.length} cours datent de plus de 3 jours.`);if(!alerts.length)alerts.push('Aucune anomalie importante détectée.');box.innerHTML=alerts.map((x,i)=>`<div class="insight ${i===0&&alerts.length===1?'okInsight':''}">${escapeHtml(x)}</div>`).join('');}
function renderOriginBreakdown(origins){const box=document.querySelector('#effortOrigin');if(!box)return;const entries=Object.entries(origins).sort((a,b)=>b[1]-a[1]);if(!entries.length){box.innerHTML='<p class="muted">Ajoute des achats dans le journal pour ventiler ton effort.</p>';return}const total=entries.reduce((s,x)=>s+Number(x[1]||0),0);box.innerHTML=entries.map(([k,v])=>`<div class="breakdownRow"><span>${escapeHtml(k)}</span><strong>${euro.format(v)}</strong><small>${total?((v/total)*100).toFixed(1):0} %</small></div>`).join('');}
function renderRisk(r){const box=document.querySelector('#riskCategories');if(box){const entries=Object.entries(r.categories||{}).sort((a,b)=>b[1]-a[1]);box.innerHTML=entries.map(([k,v])=>`<div class="breakdownRow"><span>${escapeHtml(k)}</span><strong>${Number(v).toFixed(1)} %</strong><small>Cible ${Number(r.category_targets?.[k]||0).toFixed(1)} %</small></div>`).join('')||'<p class="muted">Pas encore de données.</p>';}const warn=document.querySelector('#overlapWarnings');if(warn){const items=[...(r.overlap||[]),...(r.alerts||[])];warn.innerHTML=(items.length?items:['Pas de signal particulier.']).map(x=>`<div class="insight">${escapeHtml(x)}</div>`).join('');}}
function renderReconciliation(rec){const v=document.querySelector('#reconcileValue'),d=document.querySelector('#reconcileDetail');if(!v||!d)return;if(!rec.tr_reference_value){v.textContent='—';d.textContent='Ajoute une valeur Trade Republic pour mesurer l’écart.';return}v.textContent=euro.format(rec.gap||0);v.className=perfClass(-(rec.gap||0));d.textContent=`Trade Republic ${euro.format(rec.tr_reference_value)} · Tracker ${euro.format(rec.tracker_value)} · écart ${euro.format(rec.gap)} (${rec.gap_pct>=0?'+':''}${Number(rec.gap_pct||0).toFixed(2)} %)`;}
function renderEffortChart(){const canvas=document.querySelector('#effortChart');if(!canvas||typeof Chart==='undefined'||!analyticsState)return;if(effortChart)effortChart.destroy();const e=analyticsState.effort;const labels=e.labels;effortChart=new Chart(canvas,{type:'bar',data:{labels,datasets:[{label:'Plan PEA réalisé',data:e.monthly,backgroundColor:'#087cff'},{label:'Plan PEA prévu',data:Array(12).fill(e.monthly_target),backgroundColor:'rgba(0,185,86,.20)'},{label:'Supplément CTO',data:e.extra_monthly,backgroundColor:'#72b0ff'},{label:'Supplément hors CTO',data:e.other_monthly,backgroundColor:'#dcaa55'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}},scales:{y:{beginAtZero:true,ticks:{callback:v=>`${v} €`}}}}});}
function renderHistoryChart(){const canvas=document.querySelector('#historyChart');if(!canvas||typeof Chart==='undefined'||!analyticsState)return;if(historyChart)historyChart.destroy();const h=analyticsState.performance.history||[];if(!h.length)return;historyChart=new Chart(canvas,{type:'line',data:{labels:h.map(x=>fmtTimestamp(x.created_at)),datasets:[{label:'Valeur du portefeuille',data:h.map(x=>x.total_value),borderColor:'#087cff',backgroundColor:'rgba(8,124,255,.08)',fill:true,tension:.15,pointRadius:h.length>60?0:2},{label:'Capital investi',data:h.map(x=>x.invested_estimate),borderColor:'#00b956',borderDash:[5,4],tension:.15,pointRadius:0}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>`${c.dataset.label}: ${euro.format(c.raw)}`}}},scales:{x:{ticks:{maxTicksLimit:8}},y:{ticks:{callback:v=>new Intl.NumberFormat('fr-FR',{notation:'compact'}).format(v)+' €'}}}}});}
async function calculateRebalance(){const amount=Math.max(0,Number(document.querySelector('#rebalanceAmount').value)||0);const a=await api(`/api/analytics?rebalance_amount=${encodeURIComponent(amount)}`);analyticsState=a;const box=document.querySelector('#rebalanceResults');const list=a.rebalance?.suggestions||[];if(!list.length){box.innerHTML='<p class="muted">Aucune allocation proposée. Vérifie les cibles ou le montant.</p>';return}box.innerHTML=list.map(x=>`<div class="recommendation"><span><strong>${escapeHtml(x.name)}</strong><small>${Number(x.weight_pct).toFixed(1)} % actuel → cible ${Number(x.target_pct).toFixed(1)} %</small></span><strong>${euro.format(x.amount)}</strong></div>`).join('');}
async function saveGoals(){const monthly=Number(document.querySelector('#effortMonthlyTarget').value)||0,annual=Number(document.querySelector('#effortAnnualGoal').value)||0;const st=document.querySelector('#goalsStatus');try{await api('/api/settings/goals',{method:'POST',body:JSON.stringify({monthly_target:monthly,annual_goal:annual})});st.textContent='Objectifs enregistrés.';st.className='status okBox';await load()}catch(err){st.textContent=err.message;st.className='status errorBox'}}
async function saveTrRef(){const v=Number(document.querySelector('#trReferenceValue').value)||0;await api('/api/settings/goals',{method:'POST',body:JSON.stringify({tr_reference_value:v})});await load();}
function renderMilestones(){const box=document.querySelector('#milestoneGrid');if(!box||!state)return;const settings=projectionSettings();const monthly=Math.max(0,Number(document.querySelector('#projectionMonthly')?.value)||settings.monthly);const annual=Number(document.querySelector('#projectionReturn')?.value)||settings.annualReturn;const current=Number(state.total_value)||0;const targets=[10000,25000,50000,100000,250000];box.innerHTML=targets.map(target=>{if(current>=target)return `<div class="milestone reached"><span>${euro.format(target)}</span><strong>Atteint ✓</strong></div>`;let m=null;for(let i=1;i<=600;i++){if(projectionFutureValueMonths(current,monthly,annual,i)>=target){m=i;break}}const label=m?`${Math.floor(m/12)?Math.floor(m/12)+' an'+(Math.floor(m/12)>1?'s':'')+' ':''}${m%12?m%12+' mois':''}`:'> 50 ans';return `<div class="milestone"><span>${euro.format(target)}</span><strong>${label.trim()}</strong></div>`}).join('');}
function renderScenario(){const out=document.querySelector('#scenarioResult');if(!out||!state)return;const one=Math.max(0,Number(document.querySelector('#scenarioOneOff')?.value)||0),monthly=Math.max(0,Number(document.querySelector('#scenarioMonthly')?.value)||projectionSettings().monthly),years=Number(document.querySelector('#scenarioYears')?.value)||5,annual=Number(document.querySelector('#scenarioReturn')?.value)||6;const val=projectionFutureValue(Number(state.total_value||0)+one,monthly,annual,years);out.innerHTML=`Avec <strong>${euro.format(one)}</strong> de versement ponctuel puis <strong>${euro.format(monthly)}/mois</strong>, la valeur projetée à ${years} an${years>1?'s':''} serait d’environ <strong>${euro.format(val)}</strong> avec ${annual.toFixed(1)} %/an.`;}
function bindAnalyticsControls(){document.querySelectorAll('[data-position-view]').forEach(btn=>btn.addEventListener('click',()=>{positionView=btn.dataset.positionView||'TOTAL';renderTable();renderPositionCards();}));document.querySelector('#saveGoalsBtn')?.addEventListener('click',saveGoals);document.querySelector('#rebalanceBtn')?.addEventListener('click',calculateRebalance);document.querySelector('#saveTrRefBtn')?.addEventListener('click',saveTrRef);['#scenarioOneOff','#scenarioMonthly','#scenarioYears','#scenarioReturn'].forEach(sel=>document.querySelector(sel)?.addEventListener('input',renderScenario));['#projectionMonthly','#projectionReturn'].forEach(sel=>document.querySelector(sel)?.addEventListener('input',()=>{renderMilestones();renderScenario()}));const saved=localStorage.getItem('portfolioActiveTab');if(saved&&tabMeta[saved])activateTab(saved);}

// PWA installable (Android / desktop)
document.querySelector('#cloudDbImportBtn')?.addEventListener('click',async()=>{const file=document.querySelector('#cloudDbFile').files?.[0];const status=document.querySelector('#cloudDbImportStatus');if(!file){status.textContent='Choisis une copie de portfolio.db.';status.className='status errorBox';return}const replace=document.querySelector('#cloudDbReplace').checked;if(replace&&!confirm('Remplacer toutes les données actuellement présentes dans le cloud ?'))return;status.textContent='Import en cours…';status.className='status';try{const r=await fetch(`/api/admin/import-sqlite?replace=${replace?'true':'false'}`,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:file,cache:'no-store'});const data=await r.json();if(r.status===401){location.href='/login';return}if(!r.ok)throw new Error(data.detail||'Import impossible');status.textContent=`Import terminé : ${data.counts?.positions||0} positions et ${data.counts?.transactions||0} transactions.`;status.className='status okBox';await load()}catch(err){status.textContent=err.message;status.className='status errorBox'}});

let deferredInstallPrompt=null;
const installBtn=document.querySelector('#installPwaBtn');
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();deferredInstallPrompt=event;if(installBtn)installBtn.hidden=false});
if(installBtn)installBtn.addEventListener('click',async()=>{if(!deferredInstallPrompt)return;deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;installBtn.hidden=true});
window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;if(installBtn)installBtn.hidden=true});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>{}));}

boot().then(resumeQuoteRefresh).catch(err=>{const s=document.querySelector('#status');s.textContent=err.message;s.className='status errorBox'});

// Mise à jour de l'application (v2.5+)
async function loadUpdateStatus(){
  const box=document.querySelector('#updateStatus');
  try{
    const u=await api('/api/update/status');
    document.querySelector('#updateVersion').textContent=`Version actuelle : v${u.current_version}`;
    if(u.cloud_mode){
      const updateBox=document.querySelector('#updateBox');
      if(updateBox) updateBox.innerHTML=`<div><strong>Mises à jour cloud</strong><p class="muted">${escapeHtml(u.message||'Les mises à jour sont déployées côté serveur.')}</p></div><p class="positionMeta">Version actuelle : v${escapeHtml(u.current_version)}</p>`;
      return;
    }
    const restore=document.querySelector('#restoreUpdateBtn');
    restore.disabled=!u.can_restore;
    restore.title=u.can_restore?'Restaurer la dernière version sauvegardée':'Aucune version précédente disponible';
    if(box && !box.textContent) box.textContent=u.can_restore?`Une sauvegarde de version est disponible.`:'Aucune sauvegarde de version pour le moment.';
  }catch(err){if(box){box.textContent=err.message;box.className='status errorBox'}}
}

async function fetchWithTimeout(url,options={},timeout=4000){
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeout);
  try{const response=await fetch(url,{...options,signal:controller.signal,cache:'no-store'});const body=await response.text();return {ok:response.ok,status:response.status,text:async()=>body,json:async()=>JSON.parse(body)};}finally{clearTimeout(timer);}
}
let updateBusy=false;
function setUpdateBusy(busy){updateBusy=busy;document.querySelector('#installUpdateBtn').disabled=busy;document.querySelector('#restoreUpdateBtn').disabled=busy;document.querySelector('#updateFile').disabled=busy;}
async function waitForVersion(expected){
  const status=document.querySelector('#updateStatus');const deadline=Date.now()+90000;
  while(Date.now()<deadline){
    try{
      const r=await fetchWithTimeout(`/api/health?t=${Date.now()}`,{},3000);
      if(r.ok){const h=await r.json();if(h.ok&&h.version===expected){
        status.textContent=`Version ${h.version} démarrée. Rechargement…`;status.className='status okBox';
        const dialog=document.querySelector('#settingsDialog');if(dialog.open)dialog.close();
        location.replace(`/?v=${encodeURIComponent(h.version)}&t=${Date.now()}`);return true;
      }}
    }catch{}
    status.textContent=`Mise à jour installée. Redémarrage en cours… ${Math.max(0,Math.ceil((deadline-Date.now())/1000))} s maximum.`;
    await new Promise(r=>setTimeout(r,1000));
  }
  status.textContent='Les fichiers sont installés, mais le redémarrage n’a pas été confirmé. Relance “Mon Portefeuille” ou start-portfolio.bat, puis recharge cette page. En cas de nouvel échec, consulte .updates/restart.log.';
  status.className='status errorBox';return false;
}

document.querySelector('#installUpdateBtn').addEventListener('click',async()=>{
  if(updateBusy)return;
  const input=document.querySelector('#updateFile');
  const status=document.querySelector('#updateStatus');
  const file=input.files?.[0];
  if(!file){status.textContent='Choisis d’abord un fichier .ptupdate ou .zip.';status.className='status errorBox';return}
  if(!confirm(`Installer ${file.name} ? Une sauvegarde de l’application et de la base sera créée automatiquement.`)) return;
  setUpdateBusy(true);
  status.textContent='Vérification et installation… ne ferme pas cette page.';status.className='status';
  try{
    const r=await fetchWithTimeout('/api/update/install',{method:'POST',headers:{'Content-Type':'application/zip','X-Update-Filename':file.name},body:file,cache:'no-store'},300000);
    const raw=await r.text();let data={};try{data=raw?JSON.parse(raw):{}}catch{data={detail:raw}}
    if(!r.ok) throw new Error(data.detail||`Erreur HTTP ${r.status}`);
    status.textContent=`Mise à jour ${data.to_version} installée. Redémarrage…`;
    status.className='status okBox';
    await waitForVersion(data.to_version);
  }catch(err){status.textContent=err.name==='AbortError'?'Le serveur ne répond plus. Relance Mon Portefeuille et vérifie la version avant de réessayer.':err.message;status.className='status errorBox'}finally{setUpdateBusy(false);}
});

document.querySelector('#restoreUpdateBtn').addEventListener('click',async()=>{
  if(updateBusy)return;
  const status=document.querySelector('#updateStatus');
  if(!confirm('Restaurer la dernière version de l’application ? Les données du portefeuille ne seront pas remplacées.')) return;
  setUpdateBusy(true);
  status.textContent='Restauration de la version précédente…';status.className='status';
  try{
    const response=await fetchWithTimeout('/api/update/restore-latest',{method:'POST'},300000);const r=await response.json();if(!response.ok)throw new Error(r.detail||'Restauration impossible');
    status.textContent=`Version précédente restaurée. Redémarrage…`;
    status.className='status okBox';
    await waitForVersion(r.restored.version);
  }catch(err){status.textContent=err.message;status.className='status errorBox'}finally{setUpdateBusy(false);}
});

// Charger l'état du système de mise à jour à l'ouverture des réglages.
const originalSettingsHandler=document.querySelector('#settingsBtn');
originalSettingsHandler.addEventListener('click',()=>setTimeout(loadUpdateStatus,0));

function syncTxAccount(){const p=state?.positions.find(p=>+p.id===+document.querySelector('#txPosition').value);document.querySelector('#txAccount').value=p?.account||'';}
function updateFrameworkFields(){const other=document.querySelector('#txOrigin').value==='Autre';document.querySelector('#txCustomLabel').hidden=!other;document.querySelector('#txCustomLabel').style.display=other?'grid':'none';document.querySelector('#txCustom').required=other;syncTxAccount();}
document.querySelector('#txOrigin').addEventListener('change',updateFrameworkFields);
document.querySelector('#txPosition').addEventListener('change',syncTxAccount);
// Refresh the active period after returning to the app, including October rollover.
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&state)load();});

setInterval(()=>{if(!analyticsState||document.hidden)return;const now=new Date();const startYear=now.getMonth()>=9?now.getFullYear():now.getFullYear()-1;if(analyticsState.effort.period_start!==`${startYear}-10-01`)load();},60000);

function renderEffortConfirmations(e){
  const select=document.querySelector('#effortConfirmPosition');const previous=select.value;
  select.innerHTML=state.positions.filter(p=>p.account==='PEA').map(p=>`<option value="${p.id}">${escapeHtml(p.name)} · PEA</option>`).join('');
  if([...select.options].some(o=>o.value===previous))select.value=previous;
  const month=document.querySelector('#effortConfirmMonth');if(!month.value)month.value=localIsoDate().slice(0,7);month.max=localIsoDate().slice(0,7);
  const entries=e.confirmations||[];
  document.querySelector('#effortConfirmList').innerHTML=entries.map(c=>`<div class="breakdownRow"><span>${escapeHtml(c.position_name)} · ${escapeHtml(c.month)}${c.account!=='PEA'?' · hors PEA, exclu':''}</span><strong>${euro.format(c.amount_eur)}</strong><small>Complément ${euro.format(c.added_to_effort)}</small><button type="button" class="secondary" data-confirm-position="${c.position_id}" data-confirm-month="${escapeHtml(c.month)}">Modifier</button></div>`).join('');
  document.querySelectorAll('[data-confirm-position]').forEach(button=>button.addEventListener('click',()=>{select.value=button.dataset.confirmPosition;month.value=button.dataset.confirmMonth;syncEffortConfirmation();}));
}
function syncEffortConfirmation(){const entry=analyticsState?.effort?.confirmations?.find(c=>+c.position_id===+document.querySelector('#effortConfirmPosition').value&&c.month===document.querySelector('#effortConfirmMonth').value);document.querySelector('#effortConfirmAmount').value=entry?.amount_eur??'';}
document.querySelector('#effortConfirmPosition').addEventListener('change',syncEffortConfirmation);
document.querySelector('#effortConfirmMonth').addEventListener('change',syncEffortConfirmation);
document.querySelector('#effortConfirmForm').addEventListener('submit',async event=>{
 event.preventDefault();const status=document.querySelector('#effortConfirmStatus');const button=document.querySelector('#effortConfirmSave');button.disabled=true;
 try{await api('/api/effort/monthly-confirmations',{method:'POST',body:JSON.stringify({position_id:+document.querySelector('#effortConfirmPosition').value,month:document.querySelector('#effortConfirmMonth').value,amount_eur:+document.querySelector('#effortConfirmAmount').value})});await load();status.textContent='Effort enregistré. Quantité, PRU et valeur de la position inchangés.';status.className='status okBox';}catch(error){status.textContent=error.message;status.className='status errorBox';}finally{button.disabled=false;}
});

function syncPositionScroll(){const wrap=document.querySelector('#positionsTableWrap'),range=document.querySelector('#positionsScrollRange');if(!wrap||!range)return;const max=Math.max(0,wrap.scrollWidth-wrap.clientWidth);range.max=String(max);range.value=String(wrap.scrollLeft);range.disabled=max===0;document.querySelector('#positionsScrollLeft').disabled=wrap.scrollLeft<=0;document.querySelector('#positionsScrollRight').disabled=wrap.scrollLeft>=max-1;}
const positionScrollWrap=document.querySelector('#positionsTableWrap');
positionScrollWrap.addEventListener('scroll',syncPositionScroll,{passive:true});
document.querySelector('#positionsScrollRange').addEventListener('input',event=>{positionScrollWrap.scrollLeft=+event.target.value;syncPositionScroll();});
document.querySelector('#positionsScrollLeft').addEventListener('click',()=>{positionScrollWrap.scrollLeft-=Math.max(200,positionScrollWrap.clientWidth*.65);syncPositionScroll();});
document.querySelector('#positionsScrollRight').addEventListener('click',()=>{positionScrollWrap.scrollLeft+=Math.max(200,positionScrollWrap.clientWidth*.65);syncPositionScroll();});
new ResizeObserver(syncPositionScroll).observe(positionScrollWrap);
