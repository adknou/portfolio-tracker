"""Pure, testable opportunity comparison. Prices are EUR closing prices by calendar day."""
from datetime import date, timedelta


def compare_opportunity(start, end, quantity, prices, transactions):
    if not (start < end and quantity > 0):
        raise ValueError('Dates ou quantité invalides')
    calendar = [(date.fromisoformat(start) + timedelta(days=i)).isoformat()
                for i in range((date.fromisoformat(end)-date.fromisoformat(start)).days+1)]
    known = sorted((day, float(price)) for day, price in prices.items() if price and float(price)>0 and day<=end)
    if not known or known[0][0] > start:
        raise ValueError('Cours au début indisponible')
    by_day = {}
    initial_qty = 0.0
    for tx in sorted(transactions, key=lambda t:(t['transaction_date'], t.get('id',0))):
        day = tx['transaction_date']; typ = tx['transaction_type']; q=float(tx.get('quantity') or 0)
        if day<=start:
            if typ in ('opening','buy'): initial_qty+=q
            elif typ=='sell':initial_qty-=q
        elif day<=end:
            by_day.setdefault(day,[]).append(tx)
    if initial_qty < -1e-7: raise ValueError('Historique de quantité incohérent')
    current_price=None;cursor=0;qty=initial_qty;cash=0.; invested=0.;extra_div=0.;warnings=[];points=[]
    for day in calendar:
        while cursor<len(known) and known[cursor][0]<=day:
            current_price=known[cursor][1];cursor+=1
        if current_price is None:raise ValueError('Cours indisponible')
        if day==start:
            initial_price=current_price
            initial_value=qty*initial_price
        else:
            for tx in by_day.get(day,[]):
                typ=tx['transaction_type'];q=float(tx.get('quantity') or 0)
                gross=float(tx.get('gross_amount_eur') or 0);fee=float(tx.get('fees_eur') or 0)
                if typ=='buy':
                    if q<=0:raise ValueError('Achat avec quantité invalide')
                    amount=gross if gross>0 else q*float(tx.get('unit_price_eur') or 0)
                    if amount<=0:raise ValueError('Prix d’achat manquant')
                    qty+=q;cash-=amount+fee;invested+=amount+fee
                elif typ=='sell':
                    if q>qty+1e-7:raise ValueError('Vente supérieure à la quantité détenue')
                    qty-=q;cash+=gross-fee
                elif typ=='dividend':
                    cash+=gross
                    if qty>1e-9:extra_div+=quantity*gross/qty
                    else:warnings.append(f'{day} : dividende sans quantité réelle, supplément fictif non calculable')
                elif typ=='fee':cash-=gross+fee
        real_gain=qty*current_price+cash-initial_value
        extra_gain=quantity*(current_price-initial_price)+extra_div
        sim_gain=real_gain+extra_gain
        real_base=initial_value+invested
        sim_base=real_base+quantity*initial_price
        points.append({'date':day,'real_gain_eur':round(real_gain,4),'simulation_gain_eur':round(sim_gain,4),
                       'real_pct':round(100*real_gain/real_base,5) if real_base>1e-9 else None,
                       'simulation_pct':round(100*sim_gain/sim_base,5) if sim_base>1e-9 else None})
    extra=points[-1]['simulation_gain_eur']-points[-1]['real_gain_eur']
    return {'points':points,'final':points[-1], 'impact_eur':round(extra,2),
            'impact_pct':round(100*extra/(quantity*initial_price),5),
            'fictitious_cost_eur':round(quantity*initial_price,2),
            'extra_dividends_eur':round(extra_div,2),'warnings':warnings,
            'method':'Gains cumulés depuis le début, apports déduits; rendement simple sur valeur initiale plus achats réels. Dividendes fictifs estimés au prorata des quantités détenues.'}
