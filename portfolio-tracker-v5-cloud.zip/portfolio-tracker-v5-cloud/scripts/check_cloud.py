#!/usr/bin/env python3
import os
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
if not os.getenv('DATABASE_URL'):
    raise SystemExit('DATABASE_URL manquant')
from storage import connect, backend_name
conn=connect()
try:
    print('backend:', backend_name())
    for t in ('positions','transactions','portfolio_snapshots','settings'):
        print(t, conn.execute(f'SELECT COUNT(*) AS c FROM {t}').fetchone()['c'])
finally:
    conn.close()
