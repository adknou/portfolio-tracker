#!/usr/bin/env python3
import base64
import getpass
import hashlib
import os

ITERATIONS = 310_000

def b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip('=')

password = getpass.getpass('Mot de passe Portfolio Tracker: ')
confirm = getpass.getpass('Confirme le mot de passe: ')
if not password or password != confirm:
    raise SystemExit('Les mots de passe ne correspondent pas ou sont vides.')
salt = os.urandom(16)
digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, ITERATIONS)
print(f'pbkdf2_sha256${ITERATIONS}${b64(salt)}${b64(digest)}')
