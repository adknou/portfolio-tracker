#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def parse_args():
    p = argparse.ArgumentParser(description='Migre Portfolio Tracker SQLite vers PostgreSQL/Neon.')
    p.add_argument('sqlite_db', type=Path, help='Chemin vers portfolio.db')
    p.add_argument('--replace', action='store_true', help='Efface les données Portfolio Tracker déjà présentes dans PostgreSQL.')
    return p.parse_args()


def main():
    args = parse_args()
    if not args.sqlite_db.exists():
        raise SystemExit(f'Base SQLite introuvable: {args.sqlite_db}')
    if not os.getenv('DATABASE_URL', '').startswith(('postgres://', 'postgresql://')):
        raise SystemExit('DATABASE_URL doit contenir la chaîne PostgreSQL Neon avant de lancer la migration.')

    import app
    from storage import connect, columns, reset_postgres_sequences

    app.init_db()
    src = sqlite3.connect(args.sqlite_db)
    src.row_factory = sqlite3.Row
    dst = connect()

    tables = ['positions', 'transactions', 'effort_monthly_confirmations', 'portfolio_snapshots', 'settings']
    counts = {t: dst.execute(f'SELECT COUNT(*) AS c FROM {t}').fetchone()['c'] for t in tables}
    if any(counts.values()) and not args.replace:
        raise SystemExit('La base PostgreSQL contient déjà des données. Relance avec --replace uniquement si tu veux les remplacer.')

    try:
        if args.replace or any(counts.values()):
            for t in ['transactions', 'effort_monthly_confirmations', 'portfolio_snapshots', 'positions', 'settings']:
                dst.execute(f'DELETE FROM {t}')

        for table in tables:
            src_cols = [r['name'] for r in src.execute(f'PRAGMA table_info({table})').fetchall()]
            dst_cols = columns(dst, table)
            copy_cols = [c for c in src_cols if c in dst_cols]
            rows = src.execute(f"SELECT {','.join(copy_cols)} FROM {table}").fetchall()
            if table == 'settings':
                rows = [r for r in rows if r['key'] != 'eodhd_api_token']
            if not rows:
                continue
            placeholders = ','.join('?' for _ in copy_cols)
            sql = f"INSERT INTO {table} ({','.join(copy_cols)}) VALUES ({placeholders})"
            values = [tuple(r[c] for c in copy_cols) for r in rows]
            dst.executemany(sql, values)
            print(f'{table}: {len(values)} lignes importées')

        # Never keep a market API secret in the database in cloud mode.
        dst.execute("INSERT INTO settings(key,value) VALUES('eodhd_api_token','') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        dst.commit()
        reset_postgres_sequences(dst)
        dst.commit()
    except Exception:
        dst.rollback()
        raise
    finally:
        src.close()
        dst.close()

    # Re-run additive migrations and defaults after importing the historical schema.
    app.init_db()
    check = connect()
    try:
        print('\nMigration terminée:')
        for table in tables:
            print(f"- {table}: {check.execute(f'SELECT COUNT(*) AS c FROM {table}').fetchone()['c']}")
    finally:
        check.close()


if __name__ == '__main__':
    main()
