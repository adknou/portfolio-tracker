#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def parse_args():
    p = argparse.ArgumentParser(description='Restaure une sauvegarde JSON Portfolio Tracker dans PostgreSQL.')
    p.add_argument('backup', type=Path)
    p.add_argument('--replace', action='store_true', required=True, help='Confirme le remplacement complet des données cloud.')
    return p.parse_args()


def main():
    args = parse_args()
    if not args.backup.exists():
        raise SystemExit(f'Sauvegarde introuvable: {args.backup}')
    if not os.getenv('DATABASE_URL', '').startswith(('postgres://', 'postgresql://')):
        raise SystemExit('DATABASE_URL doit pointer vers PostgreSQL/Neon.')
    payload = json.loads(args.backup.read_text(encoding='utf-8'))
    if payload.get('format') != 'portfolio-tracker-backup-v1':
        raise SystemExit('Format de sauvegarde non reconnu.')

    import app
    from storage import connect, columns, reset_postgres_sequences

    app.init_db()
    conn = connect()
    tables = ['positions', 'transactions', 'effort_monthly_confirmations', 'portfolio_snapshots', 'settings']
    try:
        for t in ['transactions', 'effort_monthly_confirmations', 'portfolio_snapshots', 'positions', 'settings']:
            conn.execute(f'DELETE FROM {t}')
        for table in tables:
            rows = payload.get('tables', {}).get(table, [])
            if table == 'settings':
                rows = [r for r in rows if r.get('key') != 'eodhd_api_token']
            if not rows:
                continue
            allowed = columns(conn, table)
            cols = [c for c in rows[0].keys() if c in allowed]
            sql = f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' for _ in cols)})"
            conn.executemany(sql, [tuple(r.get(c) for c in cols) for r in rows])
        conn.execute("INSERT INTO settings(key,value) VALUES('eodhd_api_token','') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        conn.commit()
        reset_postgres_sequences(conn)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    app.init_db()
    print('Restauration terminée.')


if __name__ == '__main__':
    main()
