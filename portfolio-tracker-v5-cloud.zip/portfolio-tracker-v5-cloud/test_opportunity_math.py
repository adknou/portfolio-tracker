import unittest
from opportunity_math import compare_opportunity

class OpportunityTests(unittest.TestCase):
    def test_no_real_transaction(self):
        r=compare_opportunity('2026-11-04','2026-11-05',10,{'2026-11-04':15,'2026-11-05':14},[{'transaction_date':'2026-01-01','transaction_type':'buy','quantity':100}])
        self.assertEqual(r['final']['real_gain_eur'],-100)
        self.assertEqual(r['final']['simulation_gain_eur'],-110)
        self.assertEqual(r['impact_eur'],-10)
    def test_real_buy_and_hypothetical(self):
        r=compare_opportunity('2026-11-01','2026-11-03',100,{'2026-11-01':10,'2026-11-02':12,'2026-11-03':14},[{'transaction_date':'2026-11-02','transaction_type':'buy','quantity':50,'gross_amount_eur':600}])
        self.assertEqual(r['final']['real_gain_eur'],100)
        self.assertEqual(r['final']['simulation_gain_eur'],500)
        self.assertEqual(r['impact_pct'],40)
    def test_sale_and_dividend(self):
        r=compare_opportunity('2026-11-01','2026-11-03',10,{'2026-11-01':10,'2026-11-02':11,'2026-11-03':12},[
            {'transaction_date':'2026-10-01','transaction_type':'buy','quantity':100},
            {'transaction_date':'2026-11-02','transaction_type':'sell','quantity':20,'gross_amount_eur':220,'fees_eur':2},
            {'transaction_date':'2026-11-03','transaction_type':'dividend','gross_amount_eur':80}])
        self.assertEqual(r['final']['real_gain_eur'],258)
        self.assertEqual(r['extra_dividends_eur'],10)
        self.assertEqual(r['impact_eur'],30)
    def test_missing_initial_price(self):
        with self.assertRaises(ValueError):compare_opportunity('2026-11-01','2026-11-02',1,{'2026-11-02':10},[])

if __name__=='__main__':unittest.main()
