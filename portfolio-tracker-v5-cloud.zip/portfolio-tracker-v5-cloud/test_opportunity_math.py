import unittest
from opportunity_math import compare_opportunity

class OpportunityTests(unittest.TestCase):
    def test_no_real_transaction(self):
        r=compare_opportunity('2026-11-04','2026-11-05',10,{'2026-11-04':15,'2026-11-05':14},[{'transaction_date':'2026-01-01','transaction_type':'buy','quantity':100}])
        self.assertEqual(r['final']['real_gain_eur'],-100)
        self.assertEqual(r['final']['simulation_gain_eur'],-110)
        self.assertEqual(r['impact_eur'],-10)
    def test_real_buy_and_hypothetical(self):
        r=compare_opportunity('2026-11-01','2026-11-03',100,{'2026-11-01':10,'2026-11-02':12,'2026-11-03':14},[{'transaction_date':'2026-11-02','transaction_type':'buy','quantity':50,'gross_amount_eur':600}])
        self.assertEqual(r['final']['real_gain_eur'],100)
        self.assertEqual(r['final']['simulation_gain_eur'],500)
        self.assertEqual(r['impact_pct'],40)
    def test_sale_and_dividend(self):
        r=compare_opportunity('2026-11-01','2026-11-03',10,{'2026-11-01':10,'2026-11-02':11,'2026-11-03':12},[
            {'transaction_date':'2026-10-01','transaction_type':'buy','quantity':100},
            {'transaction_date':'2026-11-02','transaction_type':'sell','quantity':20,'gross_amount_eur':220,'fees_eur':2},
            {'transaction_date':'2026-11-03','transaction_type':'dividend','gross_amount_eur':80}])
        self.assertEqual(r['final']['real_gain_eur'],258)
        self.assertEqual(r['extra_dividends_eur'],10)
        self.assertEqual(r['impact_eur'],30)
    def test_missing_initial_price(self):
        with self.assertRaises(ValueError):compare_opportunity('2026-11-01','2026-11-02',1,{'2026-11-02':10},[])

if __name__=='__main__':unittest.main()

class UnitPriceSeriesTests(unittest.TestCase):
    def test_unit_price_tracks_quotes_independently_of_gains(self):
        result=compare_opportunity('2026-11-04','2026-11-06',10,
            {'2026-11-04':15,'2026-11-05':14,'2026-11-06':16},[])
        self.assertEqual([p['unit_price_eur'] for p in result['points']],[15,14,16])
        self.assertEqual(result['impact_eur'],10)

class PortfolioValueSeriesTests(unittest.TestCase):
    def test_both_curves_include_actual_buys_sells_and_fictitious_units(self):
        result=compare_opportunity('2026-11-01','2026-11-04',10,
            {'2026-11-01':10,'2026-11-02':11,'2026-11-03':12,'2026-11-04':13},[
            {'transaction_date':'2026-10-01','transaction_type':'buy','quantity':100},
            {'transaction_date':'2026-11-02','transaction_type':'buy','quantity':20,'gross_amount_eur':220},
            {'transaction_date':'2026-11-03','transaction_type':'sell','quantity':30,'gross_amount_eur':360},
            {'transaction_date':'2026-11-04','transaction_type':'dividend','gross_amount_eur':90}])
        self.assertEqual([p['real_value_eur'] for p in result['points']],[1000,1320,1080,1170])
        self.assertEqual([p['simulation_value_eur'] for p in result['points']],[1100,1430,1200,1300])
        self.assertEqual(result['impact_eur'],40)
        self.assertEqual(result['extra_dividends_eur'],10)
    def test_zero_real_position_still_shows_fictitious_portfolio(self):
        result=compare_opportunity('2026-11-01','2026-11-02',3,
            {'2026-11-01':5,'2026-11-02':6},[])
        self.assertEqual([p['real_value_eur'] for p in result['points']],[0,0])
        self.assertEqual([p['simulation_value_eur'] for p in result['points']],[15,18])
