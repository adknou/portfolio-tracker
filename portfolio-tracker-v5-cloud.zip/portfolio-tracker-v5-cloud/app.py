from __future__ import annotations

import json
import base64
import hashlib
import hmac
import secrets
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import date, timedelta, datetime, timezone
from pathlib import Path
from io import BytesIO
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, StreamingResponse, HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.chart import LineChart, Reference

from storage import connect as storage_connect, columns as storage_columns, add_column as storage_add_column, create_schema, is_integrity_error, backend_name, USE_POSTGRES, reset_postgres_sequences

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "portfolio.db"
CLOUD_MODE = bool(os.getenv("CLOUD_MODE", "1" if USE_POSTGRES else "0") == "1")
SEED_PATH = ROOT / "data" / "seed_positions.json"
USER_AGENT = "Mozilla/5.0 PortfolioTracker/5.0"
APP_ID = "trade-republic-portfolio-mvp"
APP_VERSION = "5.6.5"
UPDATES_DIR = ROOT / ".updates"
BACKUPS_DIR = UPDATES_DIR / "backups"
DB_BACKUPS_DIR = UPDATES_DIR / "db_backups"
FX_CACHE: dict[str, tuple[float, str, int]] = {}

app = FastAPI(title=f"Portfolio Tracker v{APP_VERSION}")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

AUTH_USERNAME = os.getenv("APP_USERNAME", "").strip()
AUTH_PASSWORD_HASH = os.getenv("APP_PASSWORD_HASH", "").strip()
SESSION_SECRET = os.getenv("SESSION_SECRET", "").strip()
AUTH_ENABLED = CLOUD_MODE or os.getenv("AUTH_ENABLED", "0") == "1"
SESSION_COOKIE = "pt_session"
SESSION_TTL = 60 * 60 * 24 * 14


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _b64url_decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        salt = _b64url_decode(salt_b64)
        expected = _b64url_decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def _session_token(username: str, expires: int) -> str:
    payload = f"{username}|{expires}"
    sig = hmac.new(SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).digest()
    return _b64url(payload.encode()) + "." + _b64url(sig)


def _session_valid(token: str | None) -> bool:
    if not token or not SESSION_SECRET:
        return False
    try:
        body, sig = token.split(".", 1)
        payload = _b64url_decode(body).decode()
        username, expires_text = payload.rsplit("|", 1)
        expected = hmac.new(SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(_b64url_decode(sig), expected):
            return False
        return username == AUTH_USERNAME and int(expires_text) >= int(time.time())
    except Exception:
        return False


def market_token() -> str:
    env_token = os.getenv("EODHD_API_TOKEN", "").strip()
    if env_token:
        return env_token
    return get_settings().get("eodhd_api_token", "").strip()


@app.middleware("http")
async def cloud_auth(request: Request, call_next):
    if not AUTH_ENABLED:
        return await call_next(request)
    path = request.url.path
    public = path in {"/login", "/api/health", "/manifest.webmanifest", "/sw.js"} or path.startswith("/static/")
    if public:
        return await call_next(request)
    if not _session_valid(request.cookies.get(SESSION_COOKIE)):
        if path.startswith("/api/"):
            return JSONResponse({"detail": "Authentification requise"}, status_code=401)
        return RedirectResponse("/login", status_code=303)
    return await call_next(request)


LOGIN_HTML = """<!doctype html><html lang='fr'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><meta name='theme-color' content='#111827'><title>Connexion · Portfolio Tracker</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#f4f6f8;margin:0;min-height:100vh;display:grid;place-items:center;color:#111827}.card{width:min(92vw,380px);background:white;padding:28px;border-radius:18px;box-shadow:0 12px 40px #0002}h1{margin:0 0 8px;font-size:1.5rem}p{color:#64748b}label{display:grid;gap:6px;margin:16px 0;font-weight:600}input{font:inherit;padding:12px;border:1px solid #cbd5e1;border-radius:10px}button{width:100%;font:inherit;font-weight:700;padding:12px;border:0;border-radius:10px;background:#111827;color:white;cursor:pointer}.err{color:#b91c1c;font-size:.9rem}</style></head><body><form class='card' method='post' action='/login'><h1>Portfolio Tracker</h1><p>Connexion à ton portefeuille cloud.</p><label>Identifiant<input name='username' autocomplete='username' required></label><label>Mot de passe<input name='password' type='password' autocomplete='current-password' required></label>__ERROR__<button type='submit'>Se connecter</button></form></body></html>"""


@app.get("/login")
def login_page(request: Request):
    if AUTH_ENABLED and _session_valid(request.cookies.get(SESSION_COOKIE)):
        return RedirectResponse("/", status_code=303)
    return HTMLResponse(LOGIN_HTML.replace("__ERROR__", ""))


@app.post("/login")
async def login_submit(request: Request):
    body = (await request.body()).decode("utf-8", "replace")
    values = urllib.parse.parse_qs(body)
    username = (values.get("username") or [""])[0]
    password = (values.get("password") or [""])[0]
    if not (secrets.compare_digest(username, AUTH_USERNAME) and verify_password(password, AUTH_PASSWORD_HASH)):
        return HTMLResponse(LOGIN_HTML.replace("__ERROR__", "<p class='err'>Identifiant ou mot de passe incorrect.</p>"), status_code=401)
    expires = int(time.time()) + SESSION_TTL
    response = RedirectResponse("/", status_code=303)
    response.set_cookie(SESSION_COOKIE, _session_token(username, expires), max_age=SESSION_TTL, httponly=True, secure=CLOUD_MODE, samesite="lax", path="/")
    return response


@app.post("/logout")
def logout():
    response = RedirectResponse("/login", status_code=303)
    response.delete_cookie(SESSION_COOKIE, path="/")
    return response


@app.middleware("http")
async def disable_browser_cache(request, call_next):
    response = await call_next(request)
    if request.url.path == "/" or request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


def db():
    return storage_connect()


def _columns(conn, table: str) -> set[str]:
    return storage_columns(conn, table)


def _add_column(conn, table: str, definition: str) -> None:
    storage_add_column(conn, table, definition)


FRAMEWORKS = {"Plan PEA", "Round Up", "Saveback", "Investissement libre", "Autre"}


def map_framework(origin):
    original = (origin or "").strip()
    key = re.sub(r"[\s_-]+", "", original.casefold())
    mapping = {"planmensuel":"Plan PEA", "planpea":"Plan PEA", "roundup":"Round Up", "saveback":"Saveback", "ponctuel":"Investissement libre", "investissementponctuel":"Investissement libre", "investissementlibre":"Investissement libre"}
    return mapping.get(key, "Autre"), original if key not in mapping else ""


def effort_period(today):
    start_year = today.year if today.month >= 10 else today.year - 1
    return date(start_year, 10, 1), date(start_year + 1, 10, 1)


def init_db() -> None:
    conn = db()
    create_schema(conn)

    _add_column(conn, "transactions", "origin TEXT NOT NULL DEFAULT 'Autre'")
    _add_column(conn, "transactions", "investment_framework TEXT NOT NULL DEFAULT ''")
    _add_column(conn, "transactions", "framework_label TEXT NOT NULL DEFAULT ''")
    _add_column(conn, "transactions", "investment_account TEXT NOT NULL DEFAULT ''")
    if "origin" in _columns(conn, "transactions"):
        for row in conn.execute("SELECT t.id,t.origin,p.account FROM transactions t JOIN positions p ON p.id=t.position_id WHERE t.investment_framework='' ").fetchall():
            framework, label = map_framework(row["origin"])
            conn.execute("UPDATE transactions SET investment_framework=?,framework_label=?,investment_account=? WHERE id=?", (framework,label,row["account"],row["id"]))

    additions = [
        "provider TEXT NOT NULL DEFAULT 'eodhd'",
        "exchange TEXT NOT NULL DEFAULT ''",
        "mic_code TEXT NOT NULL DEFAULT ''",
        "isin TEXT NOT NULL DEFAULT ''",
        "last_native_price DOUBLE PRECISION" if USE_POSTGRES else "last_native_price REAL",
        "fx_rate_to_eur DOUBLE PRECISION NOT NULL DEFAULT 1" if USE_POSTGRES else "fx_rate_to_eur REAL NOT NULL DEFAULT 1",
        "price_updated_at BIGINT" if USE_POSTGRES else "price_updated_at INTEGER",
        "price_fetched_at BIGINT" if USE_POSTGRES else "price_fetched_at INTEGER",
        "quote_checked_at BIGINT" if USE_POSTGRES else "quote_checked_at INTEGER",
        "quote_attempted_at BIGINT" if USE_POSTGRES else "quote_attempted_at INTEGER",
        "quote_refresh_error TEXT NOT NULL DEFAULT ''",
        "avg_cost_eur DOUBLE PRECISION" if USE_POSTGRES else "avg_cost_eur REAL",
        "day_change_pct DOUBLE PRECISION" if USE_POSTGRES else "day_change_pct REAL",
        "quote_quality TEXT NOT NULL DEFAULT ''",
        "quote_note TEXT NOT NULL DEFAULT ''",
        "last_quote_provider TEXT NOT NULL DEFAULT ''",
        "manual_price DOUBLE PRECISION" if USE_POSTGRES else "manual_price REAL",
        "manual_currency TEXT NOT NULL DEFAULT 'EUR'",
        "manual_price_at BIGINT" if USE_POSTGRES else "manual_price_at INTEGER",
        "manual_price_note TEXT NOT NULL DEFAULT ''",
        "price_mode TEXT NOT NULL DEFAULT 'auto'",
    ]
    for definition in additions:
        _add_column(conn, "positions", definition)

    count = conn.execute("SELECT COUNT(*) AS c FROM positions").fetchone()["c"]
    if count == 0 and not CLOUD_MODE:
        seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))
        conn.executemany(
            """
            INSERT INTO positions
            (name, asset_type, account, currency, quantity, last_price, position_value,
             performance_pct, market_symbol, target_pct)
            VALUES (:name,:asset_type,:account,:currency,:quantity,:last_price,:position_value,
                    :performance_pct,:market_symbol,:target_pct)
            """,
            seed,
        )

    rows = conn.execute("SELECT * FROM positions WHERE avg_cost_eur IS NULL").fetchall()
    for r in rows:
        perf = float(r["performance_pct"] or 0)
        px_eur = float(r["last_price"] or 0)
        avg = px_eur / (1 + perf / 100) if perf > -100 and px_eur > 0 else None
        conn.execute("UPDATE positions SET avg_cost_eur=? WHERE id=?", (avg, r["id"]))

    defaults = {
        "monthly_plan": "510",
        "monthly_plan_asset": "Pea Global EUR (Acc)",
        "auto_refresh_minutes": "120",
        "market_provider": "eodhd",
        "eodhd_api_token": "",
        "yahoo_fallback": "1",
        "eodhd_daily_limit": "0",
        "eodhd_api_requests": "0",
        "eodhd_calls_date": "",
        "eodhd_calls_today": "0",
        "effort_monthly_target": "510",
        "annual_investment_goal": "6120",
        "effort_ytd_catchup": "0",
        "effort_catchup_year": "0",
        "tr_reference_value": "0",
    }
    for key, value in defaults.items():
        conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO NOTHING", (key, value))

    # Secrets belong to the cloud provider, never to PostgreSQL.
    if CLOUD_MODE and os.getenv("EODHD_API_TOKEN"):
        conn.execute("INSERT INTO settings(key,value) VALUES('eodhd_api_token','') ON CONFLICT(key) DO UPDATE SET value=excluded.value")

    conn.commit()
    conn.close()


@app.on_event("startup")
def startup() -> None:
    if AUTH_ENABLED:
        missing = [name for name, value in (("APP_USERNAME", AUTH_USERNAME), ("APP_PASSWORD_HASH", AUTH_PASSWORD_HASH), ("SESSION_SECRET", SESSION_SECRET)) if not value]
        if missing:
            raise RuntimeError("Secrets d'authentification manquants: " + ", ".join(missing))
    init_db()


class PositionUpdate(BaseModel):
    quantity: Optional[float] = None
    avg_cost_eur: Optional[float] = None
    account: Optional[str] = None
    target_pct: Optional[float] = None


class ManualPriceUpdate(BaseModel):
    price_eur: float
    note: str = ""


class PositionCreate(BaseModel):
    name: str
    asset_type: str = "Autre"
    account: str = "CTO"
    quantity: float
    avg_cost_eur: Optional[float] = None
    market_symbol: str = ""
    provider: str = "eodhd"
    exchange: str = ""
    currency: str = "EUR"
    isin: str = ""
    target_pct: float = 0


class MarketLink(BaseModel):
    market_symbol: str
    provider: str = "eodhd"
    exchange: str = ""
    currency: str = "EUR"
    isin: str = ""


class MarketSettings(BaseModel):
    eodhd_api_token: Optional[str] = None
    yahoo_fallback: Optional[bool] = None
    auto_refresh_minutes: Optional[int] = None


class TransactionCreate(BaseModel):
    position_id: int
    transaction_type: str
    transaction_date: str
    quantity: Optional[float] = None
    unit_price_eur: Optional[float] = None
    amount_eur: Optional[float] = None
    fees_eur: float = 0
    note: str = ""
    origin: str = "Autre"
    investment_framework: str
    framework_label: str = ""


class OpeningUpdate(BaseModel):
    quantity: float
    avg_cost_eur: float



class EffortMonthlyConfirmation(BaseModel):
    position_id: int
    month: str
    amount_eur: float


class GoalSettings(BaseModel):
    monthly_target: Optional[float] = None
    annual_goal: Optional[float] = None
    ytd_catchup: Optional[float] = None
    tr_reference_value: Optional[float] = None


def get_settings(conn: Optional[sqlite3.Connection] = None) -> dict[str, str]:
    owns = conn is None
    conn = conn or db()
    out = {r["key"]: r["value"] for r in conn.execute("SELECT * FROM settings").fetchall()}
    if owns:
        conn.close()
    return out


def set_setting(key: str, value: str) -> None:
    conn = db()
    conn.execute(
        "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )
    conn.commit()
    conn.close()


def _track_eodhd_call() -> None:
    today = date.today().isoformat()
    conn = db()
    current_date = conn.execute("SELECT value FROM settings WHERE key='eodhd_calls_date'").fetchone()
    current_date = current_date["value"] if current_date else ""
    current_count = conn.execute("SELECT value FROM settings WHERE key='eodhd_calls_today'").fetchone()
    current_count = int(current_count["value"] or 0) if current_count else 0
    if current_date != today:
        current_count = 0
    current_count += 1
    conn.execute("INSERT INTO settings(key,value) VALUES('eodhd_calls_date',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (today,))
    conn.execute("INSERT INTO settings(key,value) VALUES('eodhd_calls_today',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(current_count),))
    conn.commit(); conn.close()


def _save_snapshot(reason: str = "manual") -> None:
    try:
        snap = portfolio()
        conn = db()
        conn.execute("INSERT INTO portfolio_snapshots(created_at,total_value,invested_estimate,reason) VALUES(?,?,?,?)",
                     (int(time.time()), float(snap.get("total_value") or 0), float(snap.get("invested_estimate") or 0), reason))
        conn.commit(); conn.close()
    except Exception:
        pass


def _xirr(cashflows: list[tuple[date, float]]) -> Optional[float]:
    if len(cashflows) < 2 or not any(v < 0 for _, v in cashflows) or not any(v > 0 for _, v in cashflows):
        return None
    cashflows = sorted(cashflows, key=lambda x: x[0])
    d0 = cashflows[0][0]
    def npv(rate: float) -> float:
        if rate <= -0.999999:
            return float('inf')
        total = 0.0
        for d, value in cashflows:
            years = (d - d0).days / 365.3425
            total += value / ((1 + rate) ** years)
        return total
    lo, hi = -0.999, 10.0
    flo, fhi = npv(lo), npv(hi)
    for _ in range(20):
        if flo == 0: return lo * 100
        if fhi == 0: return hi * 100
        if flo * fhi < 0: break
        hi *= 2
        fhi = npv(hi)
        if hi > 1e6: return None
    if flo * fhi > 0: return None
    for _ in range(120):
        mid = (lo + hi) / 2
        fm = npv(mid)
        if abs(fm) < 1e-7: return mid * 100
        if flo * fm <= 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return ((lo + hi) / 2) * 100


def _auto_eur_unit_price(r) -> float:
    d = dict(r) if not isinstance(r, dict) else r
    native = d.get("last_native_price") if d.get("last_native_price") is not None else d.get("last_price")
    native = float(native or 0)
    fx = float(d.get("fx_rate_to_eur") or 1)
    return native * fx


def _eur_unit_price(r) -> float:
    d = dict(r) if not isinstance(r, dict) else r
    if d.get("price_mode") == "manual" and d.get("manual_price") is not None:
        return float(d.get("manual_price") or 0)
    return _auto_eur_unit_price(d)


def row_to_dict(r) -> dict:
    d = dict(r)
    auto_eur_price = _auto_eur_unit_price(d)
    eur_price = _eur_unit_price(d)
    position_value = round(float(d["quantity"]) * eur_price, 2)
    avg_cost = d.get("avg_cost_eur")
    invested = round(float(d["quantity"]) * float(avg_cost), 2) if avg_cost not in (None, 0) else None
    perf = ((eur_price / float(avg_cost)) - 1) * 100 if avg_cost not in (None, 0) else float(d.get("performance_pct") or 0)
    d["last_price_eur"] = round(eur_price, 6)
    d["position_value"] = position_value
    d["invested_estimate"] = invested
    d["performance_pct"] = round(perf, 2)
    d["quote_configured"] = bool((d.get("market_symbol") or "").strip())
    d["quote_stale"]=bool(d.get("price_updated_at")) and quote_is_old({"timestamp":d["price_updated_at"]})
    d["quote_warning"]="Cours ancien : date antérieure au dernier jour de semaine écoulé. Vérifie la place de cotation et la source (jours fériés possibles)." if d["quote_stale"] else ""
    d["auto_last_price_eur"] = round(auto_eur_price, 6)
    d["manual_active"] = d.get("price_mode") == "manual" and d.get("manual_price") is not None
    if d["manual_active"]:
        d["price_updated_at"] = d.get("manual_price_at") or d.get("price_updated_at")
        d["quote_quality"] = "Manuel"
        d["last_quote_provider"] = "Manuel"
        d["quote_note"] = d.get("manual_price_note") or "Cours saisi manuellement"
        d["quote_stale"] = False
        d["quote_warning"] = ""
    return d


def _transaction_stats(conn: sqlite3.Connection, position_id: int) -> dict:
    rows = conn.execute(
        "SELECT transaction_type,gross_amount_eur,fees_eur,realized_pnl_eur FROM transactions WHERE position_id=?",
        (position_id,),
    ).fetchall()
    return {
        "transaction_count": sum(1 for r in rows if r["transaction_type"] != "opening"),
        "has_transactions": any(r["transaction_type"] != "opening" for r in rows),
        "realized_pnl_eur": round(sum(float(r["realized_pnl_eur"] or 0) for r in rows), 2),
        "dividends_eur": round(sum(float(r["gross_amount_eur"] or 0) for r in rows if r["transaction_type"] == "dividend"), 2),
        "standalone_fees_eur": round(sum(float(r["gross_amount_eur"] or 0) for r in rows if r["transaction_type"] == "fee"), 2),
    }


def _ensure_opening_transaction(conn: sqlite3.Connection, position: sqlite3.Row) -> None:
    count = conn.execute("SELECT COUNT(*) AS c FROM transactions WHERE position_id=?", (position["id"],)).fetchone()["c"]
    if count:
        return
    qty = float(position["quantity"] or 0)
    if qty <= 0:
        return
    avg = position["avg_cost_eur"]
    if avg in (None, 0):
        avg = _eur_unit_price(position) or 0
    avg = float(avg or 0)
    conn.execute(
        """INSERT INTO transactions(position_id,transaction_type,transaction_date,quantity,unit_price_eur,gross_amount_eur,fees_eur,realized_pnl_eur,note)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (position["id"], "opening", "1900-01-01", qty, avg, qty * avg, 0, None, "Solde initial avant suivi des transactions"),
    )


def _rebuild_position_from_transactions(conn: sqlite3.Connection, position_id: int) -> None:
    rows = conn.execute(
        "SELECT * FROM transactions WHERE position_id=? ORDER BY transaction_date,id", (position_id,)
    ).fetchall()
    qty = 0.0
    cost = 0.0
    for r in rows:
        typ = r["transaction_type"]
        q = float(r["quantity"] or 0)
        gross = float(r["gross_amount_eur"] or 0)
        fees = float(r["fees_eur"] or 0)
        realized = None
        if typ in ("opening", "buy"):
            if q < 0:
                raise ValueError("Quantité négative dans le journal")
            qty += q
            cost += gross + (fees if typ == "buy" else 0)
        elif typ == "sell":
            if q <= 0:
                raise ValueError("Quantité de vente invalide")
            if q > qty + 1e-9:
                raise ValueError("La vente dépasse la quantité détenue")
            avg_before = cost / qty if qty > 0 else 0
            realized = gross - fees - q * avg_before
            qty -= q
            cost -= q * avg_before
            if qty < 1e-10:
                qty = 0.0
                cost = 0.0
        conn.execute("UPDATE transactions SET realized_pnl_eur=? WHERE id=?", (realized, r["id"]))
    avg = cost / qty if qty > 0 else 0
    conn.execute("UPDATE positions SET quantity=?,avg_cost_eur=? WHERE id=?", (qty, avg if qty > 0 else None, position_id))


def _simulate_transaction_ledger(rows, current_price: float | None = None):
    qty = 0.0
    cost = 0.0
    realized_cum = 0.0
    dividends_cum = 0.0
    standalone_fees_cum = 0.0
    cumulative_acquisitions = 0.0
    last_trade_price = None
    points = []
    errors = []
    for r0 in rows:
        r = dict(r0)
        typ = r.get("transaction_type")
        q = float(r.get("quantity") or 0)
        gross = float(r.get("gross_amount_eur") or 0)
        fees = float(r.get("fees_eur") or 0)
        realized = None
        if typ in ("opening", "buy"):
            if q < -1e-9:
                errors.append("Quantité négative")
                break
            qty += q
            acquisition = gross + (fees if typ == "buy" else 0)
            cost += acquisition
            cumulative_acquisitions += acquisition
            if r.get("unit_price_eur") is not None:
                last_trade_price = float(r.get("unit_price_eur") or 0)
        elif typ == "sell":
            if q <= 0:
                errors.append("Quantité de vente invalide")
                break
            if q > qty + 1e-9:
                errors.append(f"Vente de {q:g} alors que {qty:g} titre(s) étaient reconstruits à cette date")
                break
            avg_before = cost / qty if qty > 0 else 0
            realized = gross - fees - q * avg_before
            realized_cum += realized
            qty -= q
            cost -= q * avg_before
            if r.get("unit_price_eur") is not None:
                last_trade_price = float(r.get("unit_price_eur") or 0)
            if qty < 1e-10:
                qty = 0.0
                cost = 0.0
        elif typ == "dividend":
            dividends_cum += gross
        elif typ == "fee":
            standalone_fees_cum += gross + fees
        ref_price = float(last_trade_price or 0)
        value_ref = qty * ref_price
        total_gain = value_ref - cost + realized_cum + dividends_cum - standalone_fees_cum
        perf = (total_gain / cumulative_acquisitions * 100) if cumulative_acquisitions > 1e-12 else None
        points.append({
            "transaction_id": r.get("id"),
            "date": r.get("transaction_date"),
            "type": typ,
            "quantity_after": round(qty, 10),
            "avg_cost_after": round(cost / qty, 8) if qty > 1e-12 else None,
            "cost_basis_after": round(cost, 2),
            "reference_price": round(ref_price, 6) if ref_price else None,
            "position_value_after": round(value_ref, 2),
            "realized_cum": round(realized_cum, 2),
            "dividends_cum": round(dividends_cum, 2),
            "fees_cum": round(standalone_fees_cum, 2),
            "total_gain": round(total_gain, 2),
            "performance_pct": round(perf, 2) if perf is not None else None,
        })
    if current_price is not None and not errors:
        value_now = qty * float(current_price or 0)
        total_gain = value_now - cost + realized_cum + dividends_cum - standalone_fees_cum
        perf = (total_gain / cumulative_acquisitions * 100) if cumulative_acquisitions > 1e-12 else None
        points.append({
            "transaction_id": None,
            "date": date.today().isoformat(),
            "type": "current",
            "quantity_after": round(qty, 10),
            "avg_cost_after": round(cost / qty, 8) if qty > 1e-12 else None,
            "cost_basis_after": round(cost, 2),
            "reference_price": round(float(current_price or 0), 6),
            "position_value_after": round(value_now, 2),
            "realized_cum": round(realized_cum, 2),
            "dividends_cum": round(dividends_cum, 2),
            "fees_cum": round(standalone_fees_cum, 2),
            "total_gain": round(total_gain, 2),
            "performance_pct": round(perf, 2) if perf is not None else None,
        })
    return {"points": points, "errors": errors, "quantity": qty, "cost_basis": cost, "avg_cost": cost / qty if qty > 1e-12 else None}


def _position_ledger_history(conn, position_id: int):
    pos = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not pos:
        raise HTTPException(404, "Position introuvable")
    rows = [dict(r) for r in conn.execute("SELECT * FROM transactions WHERE position_id=? ORDER BY transaction_date,id", (position_id,)).fetchall()]
    current_price = _eur_unit_price(pos)
    simulation = _simulate_transaction_ledger(rows, current_price=current_price)
    no_opening_rows = [r for r in rows if r.get("transaction_type") != "opening"]
    history_only = _simulate_transaction_ledger(no_opening_rows, current_price=None)
    opening = next((r for r in rows if r.get("transaction_type") == "opening"), None)
    current_qty = float(pos["quantity"] or 0)
    # Le solde initial représente la position au début du suivi. Pour le remplacer proprement,
    # on compare donc la quantité reconstituée par les mouvements ANTÉRIEURS à la date de
    # création du solde initial, et non la quantité actuelle (qui inclut déjà ce solde).
    cutoff_date = None
    if opening and opening.get("created_at"):
        try:
            cutoff_date = datetime.fromtimestamp(int(opening.get("created_at"))).date().isoformat()
        except Exception:
            cutoff_date = None
    pre_rows = [r for r in no_opening_rows if (not cutoff_date or str(r.get("transaction_date") or "") < cutoff_date)]
    pre_history = _simulate_transaction_ledger(pre_rows, current_price=None)
    opening_qty = float(opening.get("quantity") or 0) if opening else 0.0
    rebuilt_before_tracking = float(pre_history.get("quantity") or 0)
    qty_gap = opening_qty - rebuilt_before_tracking
    reconciliation = {
        "opening": opening,
        "tracking_start_date": cutoff_date,
        "current_quantity": round(current_qty, 10),
        "opening_quantity": round(opening_qty, 10),
        "history_before_tracking_quantity": round(rebuilt_before_tracking, 10),
        "quantity_gap": round(qty_gap, 10),
        "history_only_quantity": round(float(history_only.get("quantity") or 0), 10),
        "history_only_avg_cost": round(float(history_only.get("avg_cost") or 0), 8) if history_only.get("avg_cost") is not None else None,
        "history_only_errors": pre_history.get("errors") or [],
        "can_replace_opening": bool(opening) and not pre_history.get("errors") and abs(qty_gap) <= 1e-7,
    }
    return pos, rows, simulation, reconciliation


def _global_ledger_history(conn):
    positions = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM positions ORDER BY id").fetchall()}
    rows = [dict(r) for r in conn.execute("SELECT t.*,p.name AS position_name,p.account AS position_account FROM transactions t JOIN positions p ON p.id=t.position_id ORDER BY t.transaction_date,t.id").fetchall()]
    # Les anciennes positions importées peuvent ne pas avoir de ligne dans transactions
    # tant qu'aucun mouvement détaillé n'a été saisi. Pour que la feuille Global
    # représente bien tout le portefeuille, on ajoute alors une ouverture synthétique
    # (sans modifier la base). Elle sera remplacée naturellement dès que l'historique
    # réel de la ligne est saisi et qu'une transaction existe.
    tx_position_ids = {int(r["position_id"]) for r in rows}
    synthetic = []
    for pid, p in positions.items():
        if int(pid) in tx_position_ids:
            continue
        qty = float(p.get("quantity") or 0)
        if qty <= 0:
            continue
        avg = p.get("avg_cost_eur")
        if avg in (None, 0):
            avg = _eur_unit_price(p) or 0
        avg = float(avg or 0)
        synthetic.append({
            "id": -int(pid),
            "position_id": int(pid),
            "transaction_type": "opening",
            "transaction_date": "1900-01-01",
            "quantity": qty,
            "unit_price_eur": avg,
            "gross_amount_eur": qty * avg,
            "fees_eur": 0,
            "realized_pnl_eur": None,
            "origin": "",
            "investment_framework": "",
            "framework_label": "",
            "position_name": p.get("name"),
            "position_account": p.get("account"),
            "synthetic_opening": True,
        })
    rows = sorted(synthetic + rows, key=lambda r: (str(r.get("transaction_date") or ""), int(r.get("id") or 0)))
    states = {pid: {"qty":0.0,"cost":0.0,"last_price":None,"realized":0.0,"dividends":0.0,"fees":0.0,"acq":0.0} for pid in positions}
    points=[]
    for r in rows:
        st=states[r["position_id"]]; typ=r["transaction_type"]; q=float(r.get("quantity") or 0); gross=float(r.get("gross_amount_eur") or 0); fees=float(r.get("fees_eur") or 0)
        if typ in ("opening","buy"):
            st["qty"] += q; add=gross+(fees if typ=="buy" else 0); st["cost"] += add; st["acq"] += add
            if r.get("unit_price_eur") is not None: st["last_price"]=float(r.get("unit_price_eur") or 0)
        elif typ=="sell":
            if q <= st["qty"] + 1e-9 and st["qty"]>0:
                avg=st["cost"]/st["qty"]; st["realized"] += gross-fees-q*avg; st["qty"]-=q; st["cost"]-=q*avg
                if st["qty"]<1e-10: st["qty"]=0; st["cost"]=0
            if r.get("unit_price_eur") is not None: st["last_price"]=float(r.get("unit_price_eur") or 0)
        elif typ=="dividend": st["dividends"] += gross
        elif typ=="fee": st["fees"] += gross+fees
        value=sum(x["qty"]*float(x["last_price"] or 0) for x in states.values())
        cost=sum(x["cost"] for x in states.values()); realized=sum(x["realized"] for x in states.values()); dividends=sum(x["dividends"] for x in states.values()); extra_fees=sum(x["fees"] for x in states.values()); acq=sum(x["acq"] for x in states.values())
        gain=value-cost+realized+dividends-extra_fees; perf=gain/acq*100 if acq>1e-12 else None
        points.append({"date":r["transaction_date"],"position_name":r["position_name"],"account":r["position_account"],"transaction_type":typ,"framework":(r.get("framework_label") if r.get("investment_framework")=="Autre" else r.get("investment_framework")) or r.get("origin") or "","quantity":r.get("quantity"),"unit_price_eur":r.get("unit_price_eur"),"gross_amount_eur":gross,"fees_eur":fees,"portfolio_value_after":round(value,2),"cost_basis_after":round(cost,2),"realized_cum":round(realized,2),"dividends_cum":round(dividends,2),"total_gain":round(gain,2),"performance_pct":round(perf,2) if perf is not None else None})
    # current point with current market prices
    if positions:
        current_value=sum(float(p.get("quantity") or 0)*_eur_unit_price(p) for p in positions.values())
        cost=sum(x["cost"] for x in states.values()); realized=sum(x["realized"] for x in states.values()); dividends=sum(x["dividends"] for x in states.values()); extra_fees=sum(x["fees"] for x in states.values()); acq=sum(x["acq"] for x in states.values())
        gain=current_value-cost+realized+dividends-extra_fees; perf=gain/acq*100 if acq>1e-12 else None
        points.append({"date":date.today().isoformat(),"position_name":"Aujourd’hui","account":"","transaction_type":"current","framework":"Cours actuels","quantity":None,"unit_price_eur":None,"gross_amount_eur":None,"fees_eur":None,"portfolio_value_after":round(current_value,2),"cost_basis_after":round(cost,2),"realized_cum":round(realized,2),"dividends_cum":round(dividends,2),"total_gain":round(gain,2),"performance_pct":round(perf,2) if perf is not None else None})
    return points


def _normalize_trade_values(payload: TransactionCreate) -> tuple[float, float, float]:
    q = float(payload.quantity) if payload.quantity is not None else None
    unit = float(payload.unit_price_eur) if payload.unit_price_eur is not None else None
    amount = float(payload.amount_eur) if payload.amount_eur is not None else None
    if q is not None and q <= 0:
        raise HTTPException(400, "La quantité doit être positive")
    if unit is not None and unit <= 0:
        raise HTTPException(400, "Le prix unitaire doit être positif")
    if amount is not None and amount <= 0:
        raise HTTPException(400, "Le montant doit être positif")
    provided = sum(v is not None for v in (q, unit, amount))
    if provided < 2:
        raise HTTPException(400, "Renseigne au moins deux valeurs parmi quantité, prix unitaire et montant")
    if q is None:
        q = amount / unit
    elif unit is None:
        unit = amount / q
    elif amount is None:
        amount = q * unit
    else:
        expected = q * unit
        if abs(expected - amount) > max(0.02, amount * 0.002):
            raise HTTPException(400, "Quantité × prix unitaire ne correspond pas au montant")
    return float(q), float(unit), float(amount)


@app.get("/")
def index():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/manifest.webmanifest")
def pwa_manifest():
    return FileResponse(ROOT / "static" / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def service_worker():
    response = FileResponse(ROOT / "static" / "sw.js", media_type="application/javascript")
    response.headers["Service-Worker-Allowed"] = "/"
    response.headers["Cache-Control"] = "no-cache"
    return response


@app.get("/api/portfolio")
def portfolio():
    conn = db()
    rows = conn.execute("SELECT * FROM positions ORDER BY position_value DESC").fetchall()
    settings = get_settings(conn)
    conn.close()
    positions = [row_to_dict(r) for r in rows]
    positions.sort(key=lambda x: x["position_value"], reverse=True)
    total = round(sum(p["position_value"] for p in positions), 2)
    invested_items = [p["invested_estimate"] for p in positions if p["invested_estimate"] is not None]
    invested = round(sum(invested_items), 2) if invested_items else 0
    pnl = round(total - invested, 2) if invested else 0
    perf = round((total / invested - 1) * 100, 2) if invested else 0
    conn2 = db()
    for p in positions:
        p["weight_pct"] = round(p["position_value"] / total * 100, 2) if total else 0
        p.update(_transaction_stats(conn2, p["id"]))
    conn2.close()
    target_total = round(sum(float(p.get("target_pct") or 0) for p in positions), 2)
    token = market_token()
    return {
        "total_value": total,
        "invested_estimate": invested,
        "pnl_estimate": pnl,
        "performance_estimate_pct": perf,
        "positions": positions,
        "monthly_plan": float(settings.get("monthly_plan", "0")),
        "monthly_plan_asset": settings.get("monthly_plan_asset", ""),
        "quote_mode": "À la demande · EODHD différé → clôture · Yahoo secours" if settings.get("yahoo_fallback", "1") == "1" else "À la demande · EODHD différé → clôture",
        "auto_refresh_minutes": int(settings.get("auto_refresh_minutes", "120")),
        "eodhd_configured": bool(token.strip()),
        "target_total_pct": target_total,
        "app_version": APP_VERSION,
    }


def _import_sqlite_into_current_db(sqlite_path: Path, replace: bool = False) -> dict:
    src = sqlite3.connect(sqlite_path)
    src.row_factory = sqlite3.Row
    expected = {"positions", "transactions", "effort_monthly_confirmations", "portfolio_snapshots", "settings"}
    found = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    if not {"positions", "settings"}.issubset(found):
        src.close()
        raise ValueError("Ce fichier ne ressemble pas à une base Portfolio Tracker")
    conn = db()
    counts = {}
    try:
        existing = conn.execute("SELECT COUNT(*) AS c FROM positions").fetchone()["c"]
        existing_tx = conn.execute("SELECT COUNT(*) AS c FROM transactions").fetchone()["c"]
        if (existing or existing_tx) and not replace:
            raise ValueError("La base cloud contient déjà des données. Coche le remplacement si tu veux les écraser.")
        if replace:
            for table in ["transactions", "effort_monthly_confirmations", "portfolio_snapshots", "positions", "settings"]:
                conn.execute(f"DELETE FROM {table}")
        for table in ["positions", "transactions", "effort_monthly_confirmations", "portfolio_snapshots", "settings"]:
            if table not in found:
                counts[table] = 0
                continue
            src_cols = [r["name"] for r in src.execute(f"PRAGMA table_info({table})").fetchall()]
            dst_cols = _columns(conn, table)
            copy_cols = [c for c in src_cols if c in dst_cols]
            rows = src.execute(f"SELECT {','.join(copy_cols)} FROM {table}").fetchall()
            if table == "settings":
                rows = [r for r in rows if r["key"] != "eodhd_api_token"]
            if rows:
                sql = f"INSERT INTO {table} ({','.join(copy_cols)}) VALUES ({','.join('?' for _ in copy_cols)})"
                conn.executemany(sql, [tuple(r[c] for c in copy_cols) for r in rows])
            counts[table] = len(rows)
        conn.execute("INSERT INTO settings(key,value) VALUES('eodhd_api_token','') ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        conn.commit()
        reset_postgres_sequences(conn)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        src.close()
        conn.close()
    init_db()
    return counts


@app.post("/api/admin/import-sqlite")
async def import_sqlite_database(request: Request, replace: bool = Query(False)):
    if not CLOUD_MODE:
        raise HTTPException(409, "Cet import est réservé à la version cloud")
    raw = await request.body()
    if not raw or len(raw) > 25 * 1024 * 1024:
        raise HTTPException(400, "Fichier vide ou trop volumineux")
    if not raw.startswith(b"SQLite format 3\x00"):
        raise HTTPException(400, "Le fichier envoyé n'est pas une base SQLite valide")
    import tempfile
    tmp_name = None
    try:
        with tempfile.NamedTemporaryFile(prefix="portfolio-import-", suffix=".db", delete=False) as tmp:
            tmp.write(raw)
            tmp_name = tmp.name
        counts = _import_sqlite_into_current_db(Path(tmp_name), replace=replace)
        return {"ok": True, "counts": counts, "message": "Base locale importée. La clé EODHD n'a pas été copiée."}
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    finally:
        if tmp_name:
            try:
                Path(tmp_name).unlink(missing_ok=True)
            except Exception:
                pass


@app.get("/api/backup/cloud.json")
def export_cloud_backup():
    tables = ["positions", "transactions", "effort_monthly_confirmations", "portfolio_snapshots", "settings"]
    conn = db()
    try:
        payload = {
            "format": "portfolio-tracker-backup-v1",
            "app_version": APP_VERSION,
            "created_at": int(time.time()),
            "backend": backend_name(),
            "tables": {},
        }
        for table in tables:
            rows = [dict(r) for r in conn.execute(f"SELECT * FROM {table}").fetchall()]
            if table == "settings":
                rows = [r for r in rows if r.get("key") != "eodhd_api_token"]
            payload["tables"][table] = rows
    finally:
        conn.close()
    raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    filename = f"portfolio-cloud-backup-{date.today().isoformat()}.json"
    return StreamingResponse(BytesIO(raw), media_type="application/json", headers={"Content-Disposition": f'attachment; filename="{filename}"'})



def _safe_sheet_title(name: str, used: set[str]) -> str:
    base = re.sub(r"[\\/*?:\[\]]", "-", (name or "Titre")).strip()[:31] or "Titre"
    title = base
    n = 2
    while title in used:
        suffix = f" ({n})"
        title = (base[:31-len(suffix)] + suffix)
        n += 1
    used.add(title)
    return title


def _style_history_sheet(ws, headers: list[str], data_start_row: int, data_end_row: int, value_col: int, invested_col: int):
    header_fill = PatternFill("solid", fgColor="EAF3FF")
    for c in ws[1]:
        c.font = Font(bold=True, color="1F2937")
        c.fill = header_fill
        c.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.sheet_view.showGridLines = False
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{max(1,data_end_row)}"
    widths = [13,28,11,15,20,14,14,14,13,17,17,17,17,17,16,16,16]
    for i,w in enumerate(widths[:len(headers)],1): ws.column_dimensions[get_column_letter(i)].width=w
    for row in ws.iter_rows(min_row=2, max_row=max(2,data_end_row)):
        for cell in row:
            if cell.column in {6,7,8,9,10,11,12,13,14,15,16}:
                cell.number_format = '#,##0.00 [$€-fr-FR]'
            if cell.column in {5}:
                cell.number_format = '0.######'
            if cell.column in {17}:
                cell.number_format = '0.00" %"'
    if data_end_row >= data_start_row:
        chart=LineChart(); chart.title="Évolution opération après opération"; chart.style=13; chart.y_axis.title="EUR"; chart.x_axis.title="Opérations"; chart.height=7; chart.width=15
        data=Reference(ws,min_col=value_col,min_row=1,max_row=data_end_row)
        data2=Reference(ws,min_col=invested_col,min_row=1,max_row=data_end_row)
        cats=Reference(ws,min_col=1,min_row=data_start_row,max_row=data_end_row)
        chart.add_data(data,titles_from_data=True); chart.add_data(data2,titles_from_data=True); chart.set_categories(cats); chart.legend.position="b"
        ws.add_chart(chart, f"{get_column_letter(len(headers)+2)}2")


@app.get("/api/export/history.xlsx")
def export_history_excel():
    conn = db()
    try:
        global_points = _global_ledger_history(conn)
        positions = [dict(r) for r in conn.execute("SELECT * FROM positions ORDER BY name,account,id").fetchall()]
        wb = Workbook()
        ws = wb.active
        ws.title = "Global"
        headers = ["Date","Titre","Compte","Opération","Cadre","Quantité","Prix unitaire EUR","Montant EUR","Frais EUR","Valeur portefeuille après op. EUR","Capital investi après op. EUR","Réalisé cumulé EUR","Dividendes cumulés EUR","Gain total reconstitué EUR","Performance reconstituée %"]
        ws.append(headers)
        for pt in global_points:
            ws.append(["Avant suivi" if pt.get("transaction_type")=="opening" and pt.get("date")=="1900-01-01" else pt.get("date"),pt.get("position_name"),pt.get("account"),pt.get("transaction_type"),pt.get("framework"),pt.get("quantity"),pt.get("unit_price_eur"),pt.get("gross_amount_eur"),pt.get("fees_eur"),pt.get("portfolio_value_after"),pt.get("cost_basis_after"),pt.get("realized_cum"),pt.get("dividends_cum"),pt.get("total_gain"),pt.get("performance_pct")])
        _style_history_sheet(ws, headers, 2, ws.max_row, 10, 11)
        note_row = ws.max_row + 2
        ws.cell(note_row, 1, "Note : entre deux opérations, la valorisation historique utilise le dernier prix d’opération connu pour chaque titre. Le dernier point « Aujourd’hui » utilise les cours actuels.")
        ws.cell(note_row, 1).alignment=Alignment(wrap_text=True)
        used={"Global"}
        for p in positions:
            pos, rows, sim, rec = _position_ledger_history(conn, int(p["id"]))
            title=_safe_sheet_title(f'{p["name"]} {p["account"]}', used)
            sh=wb.create_sheet(title)
            h=["Date","Opération","Cadre","Quantité mouvement","Prix unitaire EUR","Montant EUR","Frais EUR","Quantité détenue après","PRU après EUR","Capital investi après EUR","Valeur position après op. EUR","Réalisé cumulé EUR","Dividendes cumulés EUR","Frais cumulés EUR","Gain total reconstitué EUR","Performance reconstituée %"]
            sh.append(h)
            tx_by_id={r.get("id"):r for r in rows}
            for pt in sim.get("points") or []:
                tx=tx_by_id.get(pt.get("transaction_id"),{})
                framework=(tx.get("framework_label") if tx.get("investment_framework")=="Autre" else tx.get("investment_framework")) or tx.get("origin") or ("Cours actuels" if pt.get("type")=="current" else "")
                sh.append(["Aujourd’hui" if pt.get("type")=="current" else pt.get("date"),pt.get("type"),framework,tx.get("quantity"),tx.get("unit_price_eur"),tx.get("gross_amount_eur"),tx.get("fees_eur"),pt.get("quantity_after"),pt.get("avg_cost_after"),pt.get("cost_basis_after"),pt.get("position_value_after"),pt.get("realized_cum"),pt.get("dividends_cum"),pt.get("fees_cum"),pt.get("total_gain"),pt.get("performance_pct")])
            _style_history_sheet(sh,h,2,sh.max_row,11,10)
            r=sh.max_row+2
            sh.cell(r,1,"Réconciliation position initiale"); sh.cell(r,1).font=Font(bold=True)
            sh.cell(r+1,1,"Quantité actuelle"); sh.cell(r+1,2,rec.get("current_quantity"))
            sh.cell(r+2,1,"Quantité reconstruite sans solde initial"); sh.cell(r+2,2,rec.get("history_only_quantity"))
            sh.cell(r+3,1,"Écart restant"); sh.cell(r+3,2,rec.get("quantity_gap"))
            sh.cell(r+5,1,"Note : la valeur historique est reconstituée au dernier prix d’opération connu. Le dernier point utilise le cours actuel."); sh.cell(r+5,1).alignment=Alignment(wrap_text=True)
        output=BytesIO(); wb.save(output); output.seek(0)
        filename=f"portfolio-historique-{date.today().isoformat()}.xlsx"
        return StreamingResponse(output, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition":f'attachment; filename="{filename}"'})
    finally:
        conn.close()


@app.get("/api/export/positions.xlsx")
def export_positions_excel():
    snapshot = portfolio()
    wb = Workbook()
    ws = wb.active
    ws.title = "Positions"

    headers = [
        "Actif", "Type", "Compte", "Quantité", "PRU EUR", "Cours marché", "Devise",
        "Cours EUR", "Valeur EUR", "Poids %", "Cible %", "Performance %", "Variation jour %",
        "Investi estimé EUR", "P/L latent EUR", "P/L réalisé EUR", "Dividendes EUR",
        "Nb transactions", "Source", "Ticker", "ISIN", "Place", "Qualité du cours", "Dernière MAJ"
    ]
    ws.append(headers)

    header_fill = PatternFill("solid", fgColor="E9EEF5")
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(vertical="center", wrap_text=True)

    for p in snapshot["positions"]:
        source = " · ".join(str(x) for x in [p.get("last_quote_provider") or p.get("provider"), p.get("market_symbol"), p.get("isin"), p.get("exchange"), p.get("quote_quality")] if x)
        updated = p.get("price_updated_at")
        updated_text = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(updated)) if updated else ""
        invested = p.get("invested_estimate")
        latent = (p.get("position_value") - invested) if invested is not None else None
        ws.append([
            p.get("name"), p.get("asset_type"), p.get("account"), p.get("quantity"), p.get("avg_cost_eur"),
            p.get("last_native_price") if p.get("last_native_price") is not None else p.get("last_price"), p.get("currency"),
            p.get("last_price_eur"), p.get("position_value"), p.get("weight_pct"), p.get("target_pct"),
            p.get("performance_pct"), p.get("day_change_pct"), invested, latent, p.get("realized_pnl_eur"),
            p.get("dividends_eur"), p.get("transaction_count"), source, p.get("market_symbol"), p.get("isin"),
            p.get("exchange"), p.get("quote_quality"), updated_text
        ])

    total_row = ws.max_row + 1
    ws.cell(total_row, 1, "Total")
    ws.cell(total_row, 1).font = Font(bold=True)
    ws.cell(total_row, 9, f"=SUM(I2:I{total_row-1})")
    ws.cell(total_row, 10, f"=SUM(J2:J{total_row-1})")
    ws.cell(total_row, 11, f"=SUM(K2:K{total_row-1})")
    ws.cell(total_row, 14, f"=SUM(N2:N{total_row-1})")
    ws.cell(total_row, 15, f"=SUM(O2:O{total_row-1})")
    ws.cell(total_row, 16, f"=SUM(P2:P{total_row-1})")
    ws.cell(total_row, 17, f"=SUM(Q2:Q{total_row-1})")
    for c in range(1, len(headers)+1):
        ws.cell(total_row, c).font = Font(bold=True)
        ws.cell(total_row, c).fill = PatternFill("solid", fgColor="F5F6F8")

    currency_cols = [5, 8, 9, 14, 15, 16, 17]
    percent_cols = [10, 11, 12, 13]
    for row in ws.iter_rows(min_row=2, max_row=total_row):
        for col in currency_cols:
            row[col-1].number_format = '#,##0.00 [$€-fr-FR]'
        for col in percent_cols:
            row[col-1].number_format = '0.00" %"'
        row[3].number_format = '0.######'
        row[5].number_format = '0.0000'

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:X{total_row-1}"
    widths = {
        1: 34, 2: 18, 3: 10, 4: 12, 5: 14, 6: 15, 7: 10, 8: 13, 9: 15, 10: 11, 11: 11,
        12: 14, 13: 14, 14: 18, 15: 16, 16: 17, 17: 15, 18: 14, 19: 42, 20: 18, 21: 18, 22: 16, 23: 18, 24: 20
    }
    for idx, width in widths.items():
        ws.column_dimensions[get_column_letter(idx)].width = width

    ws.sheet_view.showGridLines = False
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    filename = f"portfolio-positions-{date.today().isoformat()}.xlsx"
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )


@app.get("/api/settings/market")
def market_settings_get():
    s = get_settings()
    token = market_token()
    return {
        "provider": "eodhd",
        "token_configured": bool(token.strip()),
        "token_hint": ("••••" + token[-4:]) if len(token) >= 4 else ("configurée" if token else ""),
        "yahoo_fallback": s.get("yahoo_fallback", "1") == "1",
        "auto_refresh_minutes": int(s.get("auto_refresh_minutes", "120")),
        "daily_rate_limit": int(s.get("eodhd_daily_limit", "0") or 0),
        "api_requests": int(s.get("eodhd_api_requests", "0") or 0),
        "calls_today": int(s.get("eodhd_calls_today", "0") or 0) if s.get("eodhd_calls_date", "") == date.today().isoformat() else 0,
        "cloud_mode": CLOUD_MODE,
        "token_managed_by_server": bool(os.getenv("EODHD_API_TOKEN", "").strip()),
    }


@app.post("/api/settings/market")
def market_settings_save(payload: MarketSettings):
    if payload.eodhd_api_token is not None:
        if CLOUD_MODE and os.getenv("EODHD_API_TOKEN", "").strip():
            raise HTTPException(409, "La clé EODHD est gérée comme secret serveur dans la version cloud")
        token = payload.eodhd_api_token.strip()
        if token:
            # Validate and cache quota information.
            try:
                user = eodhd_user(token)
                daily_limit = int(float(user.get("dailyRateLimit") or 0))
                api_requests = int(float(user.get("apiRequests") or 0))
                set_setting("eodhd_daily_limit", str(daily_limit))
                set_setting("eodhd_api_requests", str(api_requests))
                # Free plan: avoid automatic refresh storms.
                if daily_limit and daily_limit <= 20:
                    current = int(get_settings().get("auto_refresh_minutes", "120"))
                    if current < 1440:
                        set_setting("auto_refresh_minutes", "1440")
            except Exception as exc:
                raise HTTPException(400, f"Clé EODHD refusée: {exc}")
        set_setting("eodhd_api_token", token)
    if payload.yahoo_fallback is not None:
        set_setting("yahoo_fallback", "1" if payload.yahoo_fallback else "0")
    if payload.auto_refresh_minutes is not None:
        minutes = int(payload.auto_refresh_minutes)
        if not 1 <= minutes <= 1440:
            raise HTTPException(400, "Intervalle d'actualisation invalide")
        set_setting("auto_refresh_minutes", str(minutes))
    return market_settings_get()


@app.patch("/api/positions/{position_id}")
def update_position(position_id: int, payload: PositionUpdate):
    conn = db()
    current = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not current:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    fields = payload.model_dump(exclude_none=True)
    has_ledger = conn.execute("SELECT 1 FROM transactions WHERE position_id=? AND transaction_type!='opening' LIMIT 1", (position_id,)).fetchone() is not None
    if has_ledger and any(k in fields for k in ("quantity", "avg_cost_eur")):
        conn.close()
        raise HTTPException(409, "Quantité et PRU sont gérés par le journal de transactions")
    if fields:
        if "quantity" in fields and fields["quantity"] < 0:
            raise HTTPException(400, "Quantité invalide")
        if "avg_cost_eur" in fields and fields["avg_cost_eur"] is not None and fields["avg_cost_eur"] < 0:
            raise HTTPException(400, "PRU invalide")
        if "target_pct" in fields and not (0 <= fields["target_pct"] <= 100):
            raise HTTPException(400, "Cible invalide")
        cols = ",".join(f"{k}=?" for k in fields)
        vals = list(fields.values()) + [position_id]
        conn.execute(f"UPDATE positions SET {cols} WHERE id=?", vals)
        conn.commit()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    conn.close()
    return row_to_dict(row)


@app.post("/api/positions/{position_id}/manual-price")
def set_manual_price(position_id: int, payload: ManualPriceUpdate):
    if not math.isfinite(payload.price_eur) or payload.price_eur <= 0:
        raise HTTPException(400, "Cours manuel invalide")
    conn = db()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    now = int(time.time())
    conn.execute("UPDATE positions SET manual_price=?,manual_price_at=?,manual_price_note=?,price_mode='manual' WHERE id=?", (float(payload.price_eur), now, payload.note.strip(), position_id))
    conn.commit()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    conn.close()
    _save_snapshot("manual_price")
    return row_to_dict(row)


@app.delete("/api/positions/{position_id}/manual-price")
def clear_manual_price(position_id: int):
    conn = db()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    conn.execute("UPDATE positions SET price_mode='auto',manual_price=NULL,manual_price_at=NULL,manual_price_note='' WHERE id=?", (position_id,))
    conn.commit()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    conn.close()
    return row_to_dict(row)


@app.delete("/api/positions/{position_id}")
def delete_position(position_id: int):
    conn = db()
    row = conn.execute("SELECT id,name FROM positions WHERE id=?", (position_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    conn.execute("DELETE FROM transactions WHERE position_id=?", (position_id,))
    conn.execute("DELETE FROM positions WHERE id=?", (position_id,))
    conn.commit()
    conn.close()
    _save_snapshot("position_delete")
    return {"ok": True, "id": position_id, "name": row["name"]}


@app.post("/api/positions")
def create_position(payload: PositionCreate):
    if payload.quantity < 0:
        raise HTTPException(400, "Quantité invalide")
    conn = db()
    try:
        cur = conn.execute(
            """
            INSERT INTO positions(name,asset_type,account,currency,quantity,last_price,position_value,
                                  performance_pct,market_symbol,target_pct,provider,exchange,isin,
                                  last_native_price,fx_rate_to_eur,price_updated_at,avg_cost_eur,
                                  day_change_pct,quote_quality,quote_note)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                payload.name, payload.asset_type, payload.account, payload.currency,
                payload.quantity, 0, 0, 0, payload.market_symbol, payload.target_pct,
                payload.provider, payload.exchange, payload.isin, None, 1, None,
                payload.avg_cost_eur, None, "", "",
            ),
        )
        conn.commit()
        row = conn.execute("SELECT id FROM positions WHERE name=? AND account=?", (payload.name, payload.account)).fetchone()
        row_id = row["id"] if row else cur.lastrowid
    except Exception as exc:
        conn.rollback()
        conn.close()
        if is_integrity_error(exc):
            raise HTTPException(409, "Une position de ce nom existe déjà dans ce compte")
        raise
    conn.close()
    # Market prices are refreshed only when the user explicitly requests it.
    conn = db()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (row_id,)).fetchone()
    conn.close()
    return row_to_dict(row)


@app.get("/api/transactions")
def list_transactions(position_id: Optional[int] = None, limit: int = Query(200, ge=1, le=1000)):
    conn = db()
    sql = """SELECT t.*,p.name AS position_name FROM transactions t JOIN positions p ON p.id=t.position_id"""
    params: list = []
    if position_id is not None:
        sql += " WHERE t.position_id=?"
        params.append(position_id)
    sql += " ORDER BY CASE WHEN t.transaction_type='opening' THEN 1 ELSE 0 END, t.transaction_date DESC, t.id DESC LIMIT ?"
    params.append(limit)
    rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    conn.close()
    return {"transactions": rows}


@app.post("/api/transactions")
def create_transaction(payload: TransactionCreate):
    framework = payload.investment_framework.strip()
    label = payload.framework_label.strip()
    if framework not in FRAMEWORKS:
        raise HTTPException(400, "Cadre d’investissement obligatoire ou invalide")
    if framework == "Autre" and not label:
        raise HTTPException(400, "Le libellé personnalisé est obligatoire")
    typ = payload.transaction_type.strip().lower()
    if typ not in {"buy", "sell", "dividend", "fee"}:
        raise HTTPException(400, "Type de transaction invalide")
    try:
        date.fromisoformat(payload.transaction_date)
    except Exception:
        raise HTTPException(400, "Date invalide")
    fees = float(payload.fees_eur or 0)
    if fees < 0:
        raise HTTPException(400, "Frais invalides")
    conn = db()
    position = conn.execute("SELECT * FROM positions WHERE id=?", (payload.position_id,)).fetchone()
    if not position:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    if framework == "Plan PEA" and position["account"] != "PEA":
        conn.close()
        raise HTTPException(400, "Le cadre Plan PEA nécessite une position sur le PEA")
    _ensure_opening_transaction(conn, position)
    if typ in {"buy", "sell"}:
        q, unit, amount = _normalize_trade_values(payload)
        if typ == "sell":
            current_qty = float(position["quantity"] or 0)
            if q > current_qty + 1e-9:
                conn.rollback(); conn.close()
                raise HTTPException(400, f"Vente impossible : tu détiens {current_qty:g} part(s)")
        conn.execute(
            """INSERT INTO transactions(position_id,transaction_type,transaction_date,quantity,unit_price_eur,gross_amount_eur,fees_eur,note,origin,investment_framework,framework_label,investment_account)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (payload.position_id, typ, payload.transaction_date, q, unit, amount, fees, payload.note.strip(), label if framework == "Autre" else framework, framework, label if framework == "Autre" else "", position["account"]),
        )
    else:
        amount = float(payload.amount_eur or 0)
        if amount <= 0:
            conn.rollback(); conn.close()
            raise HTTPException(400, "Le montant doit être positif")
        conn.execute(
            """INSERT INTO transactions(position_id,transaction_type,transaction_date,quantity,unit_price_eur,gross_amount_eur,fees_eur,note,origin,investment_framework,framework_label,investment_account)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (payload.position_id, typ, payload.transaction_date, None, None, amount, fees, payload.note.strip(), label if framework == "Autre" else framework, framework, label if framework == "Autre" else "", position["account"]),
        )
    try:
        _rebuild_position_from_transactions(conn, payload.position_id)
    except ValueError as exc:
        conn.rollback(); conn.close()
        raise HTTPException(400, str(exc))
    conn.commit()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (payload.position_id,)).fetchone()
    stats = _transaction_stats(conn, payload.position_id)
    conn.close()
    out = row_to_dict(row)
    out.update(stats)
    _save_snapshot("transaction")
    return out


@app.patch("/api/transactions/{transaction_id}")
def update_transaction(transaction_id: int, payload: TransactionCreate):
    """Correct a ledger entry atomically, replaying the entire affected ledger."""
    typ = payload.transaction_type.strip().lower()
    if typ not in {"buy", "sell", "dividend", "fee"}:
        raise HTTPException(400, "Type de transaction invalide")
    try:
        date.fromisoformat(payload.transaction_date)
    except (ValueError, TypeError):
        raise HTTPException(400, "Date invalide")
    framework = payload.investment_framework.strip()
    label = payload.framework_label.strip()
    if framework not in FRAMEWORKS or (framework == "Autre" and not label):
        raise HTTPException(400, "Cadre d’investissement invalide")
    fees = float(payload.fees_eur or 0)
    if not math.isfinite(fees) or fees < 0:
        raise HTTPException(400, "Frais invalides")
    if typ in {"buy", "sell"}:
        q, unit, amount = _normalize_trade_values(payload)
        if not all(math.isfinite(x) for x in (q, unit, amount)):
            raise HTTPException(400, "Valeurs non finies")
    else:
        amount = float(payload.amount_eur or 0)
        if not math.isfinite(amount) or amount <= 0:
            raise HTTPException(400, "Le montant doit être positif")
        q = unit = None
    conn = db()
    try:
        tx = conn.execute("SELECT * FROM transactions WHERE id=?", (transaction_id,)).fetchone()
        if not tx:
            raise HTTPException(404, "Transaction introuvable")
        if tx["transaction_type"] == "opening":
            raise HTTPException(400, "Utilise l’éditeur de position initiale")
        if payload.position_id != tx["position_id"]:
            raise HTTPException(400, "Le titre d’une transaction ne peut pas être changé")
        position = conn.execute("SELECT * FROM positions WHERE id=?", (payload.position_id,)).fetchone()
        if not position:
            raise HTTPException(404, "Position introuvable")
        if framework == "Plan PEA" and position["account"] != "PEA":
            raise HTTPException(400, "Le cadre Plan PEA nécessite une position PEA")
        conn.execute("""UPDATE transactions SET transaction_type=?,transaction_date=?,quantity=?,unit_price_eur=?,
            gross_amount_eur=?,fees_eur=?,note=?,origin=?,investment_framework=?,framework_label=?,investment_account=?
            WHERE id=?""", (typ,payload.transaction_date,q,unit,amount,fees,payload.note.strip(),
            label if framework == "Autre" else framework,framework,label if framework == "Autre" else "",
            position["account"],transaction_id))
        _rebuild_position_from_transactions(conn, payload.position_id)
        conn.commit()
    except ValueError as exc:
        conn.rollback()
        raise HTTPException(400, str(exc))
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    _save_snapshot("transaction_update")
    return {"ok": True, "id": transaction_id}


@app.delete("/api/transactions/{transaction_id}")
def delete_transaction(transaction_id: int):
    conn = db()
    tx = conn.execute("SELECT * FROM transactions WHERE id=?", (transaction_id,)).fetchone()
    if not tx:
        conn.close(); raise HTTPException(404, "Transaction introuvable")
    if tx["transaction_type"] == "opening":
        conn.close(); raise HTTPException(400, "Le solde initial ne peut pas être supprimé")
    position_id = tx["position_id"]
    conn.execute("DELETE FROM transactions WHERE id=?", (transaction_id,))
    try:
        _rebuild_position_from_transactions(conn, position_id)
    except ValueError as exc:
        conn.rollback(); conn.close(); raise HTTPException(400, str(exc))
    conn.commit(); conn.close()
    _save_snapshot("transaction_delete")
    return {"ok": True}



@app.get("/api/positions/{position_id}/ledger-history")
def position_ledger_history(position_id: int):
    conn = db()
    try:
        pos, rows, simulation, reconciliation = _position_ledger_history(conn, position_id)
        return {
            "position": row_to_dict(pos),
            "transactions": rows,
            "points": simulation.get("points") or [],
            "errors": simulation.get("errors") or [],
            "reconciliation": reconciliation,
            "valuation_note": "Entre deux opérations, la valorisation est reconstituée au dernier prix d’opération connu. Le dernier point utilise le cours actuel.",
        }
    finally:
        conn.close()


@app.patch("/api/positions/{position_id}/opening")
def update_opening(position_id: int, payload: OpeningUpdate):
    if payload.quantity < 0:
        raise HTTPException(400, "La quantité initiale ne peut pas être négative")
    if payload.avg_cost_eur < 0:
        raise HTTPException(400, "Le PRU initial ne peut pas être négatif")
    conn = db()
    pos = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not pos:
        conn.close(); raise HTTPException(404, "Position introuvable")
    opening = conn.execute("SELECT * FROM transactions WHERE position_id=? AND transaction_type='opening' ORDER BY id LIMIT 1", (position_id,)).fetchone()
    if not opening:
        conn.close(); raise HTTPException(404, "Aucune position initiale à modifier")
    amount = float(payload.quantity) * float(payload.avg_cost_eur)
    conn.execute("UPDATE transactions SET quantity=?,unit_price_eur=?,gross_amount_eur=? WHERE id=?", (float(payload.quantity), float(payload.avg_cost_eur), amount, opening["id"]))
    try:
        _rebuild_position_from_transactions(conn, position_id)
    except ValueError as exc:
        conn.rollback(); conn.close(); raise HTTPException(400, str(exc))
    conn.commit(); conn.close()
    _save_snapshot("opening_update")
    return {"ok": True}


@app.delete("/api/positions/{position_id}/opening")
def delete_opening(position_id: int, force: bool = False):
    conn = db()
    pos = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not pos:
        conn.close(); raise HTTPException(404, "Position introuvable")
    opening = conn.execute("SELECT * FROM transactions WHERE position_id=? AND transaction_type='opening' ORDER BY id LIMIT 1", (position_id,)).fetchone()
    if not opening:
        conn.close(); raise HTTPException(404, "Aucune position initiale à supprimer")
    _, _, _, rec = _position_ledger_history(conn, position_id)
    if rec.get("history_only_errors") and not force:
        conn.close(); raise HTTPException(409, {"message": "L’historique saisi ne peut pas être reconstruit sans la position initiale.", "reconciliation": rec})
    if abs(float(rec.get("quantity_gap") or 0)) > 1e-7 and not force:
        conn.close(); raise HTTPException(409, {"message": "L’historique saisi ne reconstitue pas encore la quantité actuelle.", "reconciliation": rec})
    conn.execute("DELETE FROM transactions WHERE id=?", (opening["id"],))
    try:
        _rebuild_position_from_transactions(conn, position_id)
    except ValueError as exc:
        conn.rollback(); conn.close(); raise HTTPException(400, str(exc))
    conn.commit(); conn.close()
    _save_snapshot("opening_delete")
    return {"ok": True}


@app.post("/api/positions/{position_id}/market-link")
def link_market(position_id: int, payload: MarketLink):
    conn = db()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    symbol = payload.market_symbol.strip().upper()
    if not symbol:
        conn.close()
        raise HTTPException(400, "Symbole vide")
    conn.execute(
        """UPDATE positions
           SET market_symbol=?,provider=?,exchange=?,currency=?,isin=?
           WHERE id=?""",
        (symbol, payload.provider, payload.exchange, payload.currency, payload.isin, position_id),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    conn.close()
    # Association only: market data is fetched solely via the explicit refresh action.
    return row_to_dict(row)


class QuoteQuotaError(ValueError):
    pass


def _quote_job_stat(key):
    if getattr(QUOTE_CONTEXT,"active",False):
        with QUOTE_JOB_LOCK:
            QUOTE_JOB[key]=QUOTE_JOB.get(key,0)+1


def http_json(url: str, timeout: int = 12):
    is_eod="eodhd.com/" in url
    if is_eod:
        if getattr(QUOTE_CONTEXT,"active",False) and getattr(QUOTE_CONTEXT,"quota_exhausted",False):
            raise QuoteQuotaError("Quota fournisseur atteint ; aucune nouvelle requête envoyée")
        _track_eodhd_call()
        _quote_job_stat("eodhd_requests")
    _quote_job_stat("api_requests")
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as res:
            raw = res.read().decode("utf-8")
            _quote_job_stat("api_responses")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        _quote_job_stat("api_responses")
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        if is_eod and (exc.code in {402,429} or (exc.code==403 and any(k in body.lower() for k in ["quota","limit","exceeded"]))):
            QUOTE_CONTEXT.quota_exhausted=True
            raise QuoteQuotaError(f"Quota fournisseur atteint (HTTP {exc.code})") from exc
        msg = body.strip()[:300] or exc.reason
        raise ValueError(f"HTTP {exc.code}: {msg}") from exc
    except Exception as exc:
        if not isinstance(exc,(ValueError,json.JSONDecodeError)):
            _quote_job_stat("api_network_errors")
        raise ValueError(f"Source de marché indisponible: {exc}") from exc


def eodhd_token() -> str:
    token = market_token()
    if not token:
        raise ValueError("Ajoute d'abord ta clé EODHD dans Réglages marché")
    return token


def eodhd_user(token: Optional[str] = None) -> dict:
    token = token or eodhd_token()
    params = urllib.parse.urlencode({"api_token": token, "fmt": "json"})
    payload = http_json(f"https://eodhd.com/api/user?{params}")
    if isinstance(payload, dict) and (payload.get("error") or payload.get("message") == "Unauthenticated"):
        raise ValueError(payload.get("error") or payload.get("message"))
    return payload if isinstance(payload, dict) else {"ok": True}


def eodhd_search(query: str, limit: int = 20) -> list[dict]:
    token = eodhd_token()
    encoded = urllib.parse.quote(query.strip())
    params = urllib.parse.urlencode({"api_token": token, "fmt": "json", "limit": limit, "type": "all"})
    payload = http_json(f"https://eodhd.com/api/search/{encoded}?{params}")
    if not isinstance(payload, list):
        raise ValueError("Réponse de recherche EODHD inattendue")
    out = []
    for item in payload:
        code = (item.get("Code") or item.get("code") or "").strip()
        exchange = (item.get("Exchange") or item.get("exchange") or "").strip()
        if not code or not exchange:
            continue
        symbol = f"{code}.{exchange}".upper()
        out.append({
            "symbol": symbol,
            "code": code,
            "name": item.get("Name") or item.get("name") or symbol,
            "exchange": exchange,
            "type": item.get("Type") or item.get("type") or "",
            "currency": item.get("Currency") or item.get("currency") or "EUR",
            "isin": item.get("ISIN") or item.get("Isin") or item.get("isin") or "",
            "country": item.get("Country") or item.get("country") or "",
            "is_primary": bool(item.get("isPrimary")),
            "previous_close": item.get("previousClose"),
            "previous_close_date": item.get("previousCloseDate") or "",
        })
    return out


def quote_is_old(quote: dict, today=None) -> bool:
    # Conservative weekday heuristic, not an exchange holiday calendar.
    today=today or datetime.now(timezone.utc).date()
    previous=today-timedelta(days=1)
    while previous.weekday()>=5:
        previous-=timedelta(days=1)
    stamp=quote.get("timestamp")
    if not stamp:
        return True
    return datetime.fromtimestamp(float(stamp),timezone.utc).date()<previous


def market_timestamp(value):
    try:
        stamp=int(value)
        if stamp<=0 or stamp>time.time()+300:
            raise ValueError()
        return stamp
    except (TypeError,ValueError,OverflowError):
        raise ValueError("Horodatage du cours absent ou invalide")


def eodhd_live_quote(symbol: str) -> dict:
    token = eodhd_token()
    encoded = urllib.parse.quote(symbol.upper(), safe=".-^=")
    params = urllib.parse.urlencode({"api_token": token, "fmt": "json"})
    payload = http_json(f"https://eodhd.com/api/real-time/{encoded}?{params}")
    if not isinstance(payload, dict):
        raise ValueError("Réponse live EODHD inattendue")
    price = payload.get("close")
    if price in (None, 0, "0"):
        raise ValueError(f"Cours live indisponible pour {symbol}")
    prev = payload.get("previousClose")
    change_p = payload.get("change_p")
    if change_p is None and prev not in (None, 0):
        change_p = ((float(price) / float(prev)) - 1) * 100
    return {
        "price": float(price),
        "timestamp": market_timestamp(payload.get("timestamp")),
        "day_change_pct": float(change_p) if change_p is not None else None,
        "quality": "live/différé",
        "note": "EODHD Live (Delayed)",
    }


def eodhd_eod_quote(symbol: str) -> dict:
    token = eodhd_token()
    encoded = urllib.parse.quote(symbol.upper(), safe=".-^=")
    start = (date.today() - timedelta(days=10)).isoformat()
    params = urllib.parse.urlencode({
        "api_token": token,
        "fmt": "json",
        "order": "d",
        "from": start,
        "to": date.today().isoformat(),
    })
    payload = http_json(f"https://eodhd.com/api/eod/{encoded}?{params}")
    if not isinstance(payload, list) or not payload:
        raise ValueError(f"Cours de clôture indisponible pour {symbol}")
    payload=sorted(payload,key=lambda row:row.get("date") or "",reverse=True)
    last = payload[0]
    price = last.get("adjusted_close") or last.get("close")
    if price is None:
        raise ValueError(f"Cours de clôture indisponible pour {symbol}")
    prev = payload[1].get("adjusted_close") or payload[1].get("close") if len(payload) > 1 else None
    change_p = ((float(price) / float(prev)) - 1) * 100 if prev not in (None, 0) else None
    session_date = str(last.get("date") or "")
    # The EOD endpoint supplies a session date but no exact market timestamp.
    # Store midnight UTC for ordering while the UI labels it explicitly as a session date.
    try:
        ts = int(datetime.strptime(session_date, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())
    except (TypeError,ValueError):
        raise ValueError("Date de séance EOD absente ou invalide")
    return {
        "price": float(price),
        "timestamp": ts,
        "day_change_pct": change_p,
        "quality": "clôture EOD",
        "note": f"EODHD clôture · séance du {session_date}" if session_date else "EODHD clôture",
    }


def eodhd_quote(symbol: str) -> dict:
    live=None; live_error=""
    try:
        live=eodhd_live_quote(symbol)
        live["quality"]="différé · date fournisseur"
        live["note"]="EODHD Live/Delayed"
        if not quote_is_old(live):
            return live
    except QuoteQuotaError:
        raise
    except Exception as exc:
        live_error=str(exc)
    try:
        eod=eodhd_eod_quote(symbol)
        if live is None or eod["timestamp"]>live["timestamp"]:
            eod["note"]+=" · secours après cours différé ancien ou indisponible"
            return eod
    except QuoteQuotaError:
        raise
    except Exception as eod_exc:
        if live is None:
            raise ValueError(f"EODHD: différé indisponible ({live_error}); clôture indisponible ({eod_exc})") from eod_exc
        live["note"]+=" · clôture de secours indisponible"
    live["note"]+=" · aucun cours plus récent obtenu"
    return live


# Yahoo remains an optional fallback for symbols already configured in earlier versions.
def yahoo_chart(symbol: str) -> dict:
    encoded = urllib.parse.quote(symbol.strip().upper(), safe="=.-^")
    last_exc = None
    for host in ("query1.finance.yahoo.com", "query2.finance.yahoo.com"):
        try:
            payload = http_json(f"https://{host}/v8/finance/chart/{encoded}?interval=1m&range=1d&includePrePost=false")
            result = (payload.get("chart", {}).get("result") or [])
            if result:
                return result[0]
            err = payload.get("chart", {}).get("error") or {}
            last_exc = ValueError(err.get("description") or f"Aucun cours pour {symbol}")
        except Exception as exc:
            last_exc = exc
    raise ValueError(str(last_exc) if last_exc else f"Aucun cours pour {symbol}")


def yahoo_quote(symbol: str) -> dict:
    result = yahoo_chart(symbol)
    meta = result.get("meta") or {}
    price = meta.get("regularMarketPrice")
    if price is None:
        closes = (((result.get("indicators") or {}).get("quote") or [{}])[0].get("close") or [])
        closes = [x for x in closes if x is not None]
        price = closes[-1] if closes else None
    if price is None:
        raise ValueError(f"Cours Yahoo indisponible pour {symbol}")
    prev = meta.get("chartPreviousClose") or meta.get("previousClose")
    return {
        "price": float(price),
        "currency": meta.get("currency") or "EUR",
        "exchange": meta.get("exchangeName") or meta.get("fullExchangeName") or "",
        "timestamp": market_timestamp(meta.get("regularMarketTime")),
        "day_change_pct": ((float(price) / float(prev)) - 1) * 100 if prev not in (None, 0) else None,
        "quality": "Yahoo secours",
        "note": "Yahoo Finance non officiel",
    }


def fetch_fx_to_eur(currency: str) -> tuple[float, str]:
    cur = (currency or "EUR").upper()
    if cur == "EUR":
        return 1.0, "EUR"
    now = int(time.time())
    cached = FX_CACHE.get(cur)
    if cached and now - cached[2] < 6 * 3600:
        return cached[0], cached[1] + " (cache)"
    multiplier = 1.0
    if cur in {"GBX", "GBP."}:
        multiplier = 0.01
        cur = "GBP"
    pair = f"{cur}EUR.FOREX"
    try:
        q = eodhd_quote(pair)
        result = (float(q["price"]) * multiplier, q["quality"])
        FX_CACHE[cur] = (result[0], result[1], now)
        return result
    except QuoteQuotaError:
        raise
    except Exception as eod_exc:
        if get_settings().get("yahoo_fallback", "1") != "1":
            raise ValueError(f"Taux {cur}/EUR indisponible: {eod_exc}")
        try:
            result = yahoo_chart(f"{cur}EUR=X")
            rate = (result.get("meta") or {}).get("regularMarketPrice")
            if rate is None:
                raise ValueError("cours FX absent")
            result = (float(rate) * multiplier, "Yahoo secours")
            FX_CACHE[cur] = (result[0], result[1], now)
            return result
        except Exception as yahoo_exc:
            raise ValueError(f"Taux {cur}/EUR indisponible (EODHD: {eod_exc}; Yahoo: {yahoo_exc})") from yahoo_exc


def quote_for_row(row: sqlite3.Row) -> dict:
    provider = (row["provider"] or "eodhd").lower()
    symbol = (row["market_symbol"] or "").strip().upper()
    if not symbol:
        raise ValueError("Instrument de marché non configuré")
    if provider == "yahoo":
        q = yahoo_quote(symbol)
        currency = q.get("currency") or row["currency"] or "EUR"
        exchange = q.get("exchange") or row["exchange"] or ""
        return {**q, "currency": currency, "exchange": exchange, "provider": "yahoo"}
    try:
        q = eodhd_quote(symbol)
        return {
            **q,
            "currency": row["currency"] or "EUR",
            "exchange": row["exchange"] or (symbol.split(".")[-1] if "." in symbol else ""),
            "provider": "eodhd",
        }
    except QuoteQuotaError:
        raise
    except Exception as eod_exc:
        if get_settings().get("yahoo_fallback", "1") == "1" and provider != "eodhd-only":
            # Only works when the existing symbol is also understood by Yahoo.
            try:
                y = yahoo_quote(symbol)
                return {**y, "provider": "yahoo", "quality": "Yahoo secours", "note": f"EODHD échec: {eod_exc}"}
            except Exception:
                pass
        raise


@app.get("/api/market/search")
def market_search(q: str = Query(min_length=1, max_length=120)):
    try:
        return {"provider": "eodhd", "results": eodhd_search(q)}
    except Exception as exc:
        raise HTTPException(502, str(exc))


@app.get("/api/market/preview")
def market_preview(
    symbol: str = Query(min_length=1, max_length=50),
    currency: str = Query(default="EUR", min_length=3, max_length=5),
):
    try:
        quote = eodhd_quote(symbol)
        fx, fx_quality = fetch_fx_to_eur(currency)
        return {
            **quote,
            "currency": currency.upper(),
            "fx_rate_to_eur": fx,
            "fx_quality": fx_quality,
            "price_eur": quote["price"] * fx,
            "exchange": symbol.split(".")[-1] if "." in symbol else "",
        }
    except Exception as exc:
        raise HTTPException(502, str(exc))


def refresh_position(position_id: int, quote_cache=None) -> dict:
    conn = db()
    row = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(404, "Position introuvable")
    try:
        key=(row["provider"],row["market_symbol"],row["currency"],row["exchange"])
        if quote_cache is not None and key in quote_cache:
            quote=quote_cache[key]
            if isinstance(quote,Exception):
                raise quote
        else:
            try:
                quote = quote_for_row(row)
            except Exception as exc:
                if quote_cache is not None:
                    quote_cache[key]=exc
                raise
            if quote_cache is not None:
                quote_cache[key]=quote
        market_timestamp(quote.get("timestamp"))
        if row["last_quote_provider"] and row["price_updated_at"] and quote["timestamp"]<row["price_updated_at"]:
            raise ValueError("La source a renvoyé un cours plus ancien que celui conservé ; cours existant inchangé")
        currency = quote.get("currency") or row["currency"] or "EUR"
        fx_key=("fx",currency)
        if quote_cache is not None and fx_key in quote_cache:
            fx_result=quote_cache[fx_key]
            if isinstance(fx_result,Exception):raise fx_result
            fx,fx_quality=fx_result
        else:
            try:
                fx,fx_quality=fetch_fx_to_eur(currency)
                if quote_cache is not None:quote_cache[fx_key]=(fx,fx_quality)
            except Exception as exc:
                if quote_cache is not None:quote_cache[fx_key]=exc
                raise
        price_eur = float(quote["price"]) * fx
        note = quote.get("note") or ""
        if fx_quality not in {"EUR", quote.get("quality")} and currency.upper() != "EUR":
            note = (note + f" · FX {fx_quality}").strip(" ·")
        conn.execute(
            """
            UPDATE positions
            SET currency=?, exchange=?, last_native_price=?, fx_rate_to_eur=?, last_price=?,
                position_value=?, price_updated_at=?, day_change_pct=?, last_quote_provider=?,
                quote_quality=?, quote_note=?, quote_checked_at=?
            WHERE id=?
            """,
            (
                currency, quote.get("exchange", row["exchange"]), quote["price"], fx, price_eur,
                price_eur * float(row["quantity"]), quote.get("timestamp") or int(time.time()),
                quote.get("day_change_pct"), quote.get("provider", row["provider"]),
                quote.get("quality", ""), note, int(time.time()), position_id,
            ),
        )
        # A manual price is a temporary fallback by default.
        # Once a valid automatic quote is obtained, switch the position back to automatic mode.
        # If the automatic refresh fails, the manual price remains active because this block is never reached.
        if row["price_mode"] == "manual":
            conn.execute("UPDATE positions SET price_mode='auto' WHERE id=?", (position_id,))
        conn.commit()
        updated = conn.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
        conn.close()
        return row_to_dict(updated)
    except Exception:
        conn.close()
        raise


QUOTE_JOB_LOCK=threading.RLock()
QUOTE_CONTEXT=threading.local()
QUOTE_JOB={}


class QuoteRefreshRequest(BaseModel):
    position_id: Optional[int] = None
    retry_only: bool = False


def _persist_quote_job():
    UPDATES_DIR.mkdir(parents=True,exist_ok=True)
    path=UPDATES_DIR/"quote_refresh_state.json"
    temp=path.with_suffix(".tmp")
    temp.write_text(json.dumps(QUOTE_JOB,ensure_ascii=False),encoding="utf-8")
    temp.replace(path)


def _load_quote_job():
    global QUOTE_JOB
    if not QUOTE_JOB:
        path=UPDATES_DIR/"quote_refresh_state.json"
        if path.exists():
            try:
                QUOTE_JOB=json.loads(path.read_text(encoding="utf-8"))
                if QUOTE_JOB.get("status")=="running":
                    QUOTE_JOB["status"]="interrupted"
                    for item in QUOTE_JOB.get("results",[]):
                        if item["status"] in {"pending","running"}:item["status"]="not_attempted"
                    _persist_quote_job()
            except (OSError,ValueError):
                QUOTE_JOB={}


def _quote_job_view():
    with QUOTE_JOB_LOCK:
        _load_quote_job()
        return json.loads(json.dumps(QUOTE_JOB))


def _safe_quote_error(exc):
    value=str(exc)
    token=market_token()
    if token:value=value.replace(token,"[clé masquée]")
    return re.sub(r"api_token=[^&\s]+","api_token=[masqué]",value)[:500]


def _run_quote_job():
    QUOTE_CONTEXT.active=True;QUOTE_CONTEXT.quota_exhausted=False
    cache={}
    try:
        with QUOTE_JOB_LOCK:
            ids=[x["id"] for x in QUOTE_JOB["results"] if x["status"]=="pending"]
        for pid in ids:
            with QUOTE_JOB_LOCK:
                item=next(x for x in QUOTE_JOB["results"] if x["id"]==pid)
                item["status"]="running";QUOTE_JOB["current_name"]=item["name"]
            conn=db()
            conn.execute("UPDATE positions SET quote_attempted_at=?,quote_refresh_error='' WHERE id=?",(int(time.time()),pid));conn.commit();conn.close()
            try:
                p=refresh_position(pid,cache)
                status="old" if p.get("quote_stale") else "recent"
                result={"status":status,"timestamp":p.get("price_updated_at"),"checked_at":p.get("quote_checked_at"),"quality":p.get("quote_quality"),"note":p.get("quote_note"),"price_eur":p.get("last_price_eur")}
            except Exception as exc:
                message=_safe_quote_error(exc)
                result={"status":"error","error":message}
                conn=db();conn.execute("UPDATE positions SET quote_refresh_error=? WHERE id=?",(message,pid));conn.commit();conn.close()
            with QUOTE_JOB_LOCK:
                item.update(result);QUOTE_JOB["processed"]+=1
                _persist_quote_job()
            if getattr(QUOTE_CONTEXT,"quota_exhausted",False):
                with QUOTE_JOB_LOCK:
                    QUOTE_JOB["quota_exhausted"]=True
                    for pending in QUOTE_JOB["results"]:
                        if pending["status"]=="pending":pending.update(status="not_attempted",error="Quota atteint : requête non envoyée")
                break
        with QUOTE_JOB_LOCK:
            QUOTE_JOB["status"]="completed";QUOTE_JOB["current_name"]="";QUOTE_JOB["finished_at"]=int(time.time())
            _persist_quote_job()
        if any(x["status"] in {"recent","old"} for x in QUOTE_JOB["results"]):_save_snapshot("quote_refresh")
    except Exception as exc:
        with QUOTE_JOB_LOCK:
            QUOTE_JOB["status"]="interrupted";QUOTE_JOB["error"]=_safe_quote_error(exc)
            for item in QUOTE_JOB.get("results",[]):
                if item["status"] in {"pending","running"}:item["status"]="not_attempted"
            _persist_quote_job()
    finally:
        QUOTE_CONTEXT.active=False


def _start_quote_job(payload,background=True,stale_only=False):
    global QUOTE_JOB
    with QUOTE_JOB_LOCK:
        _load_quote_job()
        if QUOTE_JOB.get("status")=="running":
            return _quote_job_view()  # Join the existing run; never launch a second one.
        conn=db();rows=[dict(r) for r in conn.execute("SELECT * FROM positions WHERE TRIM(market_symbol)<>'' ORDER BY id")];conn.close()
        if payload.position_id is not None:
            rows=[r for r in rows if r["id"]==payload.position_id]
            if not rows:raise HTTPException(400,"Position introuvable ou sans instrument associé")
        previous_pending={r["id"] for r in QUOTE_JOB.get("results",[]) if r["status"] in {"error","old","not_attempted"}}
        if payload.retry_only:
            rows=[r for r in rows if r["id"] in previous_pending or r.get("quote_refresh_error") or not r.get("price_updated_at") or quote_is_old({"timestamp":r.get("price_updated_at")})]
        if stale_only:
            interval=max(1,int(get_settings().get("auto_refresh_minutes","120")))*60
            rows=[r for r in rows if not r.get("price_updated_at") or r["price_updated_at"]<time.time()-interval]
        # The cooldown applies across accounts for the same symbol, including failed attempts.
        conn=db();attempts=[dict(r) for r in conn.execute("SELECT provider,market_symbol,quote_attempted_at FROM positions")];conn.close()
        latest={}
        for r in attempts:
            key=(r["provider"],r["market_symbol"])
            latest[key]=max(latest.get(key,0),r.get("quote_attempted_at") or 0)
        now=int(time.time());results=[]
        for row in rows:
            cooldown=max(0,latest.get((row["provider"],row["market_symbol"]),0)+60-now)
            results.append({"id":row["id"],"name":row["name"],"symbol":row["market_symbol"],"status":"skipped" if cooldown else "pending","retry_after":cooldown})
        QUOTE_JOB={"id":str(time.time_ns()),"status":"running","started_at":now,"total":len(results),"processed":0,"api_requests":0,"api_responses":0,"api_network_errors":0,"eodhd_requests":0,"results":results,"current_name":""}
        _persist_quote_job()
        if background:
            threading.Thread(target=_run_quote_job,daemon=True).start()
            return _quote_job_view()
    _run_quote_job()
    return _quote_job_view()


@app.post("/api/quotes/jobs")
def start_quote_refresh(payload: QuoteRefreshRequest):
    return _start_quote_job(payload)


@app.get("/api/quotes/jobs/current")
def current_quote_refresh():
    return _quote_job_view()


@app.post("/api/quotes/refresh")
def refresh_quotes(stale_only: bool = False):
    result=_start_quote_job(QuoteRefreshRequest(),background=False,stale_only=stale_only)
    if result.get("status")=="running":raise HTTPException(409,"Une actualisation est déjà en cours")
    updated=[r for r in result["results"] if r["status"] in {"recent","old"}]
    errors=[r for r in result["results"] if r["status"] in {"error","not_attempted"}]
    return {"updated":updated,"errors":errors,"summary":{"stale":sum(r["status"]=="old" for r in updated)},"job":result}


@app.post("/api/effort/monthly-confirmations")
def confirm_effort_month(payload: EffortMonthlyConfirmation):
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", payload.month):
        raise HTTPException(400, "Mois invalide")
    if payload.month > date.today().strftime("%Y-%m"):
        raise HTTPException(400, "Un investissement futur ne peut pas être confirmé")
    if not math.isfinite(payload.amount_eur) or payload.amount_eur < 0:
        raise HTTPException(400, "Montant invalide")
    conn=db()
    try:
        p=conn.execute("SELECT account FROM positions WHERE id=?", (payload.position_id,)).fetchone()
        if not p or p["account"]!="PEA":
            raise HTTPException(400, "Sélectionne une position du PEA")
        if payload.amount_eur==0:
            conn.execute("DELETE FROM effort_monthly_confirmations WHERE position_id=? AND month=?",(payload.position_id,payload.month))
        else:
            conn.execute("INSERT INTO effort_monthly_confirmations(position_id,month,amount_eur) VALUES(?,?,?) ON CONFLICT(position_id,month) DO UPDATE SET amount_eur=excluded.amount_eur",(payload.position_id,payload.month,round(payload.amount_eur,2)))
        conn.commit()
    finally:
        conn.close()
    return {"ok":True}


@app.get("/api/settings/goals")
def goal_settings_get():
    s = get_settings()
    return {
        "monthly_target": float(s.get("effort_monthly_target", s.get("monthly_plan", "0")) or 0),
        "annual_goal": float(s.get("annual_investment_goal", "0") or 0),
        "ytd_catchup": float(s.get("effort_ytd_catchup", "0") or 0) if int(s.get("effort_catchup_year", "0") or 0) == date.today().year else 0.0,
        "tr_reference_value": float(s.get("tr_reference_value", "0") or 0),
    }


@app.post("/api/settings/goals")
def goal_settings_save(payload: GoalSettings):
    if payload.monthly_target is not None:
        if payload.monthly_target < 0: raise HTTPException(400, "Objectif mensuel invalide")
        set_setting("effort_monthly_target", str(float(payload.monthly_target)))
    if payload.annual_goal is not None:
        if payload.annual_goal < 0: raise HTTPException(400, "Objectif annuel invalide")
        set_setting("annual_investment_goal", str(float(payload.annual_goal)))
    if payload.ytd_catchup is not None:
        if payload.ytd_catchup < 0: raise HTTPException(400, "Rattrapage annuel invalide")
        set_setting("effort_ytd_catchup", str(float(payload.ytd_catchup)))
        set_setting("effort_catchup_year", str(date.today().year))
    if payload.tr_reference_value is not None:
        if payload.tr_reference_value < 0: raise HTTPException(400, "Valeur Trade Republic invalide")
        set_setting("tr_reference_value", str(float(payload.tr_reference_value)))
    return goal_settings_get()


def _risk_category(p: dict) -> str:
    n=(p.get("name") or "").lower(); t=(p.get("asset_type") or "").lower()
    if "gold" in n or "or physique" in n: return "Or"
    if "commodity" in n or "commodit" in n or "matière" in n: return "Matières premières"
    if t == "action" or "action" == t.strip(): return "Actions individuelles"
    if "sector" in t or "thématique" in t or "themat" in t: return "Sectoriel / thématique"
    if "small" in t or "small" in n or "russell 2000" in n: return "Small caps"
    if any(x in n for x in ["world", "all country", "global", "s&p 500"]): return "ETF larges"
    return "Autres"


def _rebalance_suggestions(snapshot: dict, amount: float) -> dict:
    total=float(snapshot.get("total_value") or 0); amount=max(0.0,float(amount or 0))
    future_total=total+amount
    gaps=[]
    for p in snapshot.get("positions",[]):
        target=float(p.get("target_pct") or 0)
        ideal=future_total*target/100
        gap=max(0.0, ideal-float(p.get("position_value") or 0))
        if target>0 and gap>0:
            gaps.append((p,gap))
    total_gap=sum(g for _,g in gaps)
    suggestions=[]
    if amount>0 and total_gap>0:
        for p,g in sorted(gaps,key=lambda x:x[1],reverse=True):
            alloc=min(g, amount*(g/total_gap))
            if alloc>=0.5:
                suggestions.append({"id":p["id"],"name":p["name"],"amount":round(alloc,2),"target_pct":p.get("target_pct",0),"weight_pct":p.get("weight_pct",0)})
        allocated=sum(x["amount"] for x in suggestions)
        if suggestions and abs(allocated-amount)>0.01:
            suggestions[0]["amount"]=round(suggestions[0]["amount"]+(amount-allocated),2)
    return {"amount":amount,"suggestions":suggestions,"target_total_pct":snapshot.get("target_total_pct",0)}


@app.get("/api/analytics")
def analytics(year: Optional[int] = None, rebalance_amount: Optional[float] = None):
    snap=portfolio(); today=date.today(); year=year or today.year
    settings=get_settings(); monthly_target=float(settings.get("effort_monthly_target", settings.get("monthly_plan", "0")) or 0)
    annual_goal=float(settings.get("annual_investment_goal", monthly_target*12) or 0)
    tr_ref=float(settings.get("tr_reference_value", "0") or 0)
    conn=db()
    period_start, period_end = effort_period(today)
    tx=[dict(r) for r in conn.execute("SELECT t.*,p.account FROM transactions t JOIN positions p ON p.id=t.position_id WHERE t.transaction_date>=? AND t.transaction_date<? AND t.transaction_date<=? AND t.transaction_type!='opening' ORDER BY t.transaction_date,t.id", (period_start.isoformat(),period_end.isoformat(),today.isoformat())).fetchall()]
    pea_journal_by_month={}; monthly=[0.0]*12; extra_monthly=[0.0]*12; other_monthly=[0.0]*12; origins={}; dividends=0.0; realized=0.0
    for t in tx:
        typ=t["transaction_type"]; month=(int(t["transaction_date"][5:7])-10)%12
        if typ=="buy":
            amt=float(t["gross_amount_eur"] or 0)
            framework=t["investment_framework"]
            account=t["investment_account"] or t["account"]
            if framework=="Plan PEA" and account=="PEA":
                monthly[month]+=amt
                key=(t["position_id"],t["transaction_date"][:7])
                pea_journal_by_month[key]=pea_journal_by_month.get(key,0)+amt
            elif framework!="Plan PEA":
                if account=="CTO": extra_monthly[month]+=amt
                else: other_monthly[month]+=amt
            origin=t["framework_label"] if framework=="Autre" else framework
            origins[origin]=origins.get(origin,0)+amt
        elif typ=="dividend": dividends+=float(t["gross_amount_eur"] or 0)
        realized+=float(t.get("realized_pnl_eur") or 0)
    elapsed=(today.year-period_start.year)*12+today.month-period_start.month+1
    journal_actual=sum(monthly)
    confirmations=[dict(r) for r in conn.execute("SELECT c.*,p.name AS position_name,p.account FROM effort_monthly_confirmations c JOIN positions p ON p.id=c.position_id WHERE c.month>=? AND c.month<=? ORDER BY c.month,c.position_id",(period_start.strftime("%Y-%m"),today.strftime("%Y-%m"))).fetchall()]
    confirmed_extra=0.0
    for entry in confirmations:
        known=pea_journal_by_month.get((entry["position_id"],entry["month"]),0)
        entry["journal_amount"]=round(known,2)
        entry["added_to_effort"]=round(max(0,entry["amount_eur"]-known),2) if entry["account"]=="PEA" else 0.0
        monthly[(int(entry["month"][5:7])-10)%12]+=entry["added_to_effort"]
        confirmed_extra+=entry["added_to_effort"]
    if confirmed_extra:
        origins["Plan PEA — complément confirmé"]=round(confirmed_extra,2)
    catchup=0.0; actual=sum(monthly)
    expected_ytd=monthly_target*elapsed
    extra_gross=sum(extra_monthly)
    remaining=max(0,annual_goal-actual)
    pace=actual/elapsed*12
    delta=round(actual-expected_ytd,2)
    if delta < -0.01:
        encouragement=f"Plan PEA en retard : {abs(delta):.2f} € à rattraper pour revenir au rythme prévu."
    elif delta > 0.01:
        encouragement=f"Bravo, ton plan PEA est en avance de {delta:.2f} € sur le rythme prévu !"
    else:
        encouragement="Ton plan PEA est à jour : tu es dans le rythme prévu !"
    if extra_gross>0:
        encouragement+=f" Tu as aussi investi {extra_gross:.2f} € supplémentaires sur ton CTO."
    month_names=["Octobre","Novembre","Décembre","Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre"]
    period_labels=[f"{name} {period_start.year if i<3 else period_end.year}" for i,name in enumerate(month_names)]
    # Performance retains its calendar-year meaning from v4.1.
    perf_rows=conn.execute("SELECT transaction_type,gross_amount_eur,realized_pnl_eur FROM transactions WHERE substr(transaction_date,1,4)=? AND transaction_type!='opening'", (str(year),)).fetchall()
    dividends=sum(float(t["gross_amount_eur"] or 0) for t in perf_rows if t["transaction_type"]=="dividend")
    realized=sum(float(t["realized_pnl_eur"] or 0) for t in perf_rows)
    # XIRR approximatif : solde initial positionné au premier mouvement réel connu.
    alltx=[dict(r) for r in conn.execute("SELECT * FROM transactions ORDER BY transaction_date,id").fetchall()]
    real_dates=[date.fromisoformat(t["transaction_date"]) for t in alltx if t["transaction_type"]!="opening" and t["transaction_date"]!="1900-01-01"]
    start=min(real_dates) if real_dates else today
    flows=[]
    for t in alltx:
        typ=t["transaction_type"]
        d=start if typ=="opening" or t["transaction_date"]=="1900-01-01" else date.fromisoformat(t["transaction_date"])
        gross=float(t["gross_amount_eur"] or 0); fees=float(t["fees_eur"] or 0)
        if typ in {"opening","buy"}: flows.append((d,-(gross+fees)))
        elif typ=="sell": flows.append((d,gross-fees))
        elif typ=="dividend": flows.append((d,gross))
        elif typ=="fee": flows.append((d,-gross))
    flows.append((today,float(snap.get("total_value") or 0)))
    xirr=_xirr(flows)
    hist=[dict(r) for r in conn.execute("SELECT * FROM portfolio_snapshots ORDER BY created_at ASC LIMIT 1500").fetchall()]
    conn.close()
    # Risk and overlap diagnostics.
    categories={}; category_targets={}
    for p in snap.get("positions",[]):
        cat=_risk_category(p); categories[cat]=categories.get(cat,0)+float(p.get("weight_pct") or 0)
        category_targets[cat]=category_targets.get(cat,0)+float(p.get("target_pct") or 0)
    top=sorted(snap.get("positions",[]),key=lambda p:p.get("weight_pct",0),reverse=True)[:3]
    alerts=[]
    if abs(float(snap.get("target_total_pct") or 0)-100)>0.1: alerts.append(f"La somme des cibles vaut {snap.get('target_total_pct',0):.1f} %, pas 100 %.")
    missing=[p["name"] for p in snap.get("positions",[]) if not p.get("quote_configured")]
    if missing: alerts.append(f"{len(missing)} ligne(s) sans source de marché.")
    if top and float(top[0].get("weight_pct") or 0)>30: alerts.append(f"Concentration élevée : {top[0]['name']} pèse {top[0]['weight_pct']:.1f} %.")
    broad=[p["name"] for p in snap.get("positions",[]) if any(k in (p.get("name") or "").lower() for k in ["world","all country","global","s&p 500"])]
    overlap=[]
    if len(broad)>=2: overlap.append("Chevauchement probable entre ETF larges : "+", ".join(broad)+". Cette alerte est qualitative, pas une mesure exacte des constituants.")
    usage_calls=int(settings.get("eodhd_calls_today","0") or 0) if settings.get("eodhd_calls_date","")==today.isoformat() else 0
    limit=int(settings.get("eodhd_daily_limit","0") or 0)
    return {
        "year":year,
        "effort":{"confirmations":confirmations,"confirmed_extra":round(confirmed_extra,2),"period_start":period_start.isoformat(),"period_end":(period_end-timedelta(days=1)).isoformat(),"labels":period_labels,"extra_monthly":extra_monthly,"other_monthly":other_monthly,"other_extra":round(sum(other_monthly),2),"total_actual":round(actual+extra_gross+sum(other_monthly),2),"legacy_catchup":float(settings.get("effort_ytd_catchup","0") or 0),"monthly_target":monthly_target,"annual_goal":annual_goal,"actual":round(actual,2),"journal_actual":round(journal_actual,2),"catchup":round(catchup,2),"expected_ytd":round(expected_ytd,2),"net_vs_plan_ytd":round(actual-expected_ytd,2),"extra_gross":round(extra_gross,2),"remaining":round(remaining,2),"pace_projection":round(pace,2),"monthly":[round(x,2) for x in monthly],"origins":origins,"encouragement":encouragement},
        "performance":{"xirr_pct":round(xirr,2) if xirr is not None else None,"xirr_note":"Estimation depuis le journal : les soldes initiaux sont datés au premier mouvement connu.","dividends_year":round(dividends,2),"realized_year":round(realized,2),"history":hist},
        "risk":{"categories":categories,"category_targets":{k:round(v,4) for k,v in category_targets.items()},"top_holdings":[{"name":p["name"],"weight_pct":p["weight_pct"]} for p in top],"alerts":alerts,"overlap":overlap},
        "rebalance":_rebalance_suggestions(snap, rebalance_amount if rebalance_amount is not None else monthly_target),
        "reconciliation":{"tr_reference_value":tr_ref,"tracker_value":snap.get("total_value",0),"gap":round(tr_ref-snap.get("total_value",0),2) if tr_ref>0 else None,"gap_pct":round((tr_ref/snap.get("total_value",1)-1)*100,2) if tr_ref>0 and snap.get("total_value",0)>0 else None},
        "api_usage":{"calls_today":usage_calls,"daily_limit":limit},
    }


def _safe_version_tuple(value: str) -> tuple[int, ...]:
    m = re.fullmatch(r"\s*(\d+)(?:\.(\d+))?(?:\.(\d+))?\s*", value or "")
    if not m:
        raise ValueError("Version invalide")
    return tuple(int(x or 0) for x in m.groups())


def _validate_zip_member(name: str) -> None:
    normalized = name.replace("\\", "/")
    if normalized.startswith("/") or any(part == ".." for part in normalized.split("/")):
        raise HTTPException(400, "Archive de mise à jour invalide")


def _package_root(extract_dir: Path) -> tuple[Path, dict]:
    manifests = list(extract_dir.glob("update_manifest.json")) + list(extract_dir.glob("*/update_manifest.json"))
    if len(manifests) != 1:
        raise HTTPException(400, "Le paquet doit contenir un update_manifest.json unique")
    manifest_path = manifests[0]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(400, f"Manifest de mise à jour illisible: {exc}")
    if manifest.get("app_id") != APP_ID:
        raise HTTPException(400, "Ce paquet n'est pas destiné à Portfolio Tracker")
    try:
        new_version = _safe_version_tuple(str(manifest.get("version", "")))
        current_version = _safe_version_tuple(APP_VERSION)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    if new_version <= current_version:
        raise HTTPException(400, f"Version {manifest.get('version')} non supérieure à la version actuelle {APP_VERSION}")
    root = manifest_path.parent
    required = [root / "app.py", root / "static" / "index.html", root / "requirements.txt"]
    if not all(x.exists() for x in required):
        raise HTTPException(400, "Paquet incomplet: app.py, static/index.html et requirements.txt sont requis")
    return root, manifest


def _copy_app_files(src: Path, dst: Path) -> None:
    files = ["app.py", "requirements.txt", "README.md", "update_manifest.json"]
    dirs = ["static", "data"]
    for name in files:
        source = src / name
        if source.exists():
            shutil.copy2(source, dst / name)
    for name in dirs:
        source = src / name
        if not source.exists():
            continue
        target = dst / name
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(source, target)


def _make_backup(label: str | None = None) -> Path:
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    name = f"{stamp}-{label or ('v' + APP_VERSION)}"
    target = BACKUPS_DIR / name
    target.mkdir(parents=True, exist_ok=False)
    _copy_app_files(ROOT, target)
    return target


def _backup_database() -> Path | None:
    if not DB_PATH.exists():
        return None
    DB_BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = DB_BACKUPS_DIR / f"portfolio-{stamp}.db"
    shutil.copy2(DB_PATH, target)
    return target


RESTART_HELPER_SOURCE = 'import ctypes\nimport json\nimport os\nfrom pathlib import Path\nimport socket\nimport subprocess\nimport sys\nimport time\nimport traceback\nimport urllib.request\n\nroot = Path(sys.argv[1])\nparent_pid, host, port = int(sys.argv[2]), sys.argv[3], int(sys.argv[4])\nlog_path = root / ".updates" / "restart.log"\n\ndef wait_for_parent():\n    if os.name == "nt":\n        from ctypes import wintypes\n        kernel = ctypes.WinDLL("kernel32", use_last_error=True)\n        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]\n        kernel.OpenProcess.restype = wintypes.HANDLE\n        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]\n        kernel.WaitForSingleObject.restype = wintypes.DWORD\n        kernel.CloseHandle.argtypes = [wintypes.HANDLE]\n        handle = kernel.OpenProcess(0x00100000, False, parent_pid)\n        if not handle:\n            if ctypes.get_last_error() == 87:\n                return\n            raise OSError(ctypes.get_last_error(), "Cannot observe previous server")\n        try:\n            if kernel.WaitForSingleObject(handle, 30000) != 0:\n                raise RuntimeError("Previous server did not exit within 30 seconds")\n        finally:\n            kernel.CloseHandle(handle)\n    else:\n        deadline = time.monotonic() + 30\n        while time.monotonic() < deadline:\n            try:\n                os.kill(parent_pid, 0)\n            except ProcessLookupError:\n                return\n            time.sleep(0.2)\n        raise RuntimeError("Previous server did not exit within 30 seconds")\n\ntry:\n    wait_for_parent()\n    address = "127.0.0.1" if host == "0.0.0.0" else "::1" if host == "::" else host\n    # Wait for the listening socket to be released; do not launch duplicate servers.\n    deadline = time.monotonic() + 10\n    while True:\n        with socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET) as probe:\n            try:\n                probe.bind((host, port))\n                break\n            except OSError:\n                if time.monotonic() >= deadline:\n                    raise RuntimeError("Server port is still occupied")\n        time.sleep(0.2)\n    expected = json.loads((root / "update_manifest.json").read_text(encoding="utf-8"))["version"]\n    with log_path.open("a", encoding="utf-8") as log:\n        log.write("\\nStarting Portfolio Tracker " + expected + "\\n")\n        log.flush()\n        proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "app:app", "--host", host, "--port", str(port)], cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=log)\n        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))\n        url_host = "[" + address + "]" if ":" in address else address\n        for _ in range(40):\n            if proc.poll() is not None:\n                raise RuntimeError("Replacement server exited: " + str(proc.returncode))\n            try:\n                with opener.open("http://" + url_host + ":" + str(port) + "/api/health", timeout=1) as response:\n                    health = json.load(response)\n                if health.get("ok") and health.get("version") == expected:\n                    log.write("Restart confirmed: " + expected + "\\n")\n                    break\n            except Exception:\n                pass\n            time.sleep(0.5)\n        else:\n            raise RuntimeError("Replacement server did not become healthy")\nexcept Exception:\n    with log_path.open("a", encoding="utf-8") as log:\n        traceback.print_exc(file=log)\n    sys.exit(1)\n'


def _restart_server_later() -> None:
    # Start a detached Python supervisor without cmd.exe or a console timeout.
    UPDATES_DIR.mkdir(parents=True, exist_ok=True)
    helper_path = UPDATES_DIR / "restart_helper.py"
    helper_path.write_text(RESTART_HELPER_SOURCE, encoding="utf-8")
    def option(name, default):
        for i, value in enumerate(sys.argv):
            if value == name and i + 1 < len(sys.argv):
                return sys.argv[i + 1]
            if value.startswith(name + "="):
                return value.split("=", 1)[1]
        return default
    host = option("--host", "127.0.0.1")
    port = option("--port", "8000")
    kwargs = {"creationflags": subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
    with (UPDATES_DIR / "restart.log").open("a", encoding="utf-8") as log:
        subprocess.Popen([sys.executable, str(helper_path), str(ROOT), str(os.getpid()), host, port], cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=log, **kwargs)
    # Leave time for the installation response to reach the browser.
    def exit_after_response():
        time.sleep(1.0)
        os._exit(0)
    threading.Thread(target=exit_after_response, daemon=True).start()


def _list_backups() -> list[dict]:
    if not BACKUPS_DIR.exists():
        return []
    out = []
    for p in sorted((x for x in BACKUPS_DIR.iterdir() if x.is_dir()), reverse=True):
        version = "inconnue"
        manifest = p / "update_manifest.json"
        if manifest.exists():
            try:
                version = json.loads(manifest.read_text(encoding="utf-8")).get("version", version)
            except Exception:
                pass
        out.append({"name": p.name, "version": version})
    return out


@app.get("/api/update/status")
def update_status():
    if CLOUD_MODE:
        return {
            "app_id": APP_ID,
            "current_version": APP_VERSION,
            "backups": [],
            "can_restore": False,
            "accepted_extensions": [],
            "cloud_mode": True,
            "message": "Version cloud : les mises à jour sont déployées par Koyeb depuis le dépôt Git, sans modifier le conteneur en cours.",
        }
    backups = _list_backups()
    return {
        "app_id": APP_ID,
        "current_version": APP_VERSION,
        "backups": backups[:10],
        "can_restore": bool(backups),
        "accepted_extensions": [".ptupdate", ".zip"],
        "cloud_mode": False,
    }


@app.post("/api/update/install")
async def update_install(request: Request):
    if CLOUD_MODE:
        raise HTTPException(409, "Les mises à jour cloud se font par redéploiement Koyeb/Git, pas depuis l’interface")
    raw = await request.body()
    if not raw:
        raise HTTPException(400, "Fichier de mise à jour vide")
    if len(raw) > 50 * 1024 * 1024:
        raise HTTPException(413, "Paquet de mise à jour trop volumineux")
    UPDATES_DIR.mkdir(parents=True, exist_ok=True)
    work = UPDATES_DIR / f"staging-{int(time.time() * 1000)}"
    extract = work / "extract"
    archive = work / "update.ptupdate"
    extract.mkdir(parents=True, exist_ok=True)
    archive.write_bytes(raw)
    backup = None
    try:
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                _validate_zip_member(info.filename)
            zf.extractall(extract)
        package, manifest = _package_root(extract)
        backup = _make_backup()
        db_backup = _backup_database()
        # Future releases may change dependencies. Install them inside the existing venv automatically.
        current_req = (ROOT / "requirements.txt").read_text(encoding="utf-8") if (ROOT / "requirements.txt").exists() else ""
        new_req = (package / "requirements.txt").read_text(encoding="utf-8")
        if new_req != current_req:
            proc = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(package / "requirements.txt")],
                cwd=str(ROOT), capture_output=True, text=True, timeout=240,
            )
            if proc.returncode != 0:
                raise RuntimeError("Installation des dépendances impossible: " + (proc.stderr or proc.stdout)[-1200:])
        _copy_app_files(package, ROOT)
        (UPDATES_DIR / "last_update.json").write_text(json.dumps({
            "from_version": APP_VERSION,
            "to_version": manifest.get("version"),
            "installed_at": int(time.time()),
            "backup": str(backup) if backup else None,
            "database_backup": str(db_backup) if db_backup else None,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        _restart_server_later()
        return {"ok": True, "from_version": APP_VERSION, "to_version": manifest.get("version"), "restarting": True}
    except HTTPException:
        if backup and backup.exists():
            _copy_app_files(backup, ROOT)
        raise
    except Exception as exc:
        if backup and backup.exists():
            try:
                _copy_app_files(backup, ROOT)
            except Exception:
                pass
        raise HTTPException(500, f"Mise à jour annulée, version précédente restaurée: {exc}")
    finally:
        try:
            shutil.rmtree(work)
        except Exception:
            pass


@app.post("/api/update/restore-latest")
def update_restore_latest():
    if CLOUD_MODE:
        raise HTTPException(409, "La restauration locale n’est pas disponible en mode cloud")
    backups = _list_backups()
    if not backups:
        raise HTTPException(404, "Aucune version précédente disponible")
    latest = BACKUPS_DIR / backups[0]["name"]
    safety = _make_backup(label="avant-restauration")
    try:
        _copy_app_files(latest, ROOT)
        _restart_server_later()
        return {"ok": True, "restored": backups[0], "safety_backup": safety.name, "restarting": True}
    except Exception as exc:
        try:
            _copy_app_files(safety, ROOT)
        except Exception:
            pass
        raise HTTPException(500, f"Restauration impossible: {exc}")


@app.get("/api/health")
def health():
    return {"ok": True, "version": APP_VERSION, "backend": backend_name(), "cloud_mode": CLOUD_MODE}


@app.post("/api/reset")
def reset():
    if DB_PATH.exists():
        DB_PATH.unlink()
    init_db()
    return {"ok": True}
