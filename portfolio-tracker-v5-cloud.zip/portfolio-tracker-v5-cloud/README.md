# Portfolio Tracker v5.3 Cloud

## Nouveautés v5.3

- Nouvel onglet **Positions** : lecture rapide de chaque titre avec cours, quantité, valeur et métrique configurable (% jour, % depuis acquisition, +/- value jour, +/- value depuis acquisition).
- Chaque position se déplie dans la même page pour afficher PRU, plus-value, performance, poids, cible, compte, source, place, ISIN et **historique complet des mouvements**.
- L’historique détaille achats/ventes et cadre d’investissement (Plan PEA, Round Up, Saveback, investissement libre, autre).
- L’ancienne vue analytique devient l’onglet **Tableau**, avec tri de toutes les colonnes et export Excel conservé.
- Les vues Total / CTO / PEA et les cartes Valeur / Investi / Plus-value / Performance restent en haut de Positions.
- Navigation avec icône + nom conservée.
- Même application sur desktop et mobile ; seule la mise en page s’adapte à la largeur disponible.

# Portfolio Tracker v5.2 Cloud

## Nouveautés v5.2

- Interface responsive automatique : même application, même navigation et mêmes fonctionnalités sur ordinateur, tablette et mobile.
- Barre latérale réduite aux icônes sur petit écran afin de libérer la largeur utile.
- En-tête, cartes de synthèse et actions adaptés aux écrans étroits.
- Tableau Positions conservé, mais densifié sur mobile avec première colonne fixe et défilement horizontal plus confortable.
- Boutons Transactions / Exporter Excel / Ajouter un titre regroupés sur une seule ligne sur mobile.
- Dialogues adaptés à la hauteur du téléphone avec actions accessibles.
- Aucun changement de logique financière, de stockage Neon, d’authentification ou d’API de cours.


Cette version part de **Portfolio Tracker v4.2.4** et ajoute un mode cloud sans supprimer le mode local SQLite.

## Ce qui change

- PostgreSQL via `DATABASE_URL` (Neon recommandé) ; SQLite reste disponible si `DATABASE_URL` est absent.
- Authentification obligatoire en mode cloud : identifiant + mot de passe hashé PBKDF2, session signée en cookie HttpOnly/Secure.
- La clé EODHD peut être stockée uniquement comme secret d'hébergeur (`EODHD_API_TOKEN`) et n'est pas importée dans PostgreSQL.
- Import direct de `portfolio.db` depuis **Réglages** après le premier déploiement cloud.
- Sauvegarde JSON téléchargeable depuis l'interface.
- Script de restauration d'une sauvegarde JSON.
- Cours manuel par exception : une ligne peut utiliser un cours EUR saisi manuellement, sans modifier le PRU ni les transactions, puis repasser en automatique.
- PWA conservée.
- L'auto-update `.ptupdate` est désactivé en cloud : les mises à jour se font par redéploiement Git/Docker. Il reste disponible en mode local.
- Une même valeur peut exister à la fois en CTO et en PEA : l'unicité est désormais `(nom, compte)`.

## Fichiers importants

- `app.py` : application FastAPI.
- `storage.py` : compatibilité SQLite/PostgreSQL.
- `Dockerfile` : déploiement Koyeb/Render.
- `scripts/hash_password.py` : génère le hash du mot de passe de connexion.
- `scripts/migrate_sqlite_to_postgres.py` : migration CLI alternative.
- `scripts/restore_cloud_backup.py` : restauration d'une sauvegarde JSON.
- `.env.example` : variables attendues.

---

# Déploiement recommandé : Neon + Koyeb

Le code est aussi compatible avec Render. Les données doivent rester dans Neon : le disque d'un service web gratuit peut être éphémère.

## 1. Créer la base Neon

1. Crée un projet PostgreSQL sur Neon.
2. Choisis une région européenne proche si disponible.
3. Récupère une chaîne de connexion PostgreSQL **pooled** au format :

```text
postgresql://USER:PASSWORD@HOST/DB?sslmode=require
```

Conserve-la comme secret. Ne la colle jamais dans le code ou dans GitHub.

## 2. Générer le mot de passe Portfolio Tracker

Sur un PC avec Python :

```powershell
py -3.13 scripts\hash_password.py
```

Le script demande deux fois le mot de passe et affiche une valeur de ce type :

```text
pbkdf2_sha256$310000$...$...
```

Cette valeur est **le hash**, pas le mot de passe. Elle sera utilisée dans `APP_PASSWORD_HASH`.

Génère aussi un secret de session :

```powershell
py -3.13 -c "import secrets; print(secrets.token_urlsafe(48))"
```

## 3. Mettre le code dans un dépôt Git privé

Crée un dépôt GitHub privé et ajoute les fichiers de ce dossier.

**Ne mets jamais** dans le dépôt :

- `portfolio.db`
- un fichier `.env`
- la clé EODHD
- la chaîne Neon `DATABASE_URL`
- ton mot de passe

Le `.gitignore` et le `.dockerignore` fournis excluent déjà les bases SQLite et `.env` pour un usage Git normal.

## 4. Déployer le service web sur Koyeb

1. Crée une Web Service depuis le dépôt GitHub.
2. Utilise le `Dockerfile` présent à la racine.
3. Choisis l'instance **Free** et la région **Frankfurt** si proposée.
4. Le service écoute le port fourni par la variable Koyeb `PORT`.
5. Configure `/api/health` comme health check si l'interface le propose.

Crée les secrets/variables suivants :

```text
DATABASE_URL=<connexion Neon pooled>
CLOUD_MODE=1
APP_USERNAME=<identifiant de ton choix>
APP_PASSWORD_HASH=<hash généré>
SESSION_SECRET=<secret aléatoire généré>
EODHD_API_TOKEN=<ta clé EODHD>
```

Sur Koyeb, utilise de préférence des **Secrets** pour `DATABASE_URL`, `APP_PASSWORD_HASH`, `SESSION_SECRET` et `EODHD_API_TOKEN`.

## 5. Premier accès

Ouvre l'URL HTTPS fournie par Koyeb. Tu dois arriver sur l'écran de connexion Portfolio Tracker.

Après connexion, l'application peut être vide : c'est normal.

## 6. Importer ta base locale sans Terminal

Dans **Réglages** :

1. section **Importer le portefeuille local** ;
2. sélectionne une **copie** de `portfolio.db` ;
3. si la base cloud contient déjà des données, coche **Remplacer les données cloud existantes** ;
4. clique **Importer la base locale**.

L'import transfère :

- positions ;
- transactions ;
- objectifs/cibles ;
- confirmations d'effort ;
- snapshots historiques ;
- réglages non sensibles.

La clé EODHD présente dans la base locale est explicitement exclue.

## 7. Vérifier

Contrôle au minimum :

- nombre de positions ;
- vues Total / CTO / PEA ;
- valeur investie / PRU ;
- transactions ;
- cibles ;
- onglet Effort ;
- actualisation manuelle des cours.

Conserve l'installation locale v4.2.4 tant que tu n'as pas validé ces points.

---

# Migration alternative en ligne de commande

Si tu préfères migrer directement depuis le PC vers Neon :

```powershell
$env:DATABASE_URL="postgresql://..."
py -3.13 -m venv .venv-cloud
.\.venv-cloud\Scripts\python.exe -m pip install -r requirements.txt
.\.venv-cloud\Scripts\python.exe scripts\migrate_sqlite_to_postgres.py C:\PortfolioTracker\portfolio.db --replace
```

La clé EODHD locale n'est pas migrée.

---

# Sauvegardes

Dans **Réglages**, utilise **Télécharger une sauvegarde des données**. Le fichier JSON contient les tables Portfolio Tracker mais pas la clé EODHD.

Restauration CLI :

```powershell
$env:DATABASE_URL="postgresql://..."
.\.venv-cloud\Scripts\python.exe scripts\restore_cloud_backup.py portfolio-cloud-backup-AAAA-MM-JJ.json --replace
```

Ne supprime pas ta copie locale tant que tu n'as pas plusieurs sauvegardes vérifiées.

---

# Cours manuel par exception

Dans **Modifier la position**, la section **Cours manuel de secours** permet :

- de saisir un cours en EUR pour une ligne problématique ;
- d'ajouter une note, par exemple `Trade Republic` ;
- de conserver en mémoire le dernier cours automatique ;
- de revenir en automatique en un clic.

Une ligne en cours manuel est exclue de l'actualisation automatique de cette ligne afin d'éviter d'écraser ton choix. Les autres lignes continuent d'utiliser EODHD.

---

# Mode local

Sans `DATABASE_URL`, l'application continue d'utiliser `portfolio.db` dans le dossier du projet. Sans `CLOUD_MODE=1`, l'authentification cloud est désactivée par défaut.

Lancement local :

```powershell
.\.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8000
```

---

# Alternative Render

Le même `Dockerfile` peut être déployé comme **Web Service** gratuit sur Render. Configure les mêmes variables/secrets et utilise toujours Neon pour PostgreSQL. Le service gratuit Render peut s'endormir après inactivité ; la première ouverture peut donc être plus lente.

---

# Notes de sécurité

- N'expose jamais une version cloud sans `APP_USERNAME`, `APP_PASSWORD_HASH` et `SESSION_SECRET` : le serveur refuse volontairement de démarrer si l'authentification cloud est incomplète.
- Le cookie de session est `HttpOnly`, `Secure` en cloud et `SameSite=Lax`.
- Le mot de passe n'est pas stocké en clair dans PostgreSQL.
- La clé EODHD n'est pas stockée en PostgreSQL lorsque `EODHD_API_TOKEN` est configuré côté hébergeur.
- Utilise un dépôt Git privé.
